<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "health_monitoring";
$conn = new mysqli($servername, $username_db, $dbpassword = "", $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT 
            a.appointment_id, a.appointment_date, a.reason,
            p.patient_id, p.first_name AS patient_first_name, p.last_name AS patient_last_name,
            d.first_name AS doctor_first_name, d.last_name AS doctor_last_name, d.specialty
        FROM 
            appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        JOIN doctors d ON a.doctor_id = d.doctor_id
        ORDER BY a.appointment_date DESC";
$result = $conn->query($sql);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Appointments</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', Arial, sans-serif;
            min-height: 100vh;
            color: #1e293b;
        }
        .main-container {
            padding: 2rem 0;
            min-height: 100vh;
        }
        .page-header {
            background: rgba(255,255,255,0.95);
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            padding: 2rem 2rem 1.5rem 2rem;
            margin-bottom: 2rem;
            text-align: center;
        }
        .page-header h2 {
            font-weight: 800;
            color: #2563eb;
            margin-bottom: 0.5rem;
        }
        .page-header p {
            color: #64748b;
            font-size: 1.1rem;
        }
        .card-table {
            background: rgba(255,255,255,0.97);
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.10);
            padding: 2rem 1.5rem;
            margin-bottom: 2rem;
        }
        .table th {
            background: linear-gradient(90deg, #2563eb 60%, #7c3aed 100%);
            color: white;
            font-weight: 700;
            border: none;
        }
        .table td, .table th {
            vertical-align: middle;
        }
        .btn-detail {
            background: linear-gradient(90deg, #17a2b8 60%, #2563eb 100%);
            color: white;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            transition: background 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px rgba(23,162,184,0.08);
        }
        .btn-detail:hover {
            background: linear-gradient(90deg, #138496 60%, #1d4ed8 100%);
            color: #fff;
            box-shadow: 0 4px 16px rgba(37,99,235,0.12);
        }
        @media (max-width: 768px) {
            .main-container {
                padding: 1rem 0.2rem;
            }
            .card-table {
                padding: 1rem 0.2rem;
            }
        }
    </style>
</head>
<body>
<div class="container main-container">
    <div class="page-header">
        <h2><i class="fas fa-calendar-check"></i> All Appointments</h2>
        <p>View all scheduled appointments, patients, and doctors at a glance.</p>
    </div>
    <div class="card-table">
        <table class="table table-bordered table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Doctor</th>
                    <th>Specialty</th>
                    <th>Appointment Date</th>
                    <th>Reason</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><i class="fas fa-user text-primary me-1"></i> <?php echo htmlspecialchars($row['patient_first_name'] . ' ' . $row['patient_last_name']); ?></td>
                        <td><i class="fas fa-user-md text-success me-1"></i> <?php echo htmlspecialchars($row['doctor_first_name'] . ' ' . $row['doctor_last_name']); ?></td>
                        <td><i class="fas fa-stethoscope text-warning me-1"></i> <?php echo htmlspecialchars($row['specialty']); ?></td>
                        <td><i class="fas fa-clock text-info me-1"></i> <?php echo htmlspecialchars($row['appointment_date']); ?></td>
                        <td><?php echo htmlspecialchars($row['reason']); ?></td>
                        <td>
                            <a href="appointment_details.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-detail btn-sm"><i class="fas fa-eye"></i> View</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No appointments found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
