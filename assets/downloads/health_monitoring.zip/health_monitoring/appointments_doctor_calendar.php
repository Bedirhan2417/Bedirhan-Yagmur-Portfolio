<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Doctor Appointment Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .container-fluid {
            padding: 2rem;
        }

        .header-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .header-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 1rem;
            text-shadow: 0 2px 4px rgba(37, 99, 235, 0.1);
        }

        .header-subtitle {
            color: var(--gray-600);
            text-align: center;
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .calendar-container {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        #calendar {
            background: var(--white);
            border-radius: 15px;
            overflow: hidden;
        }

        /* FullCalendar Customization */
        .fc {
            font-family: 'Inter', sans-serif;
        }

        .fc-toolbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            padding: 1.5rem;
            border-radius: 15px 15px 0 0;
            margin-bottom: 0;
        }

        .fc-toolbar-title {
            color: var(--white);
            font-weight: 700;
            font-size: 1.5rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .fc-button {
            background: rgba(255, 255, 255, 0.2) !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
            color: var(--white) !important;
            font-weight: 600;
            border-radius: 8px !important;
            padding: 0.5rem 1rem !important;
            transition: all 0.3s ease !important;
            backdrop-filter: blur(10px);
        }

        .fc-button:hover {
            background: rgba(255, 255, 255, 0.3) !important;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .fc-button.fc-button-active {
            background: var(--white) !important;
            color: var(--primary-color) !important;
            box-shadow: var(--shadow-md);
        }

        .fc-col-header {
            background: var(--gray-100);
        }

        .fc-col-header-cell {
            background: var(--gray-100);
            border: 1px solid var(--gray-200);
            padding: 1rem 0;
        }

        .fc-col-header-cell-cushion {
            color: var(--gray-700);
            font-weight: 700;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .fc-daygrid-day {
            border: 1px solid var(--gray-200);
            transition: background-color 0.2s ease;
        }

        .fc-daygrid-day:hover {
            background-color: var(--gray-100);
        }

        .fc-daygrid-day-number {
            color: var(--gray-700);
            font-weight: 600;
            padding: 0.5rem;
        }

        .fc-day-today {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.1), rgba(59, 130, 246, 0.1)) !important;
        }

        .fc-day-today .fc-daygrid-day-number {
            background: var(--primary-color);
            color: var(--white);
            border-radius: 50%;
            width: 2rem;
            height: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0.25rem;
        }

        /* Event Styling */
        .fc-event {
            border: none !important;
            border-radius: 8px !important;
            padding: 0.25rem 0.5rem !important;
            margin: 0.125rem !important;
            font-size: 0.8rem !important;
            font-weight: 600 !important;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }

        .fc-event:hover {
            transform: scale(1.02);
            box-shadow: var(--shadow-md);
        }

        .fc-event-main {
            color: var(--white) !important;
        }

        .fc-event-time {
            font-weight: 700;
        }

        .fc-event-title {
            font-weight: 600;
        }

        /* Refresh Button Styles */
        #refreshCalendar:hover {
            background: rgba(255, 255, 255, 1) !important;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        #refreshCalendar:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* All events use the same color */
        .event-regular {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
        }



        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }

            .header-section {
                padding: 1.5rem;
            }

            .header-title {
                font-size: 2rem;
            }

            .calendar-container {
                padding: 1rem;
            }

            .fc-toolbar {
                flex-direction: column;
                gap: 1rem;
            }

            .fc-toolbar-chunk {
                display: flex;
                justify-content: center;
            }
        }



        /* Custom Modal */
        .custom-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--white);
            margin: 5% auto;
            padding: 2rem;
            border-radius: 20px;
            width: 90%;
            max-width: 500px;
            box-shadow: var(--shadow-xl);
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .modal-title {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.5rem;
        }

        .close {
            color: var(--gray-600);
            font-size: 2rem;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close:hover {
            color: var(--danger-color);
        }

        .appointment-details {
            background: var(--gray-100);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1rem;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
            padding: 0.75rem;
            background: var(--white);
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .detail-icon {
            width: 40px;
            height: 40px;
            background: var(--primary-color);
            color: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }

        .detail-content h4 {
            margin: 0;
            color: var(--gray-800);
            font-weight: 600;
        }

        .detail-content p {
            margin: 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
      
        <div class="header-section">
            <a href="caretaker_dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
                Back to Dashboard
            </a>
            <h1 class="header-title">
                <i class="fas fa-calendar-alt me-3"></i>
                Doctor Appointments Calendar
            </h1>
            <p class="header-subtitle">
                Manage and view all scheduled appointments in an organized calendar interface
            </p>
            <div style="text-align: center; margin-top: 1rem;">
                <button id="refreshCalendar" class="btn btn-light" style="background: rgba(255,255,255,0.9); border: 1px solid rgba(255,255,255,0.3); padding: 0.75rem 1.5rem; border-radius: 12px; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; transition: all 0.3s ease; border: none; cursor: pointer; color: #334155;">
                    <i class="fas fa-sync-alt"></i> Refresh Calendar
                </button>
            </div>
        </div>

      
        <div class="calendar-container">
            <div id="calendar"></div>
        </div>
            </div>
        </div>
    </div>


    <div id="appointmentModal" class="custom-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    <i class="fas fa-calendar-check me-2"></i>
                    Appointment Details
                </h3>
                <span class="close">&times;</span>
            </div>
            <div id="modalBody">
           
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var calendarEl = document.getElementById('calendar');
            var modal = document.getElementById('appointmentModal');
            var closeBtn = document.querySelector('.close');
            var refreshBtn = document.getElementById('refreshCalendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: 'en',
                timeZone: 'local',
                height: 'auto',
                aspectRatio: 1.8,
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth'
                },
                buttonText: {
                    today: 'Today',
                    month: 'Month'
                },
                events: {
                    url: 'appointments_doctor_data.php',
                    failure: function(xhr, textStatus, error) {
                        console.error('Events fetch error:', xhr.responseText);
                        alert('There was an error while fetching events! Check console for details.');
                    }
                },
                eventDisplay: 'block',

                eventClick: function(info) {
                    showAppointmentModal(info.event);
                },

                eventDidMount: function(info) {
              
                    info.el.title = `${info.event.title}\n${info.event.start.toLocaleTimeString()}\n${info.event.extendedProps.description || ''}`;
                },

                eventContent: function(arg) {
                    const time = arg.event.start.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                    const title = arg.event.title;
                    const description = arg.event.extendedProps.description || '';
                    const doctorName = arg.event.extendedProps.doctor_name || 'Unknown Doctor';
                    const doctorSpecialization = arg.event.extendedProps.doctor_specialization || '';

                    return {
                        html: `
                            <div style="padding: 2px;">
                                <div style="font-weight: 700; font-size: 0.75rem; margin-bottom: 2px;">
                                    <i class="fas fa-clock me-1"></i>${time}
                                </div>
                                <div style="font-weight: 600; font-size: 0.8rem; margin-bottom: 2px;">
                                    <i class="fas fa-user me-1"></i>${title}
                                </div>
                                <div style="font-size: 0.7rem; opacity: 0.9; margin-bottom: 2px;">
                                    <i class="fas fa-user-md me-1"></i>${doctorName}
                                    ${doctorSpecialization ? ` (${doctorSpecialization})` : ''}
                                </div>
                                ${description ? `<div style="font-size: 0.7rem; opacity: 0.9;">
                                    <i class="fas fa-sticky-note me-1"></i>${description}
                                </div>` : ''}
                            </div>
                        `
                    };
                },

                loading: false
            });

            calendar.render();

        
            document.getElementById('refreshCalendar').addEventListener('click', function() {
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
                this.disabled = true;
                
           
                calendar.refetchEvents();
                
                setTimeout(() => {
                    this.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh Calendar';
                    this.disabled = false;
                }, 1000);
            });
            function showAppointmentModal(event) {
                const modalBody = document.getElementById('modalBody');
                const startTime = event.start.toLocaleString();
                const endTime = event.end ? event.end.toLocaleString() : 'Not specified';
                const description = event.extendedProps.description || 'No description provided';
                const type = event.extendedProps.type || 'regular';
                const status = event.extendedProps.status || 'scheduled';
                const doctorName = event.extendedProps.doctor_name || 'Unknown Doctor';
                const doctorSpecialization = event.extendedProps.doctor_specialization || '';

                modalBody.innerHTML = `
                    <div class="appointment-details">
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Patient Name</h4>
                                <p>${event.title}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-calendar"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Date & Time</h4>
                                <p>${startTime}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Duration</h4>
                                <p>${endTime}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-sticky-note"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Reason/Notes</h4>
                                <p>${description}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-user-md"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Doctor</h4>
                                <p>${doctorName}${doctorSpecialization ? ` (${doctorSpecialization})` : ''}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-tag"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Appointment Type</h4>
                                <p>${type.charAt(0).toUpperCase() + type.slice(1)}</p>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-info-circle"></i>
                            </div>
                            <div class="detail-content">
                                <h4>Status</h4>
                                <p>${status.charAt(0).toUpperCase() + status.slice(1)}</p>
                            </div>
                        </div>
                    </div>
                `;

                modal.style.display = 'block';
            }

        
            closeBtn.onclick = function() {
                modal.style.display = 'none';
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }

        
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && modal.style.display === 'block') {
                    modal.style.display = 'none';
                }
            });
            refreshBtn.addEventListener('click', function() {
                calendar.refetchEvents();
                alert('Calendar refreshed successfully!');
            });
        });
    </script>
</body>
</html>
