<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

$caretaker_id = $_SESSION['user_id'];

$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success = false;
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $contact_number = trim($_POST['contact_number']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $medical_history = trim($_POST['medical_history']);
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

   
    $heart_rate = trim($_POST['heart_rate']);
    $blood_pressure = trim($_POST['blood_pressure']);
    $step_count = intval($_POST['step_count']);
    $oxygen_level = trim($_POST['oxygen_level']);
    $body_temperature = trim($_POST['body_temperature']);

    $fall_detected = $_POST['fall_detected'];


    if ($first_name && $last_name && $date_of_birth && $gender && $contact_number && $email && $address) {
        $conn->begin_transaction();

        try {

            $patient_sql = "INSERT INTO patients (first_name, last_name, date_of_birth, gender, contact_number, email, address, medical_history, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $patient_stmt = $conn->prepare($patient_sql);
            $patient_stmt->bind_param("ssssssssi", $first_name, $last_name, $date_of_birth, $gender, $contact_number, $email, $address, $medical_history, $caretaker_id);

            if (!$patient_stmt->execute()) {
                throw new Exception("❌ Error adding patient: " . $patient_stmt->error);
            }

            $patient_id = $conn->insert_id;
            echo "✅ New patient added: $first_name $last_name (ID: $patient_id)\n";
            

            $stmt_health = $conn->prepare("INSERT INTO health_data (patient_id, heart_rate, blood_pressure, step_count, oxygen_level, body_temperature, fall_detected) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt_health->bind_param("isssssi", $patient_id, $heart_rate, $blood_pressure, $step_count, $oxygen_level, $body_temperature, $fall_detected);
            $stmt_health->execute();
            $stmt_health->close();

            $location_sql = "INSERT INTO patient_locations (patient_id, latitude, longitude, timestamp) VALUES (?, ?, ?, NOW())";
            $location_stmt = $conn->prepare($location_sql);
            $location_stmt->bind_param("idd", $patient_id, $latitude, $longitude);
            $location_stmt->execute();
            $location_stmt->close();
            
            $conn->commit();
            $success = true;

        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            $error = "Error: " . $exception->getMessage();
        }

    } else {
        $error = "All personal information fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Patient | Health Monitoring System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --border-radius: 16px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
            color: #1e293b;
        }
        .main-container {
            padding: 2rem;
        }
        .page-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
        }
        .page-header h2 {
            color: var(--primary-color);
            font-weight: 700;
        }
        .form-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            padding: 2.5rem;
        }
        .form-section {
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 2rem;
            margin-bottom: 2rem;
        }
        .form-section:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }
        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .section-title i {
            color: var(--primary-color);
        }
        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 0.8rem 1rem;
            transition: var(--transition);
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            outline: none;
        }
        .form-label {
            font-weight: 600;
            color: #374151;
            margin-bottom: 0.5rem;
        }
        .btn {
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            transition: var(--transition);
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
            color: white;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: var(--secondary-color);
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .alert {
            border-radius: var(--border-radius);
            border-left-width: 4px;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="page-header">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent p-0 m-0">
                    <li class="breadcrumb-item"><a href="patient_list.php">Patients</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add New Patient</li>
                </ol>
            </nav>
            <h2 class="mt-2"><i class="fas fa-user-plus"></i> Add New Patient</h2>
            <p class="text-muted">Fill in the form below to register a new patient.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">Patient and health data added successfully. <a href="patient_list.php">Back to list</a></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="form-card">
            <form method="POST">
                <div class="form-section">
                    <h3 class="section-title"><i class="fas fa-user"></i>Personal Information</h3>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="date_of_birth" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select" required>
                                <option value="">Select...</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="text" name="contact_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label">Medical History</label>
                            <textarea name="medical_history" class="form-control" rows="4" placeholder="Enter patient's medical history, allergies, chronic conditions, etc."></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3 class="section-title"><i class="fas fa-heartbeat"></i>Health Metrics</h3>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                           <label class="form-label">Heart Rate (bpm)</label>
                           <input type="number" name="heart_rate" class="form-control">
                       </div>
                       <div class="col-md-4 mb-3">
                           <label class="form-label">Blood Pressure</label>
                           <input type="text" name="blood_pressure" placeholder="e.g., 120/80" class="form-control">
                       </div>
                       <div class="col-md-4 mb-3">
                           <label class="form-label">Oxygen Level (%)</label>
                           <input type="number" name="oxygen_level" class="form-control">
                       </div>
                   </div>
                    <div class="row">
                       <div class="col-md-4 mb-3">
                           <label class="form-label">Body Temperature (°C)</label>
                           <input type="text" name="body_temperature" class="form-control">
                       </div>
                       <div class="col-md-4 mb-3">
                           <label class="form-label">Step Count</label>
                           <input type="number" name="step_count" class="form-control">
                       </div>

                   </div>
                </div>



                <div class="row mb-4">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Fall Detected</label>
                        <select name="fall_detected" class="form-select">
                            <option value="0" selected>No</option>
                            <option value="1">Yes</option>
                        </select>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <a href="patient_list.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Patient</button>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
