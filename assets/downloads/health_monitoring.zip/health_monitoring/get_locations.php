<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Please login first']);
    exit;
}


if ($_SESSION['user_type'] !== 'caretaker') {
    echo json_encode(['error' => 'Only caretakers can access this']);
    exit;
}

$caretaker_id = $_SESSION['user_id'];

require_once 'config.php';

header('Content-Type: application/json');


$uk_locations = [
    ['name' => 'London', 'lat' => 51.5074, 'lng' => -0.1278],
    ['name' => 'Manchester', 'lat' => 53.4808, 'lng' => -2.2426],
    ['name' => 'Birmingham', 'lat' => 52.4862, 'lng' => -1.8904],
    ['name' => 'Liverpool', 'lat' => 53.4084, 'lng' => -2.9916],
    ['name' => 'Leeds', 'lat' => 53.8008, 'lng' => -1.5491],
    ['name' => 'Sheffield', 'lat' => 53.3811, 'lng' => -1.4701],
    ['name' => 'Edinburgh', 'lat' => 55.9533, 'lng' => -3.1883],
    ['name' => 'Bristol', 'lat' => 51.4545, 'lng' => -2.5879],
    ['name' => 'Cardiff', 'lat' => 51.4816, 'lng' => -3.1791],
    ['name' => 'Glasgow', 'lat' => 55.8642, 'lng' => -4.2518]
];


$sql = "SELECT p.patient_id, p.first_name, p.last_name, p.address 
        FROM patients p 
        WHERE p.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $caretaker_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo json_encode(['error' => "SQL Error: " . $conn->error]);
    exit;
}

$patients = [];

while ($row = $result->fetch_assoc()) {
    $patient_id = $row['patient_id'];
    
    
    $check_sql = "SELECT * FROM patient_locations WHERE patient_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $patient_id);
    $check_stmt->execute();
    $location_result = $check_stmt->get_result();
    
    if ($location_result->num_rows > 0) {

        $location_data = $location_result->fetch_assoc();
        $row['latitude'] = $location_data['latitude'];
        $row['longitude'] = $location_data['longitude'];
        $row['timestamp'] = $location_data['timestamp'];
        $row['location_name'] = "Location #" . $location_data['location_id'];
    } else {

        $random_location = $uk_locations[array_rand($uk_locations)];
        

        $lat_offset = (rand(-100, 100) / 1000); 
        $lng_offset = (rand(-100, 100) / 1000); 
        
        $final_lat = $random_location['lat'] + $lat_offset;
        $final_lng = $random_location['lng'] + $lng_offset;
        

        $insert_sql = "INSERT INTO patient_locations (patient_id, latitude, longitude, timestamp) 
                       VALUES (?, ?, ?, NOW())";
        
        $insert_stmt = $conn->prepare($insert_sql);
        if (!$insert_stmt) {
            echo json_encode(['error' => "Prepare failed: " . $conn->error]);
            exit;
        }
        
        $insert_stmt->bind_param("idd", $patient_id, $final_lat, $final_lng);
        
        if (!$insert_stmt->execute()) {
            echo json_encode(['error' => "Execute failed: " . $insert_stmt->error]);
            exit;
        }
        
        $row['latitude'] = $final_lat;
        $row['longitude'] = $final_lng;
        $row['timestamp'] = date('Y-m-d H:i:s');
        $row['location_name'] = $random_location['name'];
    }
    
    $patients[] = $row;
}

echo json_encode($patients);
