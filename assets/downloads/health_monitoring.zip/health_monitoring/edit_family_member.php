<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';


if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: family_members.php");
    exit();
}

$member_id = $_GET['id'];


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $relationship = trim($_POST['relationship']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $notification_preferences = $_POST['notification_preferences'];
    $emergency_contact = isset($_POST['emergency_contact']) ? 1 : 0;
    
    
    $errors = [];
    
    if (empty($first_name)) $errors[] = "First name is required";
    if (empty($last_name)) $errors[] = "Last name is required";
    if (empty($relationship)) $errors[] = "Relationship is required";
    if (empty($phone)) $errors[] = "Phone number is required";
    if (empty($email)) $errors[] = "Email is required";
    
    if (empty($errors)) {
        
        $sql = "UPDATE family_members SET 
                first_name = ?, 
                last_name = ?, 
                relationship = ?, 
                phone = ?, 
                email = ?, 
                notification_preferences = ?, 
                emergency_contact = ?
                WHERE member_id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssii", $first_name, $last_name, $relationship, $phone, $email, $notification_preferences, $emergency_contact, $member_id);
        
        if ($stmt->execute()) {
            $success_message = "Family member updated successfully!";
        } else {
            $errors[] = "Error updating family member: " . $conn->error;
        }
        $stmt->close();
    }
}


$sql = "SELECT * FROM family_members WHERE member_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $member_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: family_members.php");
    exit();
}

$member = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Family Member</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .container-fluid {
            padding: 2rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .form-container {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            max-width: 800px;
            margin: 0 auto;
        }

        .form-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2rem;
            margin-bottom: 0.5rem;
            text-align: center;
        }

        .form-subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            color: var(--gray-700);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: block;
        }

        .form-control {
            border: 2px solid var(--gray-200);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--white);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            outline: none;
        }

        .form-select {
            border: 2px solid var(--gray-200);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--white);
        }

        .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            outline: none;
        }

        .notification-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 0.5rem;
        }

        .notification-option {
            background: var(--gray-100);
            border: 2px solid var(--gray-200);
            border-radius: 12px;
            padding: 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }

        .notification-option:hover {
            border-color: var(--primary-color);
            background: var(--gray-200);
        }

        .notification-option.selected {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: var(--white);
        }

        .notification-option i {
            font-size: 1.5rem;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .form-check-input {
            width: 1.2rem;
            height: 1.2rem;
            border: 2px solid var(--gray-300);
            border-radius: 6px;
            cursor: pointer;
        }

        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .form-check-label {
            color: var(--gray-700);
            font-weight: 600;
            cursor: pointer;
        }

        .btn-container {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }

        .btn {
            padding: 0.75rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--gray-700);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .alert {
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border: none;
        }

        .alert-success {
            background: var(--success-color);
            color: var(--white);
        }

        .alert-danger {
            background: var(--danger-color);
            color: var(--white);
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        @media (max-width: 768px) {
            .row {
                grid-template-columns: 1fr;
            }
            
            .container-fluid {
                padding: 1rem;
            }
            
            .form-container {
                padding: 1.5rem;
            }
            
            .btn-container {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        
        <a href="family_members.php" class="back-btn">
            <i class="fas fa-arrow-left"></i>
            Back to Family Members
        </a>

        
        <div class="form-container">
            <h1 class="form-title">
                <i class="fas fa-user-edit me-3"></i>
                Edit Family Member
            </h1>
            <p class="form-subtitle">
                Update family member information and emergency contact details
            </p>

            <?php if (isset($success_message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="row">
                    <div class="form-group">
                        <label for="first_name" class="form-label">First Name *</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" 
                               value="<?php echo htmlspecialchars($member['first_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="last_name" class="form-label">Last Name *</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" 
                               value="<?php echo htmlspecialchars($member['last_name']); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group">
                        <label for="relationship" class="form-label">Relationship *</label>
                        <select class="form-select" id="relationship" name="relationship" required>
                            <option value="">Select Relationship</option>
                            <option value="Spouse" <?php echo $member['relationship'] == 'Spouse' ? 'selected' : ''; ?>>Spouse</option>
                            <option value="Parent" <?php echo $member['relationship'] == 'Parent' ? 'selected' : ''; ?>>Parent</option>
                            <option value="Child" <?php echo $member['relationship'] == 'Child' ? 'selected' : ''; ?>>Child</option>
                            <option value="Sibling" <?php echo $member['relationship'] == 'Sibling' ? 'selected' : ''; ?>>Sibling</option>
                            <option value="Grandparent" <?php echo $member['relationship'] == 'Grandparent' ? 'selected' : ''; ?>>Grandparent</option>
                            <option value="Other" <?php echo $member['relationship'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="phone" class="form-label">Phone Number *</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               value="<?php echo htmlspecialchars($member['phone']); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email Address *</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?php echo htmlspecialchars($member['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Notification Preferences</label>
                    <div class="notification-options">
                        <div class="notification-option <?php echo $member['notification_preferences'] == 'Email' ? 'selected' : ''; ?>" 
                             onclick="selectNotification('Email')">
                            <i class="fas fa-envelope"></i>
                            <div>Email</div>
                        </div>
                        <div class="notification-option <?php echo $member['notification_preferences'] == 'SMS' ? 'selected' : ''; ?>" 
                             onclick="selectNotification('SMS')">
                            <i class="fas fa-sms"></i>
                            <div>SMS</div>
                        </div>
                    </div>
                    <input type="hidden" name="notification_preferences" id="notification_preferences" 
                           value="<?php echo htmlspecialchars($member['notification_preferences']); ?>">
                </div>

                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="emergency_contact" name="emergency_contact" 
                           <?php echo $member['emergency_contact'] ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="emergency_contact">
                        Set as Primary Emergency Contact
                    </label>
                </div>

                <div class="btn-container">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Update Family Member
                    </button>
                    <a href="family_members.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script>
        function selectNotification(type) {
            
            document.querySelectorAll('.notification-option').forEach(option => {
                option.classList.remove('selected');
            });
            
            
            event.currentTarget.classList.add('selected');
            
            
            document.getElementById('notification_preferences').value = type;
        }

        
        document.addEventListener('DOMContentLoaded', function() {
            const currentPreference = '<?php echo $member['notification_preferences']; ?>';
            if (currentPreference) {
                document.querySelectorAll('.notification-option').forEach(option => {
                    if (option.textContent.trim() === currentPreference) {
                        option.classList.add('selected');
                    }
                });
            }
        });
    </script>
</body>
</html>
