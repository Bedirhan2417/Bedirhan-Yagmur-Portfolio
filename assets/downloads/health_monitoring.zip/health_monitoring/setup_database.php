<?php
require_once 'config.php';

echo "<h2>Setting up Health Monitoring Database...</h2>";


echo "<p>🔧 Dropping existing tables...</p>";


$conn->query("SET FOREIGN_KEY_CHECKS=0;");

$tables_to_drop = [
    'emergency_alerts',
    'health_data', 
    'patient_locations',
    'patient_history',
    'family_members',
    'messages',
    'appointments',
    'doctors',
    'patients',
    'users'
];

foreach ($tables_to_drop as $table) {
    $sql = "DROP TABLE IF EXISTS $table";
    $conn->query($sql);
    echo "<p>✅ Dropped $table table</p>";
}


$conn->query("SET FOREIGN_KEY_CHECKS=1;");

echo "<p>🔧 Creating database tables...</p>";


$sql = "CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    user_type ENUM('patient', 'caretaker', 'doctor') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);
echo "<p>✅ Created users table</p>";


$sql = "CREATE TABLE IF NOT EXISTS patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    contact_number VARCHAR(20),
    date_of_birth DATE,
    gender ENUM('Male', 'Female', 'Other'),
    address TEXT,
    emergency_contact VARCHAR(255),
    medical_history TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created patients table</p>";


$sql = "CREATE TABLE IF NOT EXISTS doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    contact_number VARCHAR(20),
    specialization VARCHAR(100),
    license_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created doctors table</p>";

// Create appointments table
$sql = "CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    reason TEXT,
    status ENUM('Scheduled', 'Completed', 'Cancelled') DEFAULT 'Scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created appointments table</p>";

// Create messages table
$sql = "CREATE TABLE IF NOT EXISTS messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    sender_type ENUM('patient', 'caretaker', 'doctor') NOT NULL,
    message_text TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created messages table</p>";

// Create emergency_alerts table
$sql = "CREATE TABLE IF NOT EXISTS emergency_alerts (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    alert_type ENUM('medical', 'location', 'behavioral') NOT NULL,
    alert_message TEXT NOT NULL,
    is_resolved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created emergency_alerts table</p>";

// Create health_data table
$sql = "CREATE TABLE IF NOT EXISTS health_data (
    health_data_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    heart_rate INT,
    blood_pressure VARCHAR(50),
    step_count INT,
    oxygen_level INT,
    body_temperature DECIMAL(4,1),
    fall_detected TINYINT(1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created health_data table</p>";

// Create patient_locations table
$sql = "CREATE TABLE IF NOT EXISTS patient_locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    address TEXT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created patient_locations table</p>";

// Create patient_history table
$sql = "CREATE TABLE IF NOT EXISTS patient_history (
    detail_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    previous_condition TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created patient_history table</p>";

// Create family_members table
$sql = "CREATE TABLE IF NOT EXISTS family_members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    relationship VARCHAR(50) NOT NULL,
    contact_number VARCHAR(20),
    email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE
)";
$conn->query($sql);
echo "<p>✅ Created family_members table</p>";

// Create caretaker_patients table for patient assignment
$sql = "CREATE TABLE IF NOT EXISTS caretaker_patients (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    caretaker_id INT NOT NULL,
    patient_id INT NOT NULL,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (caretaker_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY unique_assignment (caretaker_id, patient_id)
)";
$conn->query($sql);
echo "<p>✅ Created caretaker_patients table</p>";

// Health Recommendations table
$sql_health_recommendations = "CREATE TABLE IF NOT EXISTS health_recommendations (
    recommendation_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    recommendation_type ENUM('danger', 'warning', 'info', 'success') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    icon VARCHAR(100) NOT NULL,
    priority ENUM('critical', 'warning', 'info', 'success') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
)";

if ($conn->query($sql_health_recommendations) === TRUE) {
    echo "✅ Health recommendations table created successfully\n";
} else {
    echo "❌ Error creating health recommendations table: " . $conn->error . "\n";
}

// Health Recommendation Actions table (for storing action items)
$sql_recommendation_actions = "CREATE TABLE IF NOT EXISTS recommendation_actions (
    action_id INT AUTO_INCREMENT PRIMARY KEY,
    recommendation_id INT NOT NULL,
    action_text TEXT NOT NULL,
    action_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recommendation_id) REFERENCES health_recommendations(recommendation_id) ON DELETE CASCADE
)";

if ($conn->query($sql_recommendation_actions) === TRUE) {
    echo "✅ Recommendation actions table created successfully\n";
} else {
    echo "❌ Error creating recommendation actions table: " . $conn->error . "\n";
}

// Insert sample data for testing
echo "<p>🔧 Inserting sample data...</p>";

// Insert sample caretaker user
$caretaker_password = password_hash('caretaker123', PASSWORD_DEFAULT);
$sql = "INSERT IGNORE INTO users (email, password, username, first_name, last_name, user_type) 
        VALUES ('caretaker@example.com', ?, 'caretaker', 'John', 'Caretaker', 'caretaker')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $caretaker_password);
$stmt->execute();
echo "<p>✅ Inserted sample caretaker</p>";

// Insert sample doctor
$doctor_password = password_hash('doctor123', PASSWORD_DEFAULT);
$sql = "INSERT IGNORE INTO users (email, password, username, first_name, last_name, user_type) 
        VALUES ('doctor@example.com', ?, 'doctor', 'Dr. Sarah', 'Johnson', 'doctor')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $doctor_password);
$stmt->execute();

// Get doctor user_id and insert into doctors table
$doctor_user_id = $conn->insert_id;
if ($doctor_user_id) {
    $sql = "INSERT IGNORE INTO doctors (user_id, first_name, last_name, email, contact_number, specialization, license_number) 
            VALUES (?, 'Dr. Sarah', 'Johnson', 'doctor@example.com', '0987654321', 'Cardiology', 'MD123456')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $doctor_user_id);
    $stmt->execute();
    echo "<p>✅ Inserted sample doctor</p>";
}

// Insert sample patient
$patient_password = password_hash('patient123', PASSWORD_DEFAULT);
$sql = "INSERT IGNORE INTO users (email, password, username, first_name, last_name, user_type) 
        VALUES ('patient@example.com', ?, 'patient', 'Alice', 'Patient', 'patient')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $patient_password);
$stmt->execute();

// Get patient user_id and insert into patients table
$patient_user_id = $conn->insert_id;
if ($patient_user_id) {
    $sql = "INSERT IGNORE INTO patients (user_id, first_name, last_name, email, contact_number, date_of_birth, gender, address, emergency_contact) 
            VALUES (?, 'Alice', 'Patient', 'patient@example.com', '5551234567', '1985-05-15', 'Female', '123 Health St, City', '5559876543')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patient_user_id);
    $stmt->execute();
    echo "<p>✅ Inserted sample patient</p>";
    
    // Insert sample family member for this patient
    $sql = "INSERT IGNORE INTO family_members (patient_id, first_name, last_name, relationship, contact_number, email) 
            VALUES (?, 'John', 'Smith', 'Spouse', '5559876543', 'family@example.com')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patient_user_id);
    $stmt->execute();
    echo "<p>✅ Inserted sample family member</p>";
}

echo "<h3>🎉 Database setup completed successfully!</h3>";
echo "<ul>";
echo "<li><strong>Caretaker Login:</strong> caretaker@example.com / caretaker123</li>";
echo "<li><strong>Doctor Login:</strong> doctor@example.com / doctor123</li>";
echo "<li><strong>Patient Login:</strong> patient@example.com / patient123</li>";
echo "<li><strong>Family Member Login:</strong> family@example.com / family123</li>";
echo "</ul>";
echo "<p><a href='index.php'>Go to Homepage</a></p>";

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        h2, h3 {
            color: #333;
        }
        p {
            margin: 10px 0;
            padding: 10px;
            background: white;
            border-radius: 5px;
            border-left: 4px solid #007cba;
        }
        ul {
            background: white;
            padding: 20px;
            border-radius: 5px;
            border-left: 4px solid #28a745;
        }
        a {
            color: #007cba;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
</body>
</html> 