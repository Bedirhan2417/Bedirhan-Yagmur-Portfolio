<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

$caretaker_id = $_SESSION['user_id'];


$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM patients WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $caretaker_id);
$stmt->execute();
$patients_result = $stmt->get_result();

$patients = [];
while ($row = $patients_result->fetch_assoc()) {
    $patients[] = $row;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Locations</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }



        .container-fluid {
            padding: 2rem;
        }

        .header-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .header-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(37, 99, 235, 0.1);
        }

        .header-subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .map-container {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            margin-bottom: 2rem;
        }

        #map {
            height: 600px;
            border-radius: 15px;
            box-shadow: var(--shadow-lg);
            border: 2px solid var(--gray-200);
        }

        .patient-list-container {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            height: 100%;
        }

        .patient-list-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .patient-list-title {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.3rem;
            margin: 0;
        }

        .patient-count {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: var(--white);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .patient-item {
            background: var(--gray-100);
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 0.75rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }

        .patient-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 0;
        }

        .patient-item:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-color);
        }

        .patient-item:hover::before {
            opacity: 0.1;
        }

        .patient-item.active {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            border-color: var(--primary-color);
            box-shadow: var(--shadow-lg);
        }

        .patient-item.active::before {
            opacity: 0;
        }

        .patient-item-content {
            position: relative;
            z-index: 1;
        }

        .patient-item h5 {
            margin: 0;
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .patient-item p {
            margin: 0;
            font-size: 0.9rem;
            opacity: 0.8;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .patient-item i {
            width: 16px;
            text-align: center;
        }

        .custom-popup .leaflet-popup-content-wrapper {
            background: var(--white);
            border-radius: 15px;
            padding: 0;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .custom-popup .leaflet-popup-content {
            margin: 0;
            width: 320px !important;
        }

        .custom-popup .leaflet-popup-tip {
            background: var(--white);
            border: 1px solid var(--gray-200);
        }

        .popup-content {
            padding: 1.5rem;
        }



        .popup-content h4 {
            margin: 0 0 1rem;
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.2rem;
        }

        .popup-content p {
            margin: 0.5rem 0;
            font-size: 0.9rem;
            color: var(--gray-700);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .popup-content i {
            width: 16px;
            color: var(--primary-color);
            text-align: center;
        }

        .loading {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .loading-content {
            text-align: center;
            background: var(--white);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid var(--gray-200);
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }

        .loading-text {
            color: var(--gray-600);
            font-weight: 600;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }

        .stat-number {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--gray-600);
            font-weight: 600;
            font-size: 0.85rem;
        }

        .no-patients {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--gray-600);
        }

        .no-patients i {
            font-size: 3rem;
            color: var(--gray-400);
            margin-bottom: 1rem;
        }

        .no-patients h4 {
            color: var(--gray-700);
            margin-bottom: 0.5rem;
        }

        /* Custom marker styling */
        .custom-marker {
            background: none !important;
            border: none !important;
        }

        .custom-marker i {
            filter: drop-shadow(2px 2px 4px rgba(0,0,0,0.3));
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }

            .header-section {
                padding: 1.5rem;
            }

            .header-title {
                font-size: 2rem;
            }

            .map-container {
                padding: 1rem;
                margin-bottom: 1rem;
            }

            #map {
                height: 400px;
            }

            .patient-list-container {
                padding: 1rem;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }

        /* Animation for patient items */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .patient-item {
            animation: fadeInUp 0.6s ease forwards;
        }

        .patient-item:nth-child(1) { animation-delay: 0.1s; }
        .patient-item:nth-child(2) { animation-delay: 0.2s; }
        .patient-item:nth-child(3) { animation-delay: 0.3s; }
        .patient-item:nth-child(4) { animation-delay: 0.4s; }
        .patient-item:nth-child(5) { animation-delay: 0.5s; }
        .patient-item:nth-child(6) { animation-delay: 0.6s; }
    </style>
</head>
<body>
    <div class="container-fluid">
                
                <a href="caretaker_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>

        
        <div class="header-section">
            <h1 class="header-title">
                <i class="fas fa-map-marker-alt me-3"></i>
                Patient Locations Map
            </h1>
            <p class="header-subtitle">
                Track and monitor patient locations in real-time with interactive mapping
            </p>
        </div>

    
        <div class="stats-container" id="statsContainer">
            <div class="stat-card">
                <div class="stat-number" id="totalPatients">-</div>
                <div class="stat-label">Total Patients</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="activeLocations">-</div>
                <div class="stat-label">Active Locations</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="lastUpdate">-</div>
                <div class="stat-label">Last Updated</div>
            </div>
        </div>

   
        <div class="row">
            <div class="col-lg-8">
                <div class="map-container">
                    <div id="map"></div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="patient-list-container">
                    <div class="patient-list-header">
                        <h3 class="patient-list-title">
                            <i class="fas fa-users me-2"></i>
                            Patient List
                        </h3>
                        <span class="patient-count" id="patientCount">0</span>
                    </div>
                    <div id="patientList">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

  
    <div class="loading" id="loading">
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text">Loading patient locations...</div>
        </div>
    </div>

    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const map = L.map('map').setView([52.0, -1.0], 6);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            const markers = {};
            const bounds = L.latLngBounds();
            let patientData = [];

           
            fetch('get_locations.php')
                .then(response => response.json())
                .then(patients => {
                    patientData = patients;
                    
                    
                    updateStatistics(patients);
                    
                    
                    populatePatientList(patients);
                    
                    
                    addMarkersToMap(patients);
                    
                    if (!bounds.isEmpty()) {
                        map.fitBounds(bounds);
                    }

                    
                    document.getElementById('loading').style.display = 'none';
                })
                .catch(error => {
                    console.error('Error fetching patient data:', error);
                    document.getElementById('loading').style.display = 'none';
                    showError('Error loading patient data. Please try again later.');
                });

            function updateStatistics(patients) {
                const totalPatients = patients.length;
                const activeLocations = patients.filter(p => p.latitude && p.longitude).length;
                const lastUpdate = patients.length > 0 ? 
                    new Date(Math.max(...patients.map(p => new Date(p.timestamp || 0)))).toLocaleTimeString() : 
                    'No data';

                document.getElementById('totalPatients').textContent = totalPatients;
                document.getElementById('activeLocations').textContent = activeLocations;
                document.getElementById('lastUpdate').textContent = lastUpdate;
                document.getElementById('patientCount').textContent = totalPatients;
            }

            function populatePatientList(patients) {
                const patientList = document.getElementById('patientList');
                
                if (patients.length === 0) {
                    patientList.innerHTML = `
                        <div class="no-patients">
                            <i class="fas fa-users"></i>
                            <h4>No Patients Found</h4>
                            <p>No patient location data is currently available.</p>
                        </div>
                    `;
                    return;
                }

                patients.forEach((patient, index) => {
                    const patientItem = document.createElement('div');
                    patientItem.className = 'patient-item';
                    patientItem.dataset.lat = patient.latitude;
                    patientItem.dataset.lng = patient.longitude;
                    patientItem.style.animationDelay = `${index * 0.1}s`;
                    
                    const hasLocation = patient.latitude && patient.longitude;
                    const timestamp = patient.timestamp ? new Date(patient.timestamp).toLocaleString('en-US') : 'No location data';
                    
                    patientItem.innerHTML = `
                        <div class="patient-item-content">
                            <h5>${patient.first_name} ${patient.last_name}</h5>
                            <p>
                                <i class="fas fa-clock"></i>
                                ${timestamp}
                            </p>
                            ${hasLocation ? '<p><i class="fas fa-map-marker-alt"></i> Location Available</p>' : '<p><i class="fas fa-exclamation-triangle"></i> No Location Data</p>'}
                        </div>
                    `;
                    
                    patientList.appendChild(patientItem);

                    
                    if (hasLocation) {
                        patientItem.addEventListener('click', function() {
                            map.setView([patient.latitude, patient.longitude], 15);
                            
                            
                            document.querySelectorAll('.patient-item').forEach(i => i.classList.remove('active'));
                            this.classList.add('active');

                            
                            if (markers[patient.patient_id]) {
                                markers[patient.patient_id].openPopup();
                            }
                        });
                    }
                });
            }

            function addMarkersToMap(patients) {
                patients.forEach(patient => {
                    if (patient.latitude && patient.longitude) {
                        const marker = L.marker([patient.latitude, patient.longitude], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: `<i class="fas fa-user-md" style="color: #ef4444; font-size: 24px;"></i>`,
                                iconSize: [24, 24]
                            })
                        });

                        const popupContent = `
                            <div class="popup-content">
                                <h4>${patient.first_name} ${patient.last_name}</h4>
                                <p><i class="fas fa-map-marker-alt"></i> ${patient.location_name || 'No location information'}</p>
                                <p><i class="fas fa-clock"></i> ${patient.timestamp ? new Date(patient.timestamp).toLocaleString('en-US') : 'No timestamp available'}</p>
                                <p><i class="fas fa-user"></i> Patient ID: ${patient.patient_id}</p>
                            </div>
                        `;

                        marker.bindPopup(popupContent, {
                            className: 'custom-popup'
                        });

                        marker.addTo(map);
                        markers[patient.patient_id] = marker;
                        bounds.extend([patient.latitude, patient.longitude]);
                    }
                });
            }

            function showError(message) {
                const errorDiv = document.createElement('div');
                errorDiv.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #ef4444;
                    color: white;
                    padding: 1rem 1.5rem;
                    border-radius: 10px;
                    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
                    z-index: 1001;
                    animation: slideIn 0.3s ease;
                `;
                errorDiv.textContent = message;
                document.body.appendChild(errorDiv);

                setTimeout(() => {
                    errorDiv.remove();
                }, 5000);
            }

            
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    document.querySelectorAll('.patient-item').forEach(i => i.classList.remove('active'));
                }
            });
        });
    </script>
</body>
</html> 