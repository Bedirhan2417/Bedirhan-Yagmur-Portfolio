<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

require_once 'config.php';

$caretaker_id = $_SESSION['user_id'];


$sql = "SELECT fm.*, p.first_name as patient_first_name, p.last_name as patient_last_name 
        FROM family_members fm 
        JOIN patients p ON fm.patient_id = p.patient_id 
        WHERE p.user_id = ?
        ORDER BY fm.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $caretaker_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Family Members Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }



        .container-fluid {
            padding: 2rem;
        }

        .header-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .header-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(37, 99, 235, 0.1);
        }

        .header-subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .search-container {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .search-box {
            position: relative;
            background: var(--gray-100);
            border-radius: 15px;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .search-box:focus-within {
            background: var(--white);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .search-box input {
            border: none;
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 1rem;
            color: var(--gray-800);
        }

        .search-box input::placeholder {
            color: var(--gray-600);
        }

        .search-icon {
            color: var(--primary-color);
            font-size: 1.2rem;
        }

        .add-btn {
            background: linear-gradient(135deg, var(--success-color), #059669);
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .family-card {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            position: relative;
        }

        .family-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            padding: 1.5rem;
            color: var(--white);
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
            transform: translateX(-100%);
            transition: transform 0.6s ease;
        }

        .family-card:hover .card-header::before {
            transform: translateX(100%);
        }

        .card-header h5 {
            margin: 0;
            font-weight: 700;
            font-size: 1.3rem;
            position: relative;
            z-index: 1;
        }

        .card-header small {
            opacity: 0.9;
            font-weight: 500;
            position: relative;
            z-index: 1;
        }

        .card-body {
            padding: 1.5rem;
        }

        .info-group {
            margin-bottom: 1.25rem;
        }

        .info-label {
            color: var(--gray-600);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }

        .info-value {
            color: var(--gray-800);
            font-weight: 600;
            font-size: 1rem;
        }

        .emergency-badge {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            color: var(--white);
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: var(--shadow-sm);
            margin-bottom: 1rem;
        }

        .contact-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.75rem;
            padding: 0.75rem;
            background: var(--gray-100);
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .contact-info:hover {
            background: var(--gray-200);
            transform: translateX(5px);
        }

        .contact-info i {
            color: var(--primary-color);
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }

        .contact-info span {
            color: var(--gray-700);
            font-weight: 500;
        }

        .action-buttons {
            display: flex;
            gap: 0.75rem;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px solid var(--gray-200);
        }

        .btn-action {
            flex: 1;
            padding: 0.75rem 1rem;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn-edit {
            color: var(--white);
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .btn-delete {
            color: var(--white);
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
        }

        .btn-edit:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: var(--white);
        }

        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: var(--white);
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: var(--white);
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            opacity: 0.7;
        }

        .empty-state h4 {
            color: var(--gray-800);
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .empty-state p {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--gray-600);
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* Animation for cards */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .family-card-wrapper {
            animation: fadeInUp 0.6s ease forwards;
        }

        .family-card-wrapper:nth-child(1) { animation-delay: 0.1s; }
        .family-card-wrapper:nth-child(2) { animation-delay: 0.2s; }
        .family-card-wrapper:nth-child(3) { animation-delay: 0.3s; }
        .family-card-wrapper:nth-child(4) { animation-delay: 0.4s; }
        .family-card-wrapper:nth-child(5) { animation-delay: 0.5s; }
        .family-card-wrapper:nth-child(6) { animation-delay: 0.6s; }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }

            .header-section {
                padding: 1.5rem;
            }

            .header-title {
                font-size: 2rem;
            }

            .search-container {
                padding: 1rem;
            }

            .action-buttons {
                flex-direction: column;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }

        /* Loading animation */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid var(--gray-200);
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
                
                <a href="caretaker_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>

        
        <div class="header-section">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h1 class="header-title">
                        <i class="fas fa-users me-3"></i>
                        Family Members
                    </h1>
                    <p class="header-subtitle">
                        Manage patient family contacts and emergency information with ease
                    </p>
                </div>
                <button class="add-btn" onclick="window.location.href='add_family_member.php'">
                    <i class="fas fa-user-plus"></i>
                    Add New Member
                </button>
            </div>
        </div>

        
        <?php 
        $total_members = $result->num_rows;
        $emergency_contacts = 0;
        $result->data_seek(0);
        while ($row = $result->fetch_assoc()) {
            if ($row['emergency_contact']) {
                $emergency_contacts++;
            }
        }
        $result->data_seek(0);
        ?>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-number"><?php echo $emergency_contacts; ?></div>
                <div class="stat-label">Emergency Contacts</div>
            </div>
        </div>

        
        <div class="search-container">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" placeholder="Search by name, relationship, or contact information...">
            </div>
        </div>

        
        <?php if ($result->num_rows == 0): ?>
            <div class="empty-state">
                <i class="fas fa-users"></i>
                <h4>No Family Members Yet</h4>
                <p>Start by adding family members to manage patient contacts and emergency information effectively.</p>
                <button class="add-btn" onclick="window.location.href='add_family_member.php'">
                    <i class="fas fa-user-plus"></i>
                    Add First Member
                </button>
            </div>
        <?php else: ?>
            <div class="row g-4" id="familyList">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col-md-6 col-lg-4 family-card-wrapper">
                        <div class="family-card">
                            <div class="card-header">
                                <h5><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></h5>
                                <small>
                                    <i class="fas fa-user-circle me-1"></i>
                                    <?php echo htmlspecialchars($row['relationship']); ?>
                                </small>
                            </div>
                            <div class="card-body">
                                <?php if ($row['emergency_contact']): ?>
                                    <div class="emergency-badge">
                                        <i class="fas fa-star"></i>
                                        Primary Emergency Contact
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (isset($row['patient_first_name'])): ?>
                                    <div class="contact-info">
                                        <i class="fas fa-hospital-user"></i>
                                        <span>Patient: <?php echo htmlspecialchars($row['patient_first_name'] . ' ' . $row['patient_last_name']); ?></span>
                                    </div>
                                <?php endif; ?>

                                <div class="contact-info">
                                    <i class="fas fa-phone"></i>
                                    <span><?php echo htmlspecialchars($row['phone']); ?></span>
                                </div>
                                
                                <div class="contact-info">
                                    <i class="fas fa-envelope"></i>
                                    <span><?php echo htmlspecialchars($row['email']); ?></span>
                                </div>

                                <div class="info-group">
                                    <div class="info-label">Notification Preferences</div>
                                    <div class="info-value">
                                        <?php echo htmlspecialchars($row['notification_preferences'] ?: 'Not configured'); ?>
                                    </div>
                                </div>

                                <div class="action-buttons">
                                    <button class="btn btn-action btn-edit" onclick="window.location.href='edit_family_member.php?id=<?php echo $row['member_id']; ?>'">
                                        <i class="fas fa-edit"></i>
                                        Edit
                                    </button>
                                    <button class="btn btn-action btn-delete" onclick="confirmDelete(<?php echo $row['member_id']; ?>, '<?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
            </div>
        </div>
    </div>

    <script>

        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const searchTerm = this.value.toLowerCase();
                const cards = document.querySelectorAll('.family-card-wrapper');

                cards.forEach(card => {
                    const content = card.textContent.toLowerCase();
                    const isVisible = content.includes(searchTerm);
                    
                    if (isVisible) {
                        card.style.display = '';
                        card.style.animation = 'fadeInUp 0.5s ease';
                    } else {
                        card.style.display = 'none';
                    }
                });

        
                const visibleCards = document.querySelectorAll('.family-card-wrapper[style=""]');
                const emptyState = document.querySelector('.empty-state');
                if (emptyState) {
                    if (visibleCards.length === 0 && searchTerm !== '') {
                        emptyState.style.display = 'block';
                        emptyState.innerHTML = `
                            <i class="fas fa-search"></i>
                            <h4>No Results Found</h4>
                            <p>Try adjusting your search terms or browse all family members.</p>
                        `;
                    } else {
                        emptyState.style.display = 'none';
                    }
                }
            }, 300);
        });


        function confirmDelete(memberId, memberName) {
            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
                backdrop-filter: blur(5px);
            `;
            
            modal.innerHTML = `
                <div style="
                    background: white;
                    padding: 2rem;
                    border-radius: 15px;
                    max-width: 400px;
                    text-align: center;
                    box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
                ">
                    <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #ef4444; margin-bottom: 1rem;"></i>
                    <h4 style="margin-bottom: 1rem; color: #1e293b;">Confirm Deletion</h4>
                    <p style="color: #64748b; margin-bottom: 2rem;">Are you sure you want to delete <strong>${memberName}</strong>? This action cannot be undone.</p>
                    <div style="display: flex; gap: 1rem; justify-content: center;">
                        <button onclick="this.closest('div[style*=\"position: fixed\"]').remove()" style="
                            padding: 0.75rem 1.5rem;
                            border: none;
                            border-radius: 8px;
                            background: #e2e8f0;
                            color: #475569;
                            cursor: pointer;
                            font-weight: 600;
                        ">Cancel</button>
                        <button onclick="window.location.href='delete_family_member.php?id=${memberId}'" style="
                            padding: 0.75rem 1.5rem;
                            border: none;
                            border-radius: 8px;
                            background: #ef4444;
                            color: white;
                            cursor: pointer;
                            font-weight: 600;
                        ">Delete</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
        }


        window.addEventListener('load', function() {
            const cards = document.querySelectorAll('.family-card-wrapper');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html> 