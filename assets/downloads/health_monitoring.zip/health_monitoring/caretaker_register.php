<?php
session_start();
include('config.php');

if (isset($_SESSION['user_id'])) {
    header('Location: caretaker_dashboard.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $user_type = 'caretaker';

    if (empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
        $error = "Please fill in all fields.";
    } else {
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "❌ This email is already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (email, password, first_name, last_name, user_type) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $email, $hashed_password, $first_name, $last_name, $user_type);

            if ($stmt->execute()) {
                $caretaker_id = $conn->insert_id;
                
            
                $assign_patients = $conn->query("SELECT user_id FROM users WHERE user_type = 'patient' LIMIT 5");
                while ($patient = $assign_patients->fetch_assoc()) {
                    $assign_sql = "INSERT INTO caretaker_patients (caretaker_id, patient_id, status) VALUES (?, ?, 'active')";
                    $assign_stmt = $conn->prepare($assign_sql);
                    $assign_stmt->bind_param("ii", $caretaker_id, $patient['user_id']);
                    $assign_stmt->execute();
                }
                
                $success = "🎉 Registration successful! <a href='caretaker_login.php' class='alert-link'>Login here</a>";
            } else {
                $error = "❌ An error occurred during registration: " . $stmt->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Caretaker Registration - Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        body {
            background: linear-gradient(135deg, #00416A, #E4E5E6);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            pointer-events: none;
        }

        .register-container {
            width: 100%;
            max-width: 500px;
            perspective: 1000px;
        }

        .register-box {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            width: 100%;
            backdrop-filter: blur(10px);
            transform-style: preserve-3d;
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        .logo-icon {
            font-size: 3rem;
            background: linear-gradient(45deg, #00416A, #E4E5E6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .logo-text {
            font-size: 2rem;
            font-weight: 700;
            color: #00416A;
            margin-bottom: 5px;
        }

        .input-group {
            position: relative;
            margin-bottom: 25px;
        }

        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #00416A;
            font-size: 1.2rem;
            z-index: 10;
        }

        .form-control {
            border: 2px solid #e1e1e1;
            border-radius: 12px;
            padding: 12px 20px 12px 45px;
            height: auto;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
        }

        .form-control:focus {
            border-color: #00416A;
            box-shadow: 0 0 0 0.2rem rgba(0, 65, 106, 0.1);
            transform: translateY(-2px);
        }

        .btn-register {
            background: linear-gradient(45deg, #00416A, #0078b4);
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 65, 106, 0.3);
        }

        .btn-register::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), transparent);
            transform: rotate(45deg);
            transition: all 0.3s ease;
        }

        .btn-register:hover::after {
            transform: rotate(45deg) translate(50%, 50%);
        }

        .alert {
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 25px;
            border: none;
            font-weight: 500;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .alert-danger {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .form-label {
            font-weight: 500;
            color: #00416A;
            margin-bottom: 8px;
            display: block;
        }

        .login-link {
            color: #00416A;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .login-link:hover {
            color: #0078b4;
            text-decoration: underline;
        }

        .progress-steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }

        .progress-step {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: #e1e1e1;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #fff;
            position: relative;
            z-index: 1;
        }

        .progress-step.active {
            background: #00416A;
        }

        .progress-line {
            position: absolute;
            top: 17px;
            left: 0;
            right: 0;
            height: 2px;
            background: #e1e1e1;
            z-index: 0;
        }

        @media (max-width: 576px) {
            .register-box {
                padding: 30px 20px;
            }

            .logo-text {
                font-size: 1.75rem;
            }
        }
    </style>
</head>
<body>

<div class="register-container">
    <div class="register-box">
        <div class="text-center mb-4">
            <i class="fas fa-user-md logo-icon"></i>
            <div class="logo-text">Caretaker Registration</div>
            <p class="text-muted">Join our healthcare monitoring system</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger text-center">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success text-center">
                <i class="fas fa-check-circle me-2"></i>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="caretaker_register.php" novalidate>
            <div class="input-group">
                <i class="fas fa-envelope input-icon"></i>
                <input type="email" 
                       class="form-control" 
                       id="email" 
                       name="email" 
                       placeholder="Enter your email"
                       value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                       required />
            </div>

            <div class="input-group">
                <i class="fas fa-lock input-icon"></i>
                <input type="password" 
                       class="form-control" 
                       id="password" 
                       name="password" 
                       placeholder="Create a password"
                       required />
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="input-group">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" 
                               class="form-control" 
                               id="first_name" 
                               name="first_name" 
                               placeholder="First name"
                               value="<?= isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : '' ?>"
                               required />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" 
                               class="form-control" 
                               id="last_name" 
                               name="last_name" 
                               placeholder="Last name"
                               value="<?= isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : '' ?>"
                               required />
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-register w-100 mb-3">
                <i class="fas fa-user-plus me-2"></i>Create Account
            </button>

            <div class="text-center">
                <p class="mb-0">Already have an account? 
                    <a href="caretaker_login.php" class="login-link">Login here</a>
                </p>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 