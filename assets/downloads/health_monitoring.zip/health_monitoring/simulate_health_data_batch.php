<?php
session_start();

$logged_in_user_id = null;
$logged_in_user_type = null;

if (isset($_SESSION['user_id']) && isset($_SESSION['user_type'])) {
    $logged_in_user_id = $_SESSION['user_id'];
    $logged_in_user_type = $_SESSION['user_type'];
    echo "🔐 Detected logged-in user: ID=$logged_in_user_id, Type=$logged_in_user_type\n\n";
} else {
    echo "⚠️ No active session detected. Will process all caretakers.\n\n";
}

require_once 'config.php';

if ($logged_in_user_id && $logged_in_user_type === 'caretaker') {
    $caretakers = [$logged_in_user_id];
    echo "📊 Processing only for logged-in caretaker ID: $logged_in_user_id\n\n";
} else {
    $caretaker_query = "SELECT user_id FROM users WHERE user_type = 'caretaker'";
    $caretaker_result = $conn->query($caretaker_query);

    if (!$caretaker_result) {
        die("❌ Error getting caretakers: " . $conn->error);
    }

    $caretakers = [];
    while ($row = $caretaker_result->fetch_assoc()) {
        $caretakers[] = $row['user_id'];
    }

    if (empty($caretakers)) {
        die("❌ No caretakers found in the system");
    }

    echo "📊 Found " . count($caretakers) . " caretakers in the system\n";
    foreach ($caretakers as $caretaker_id) {
        echo "   - Caretaker ID: $caretaker_id\n";
    }
    echo "\n";
}

$first_names_male = ['James', 'John', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Joseph', 'Thomas', 'Charles', 'Christopher', 'Daniel', 'Matthew', 'Anthony', 'Mark', 'Donald', 'Steven', 'Paul', 'Andrew', 'Joshua'];
$first_names_female = ['Mary', 'Patricia', 'Jennifer', 'Linda', 'Elizabeth', 'Barbara', 'Susan', 'Jessica', 'Sarah', 'Karen', 'Nancy', 'Lisa', 'Betty', 'Helen', 'Sandra', 'Donna', 'Carol', 'Ruth', 'Sharon', 'Michelle'];
$last_names = ['Smith', 'Johnson', 'Brown', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'White', 'Harris', 'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson', 'Clark', 'Rodriguez', 'Lewis', 'Lee', 'Walker', 'Hall'];

$addresses = [
    '221B Baker Street, London, W1U 6AH',
    '10 Downing Street, London, SW1A 2AA',
    '5 Manchester Square, Manchester, M1 1AA',
    '1 Birmingham Street, Birmingham, B1 1AA',
    '50 Oxford Street, London, W1D 1BS',
    '123 High Street, Birmingham, B1 1AA',
    '15 Liverpool Road, Liverpool, L1 1AA',
    '25 Leeds Street, Leeds, LS1 1AA',
    '8 Edinburgh Way, Edinburgh, EH1 1AA',
    '12 Bristol Avenue, Bristol, BS1 1AA',
    '30 Cardiff Street, Cardiff, CF1 1AA',
    '45 Glasgow Road, Glasgow, G1 1AA',
    '7 Sheffield Lane, Sheffield, S1 1AA',
    '18 Newcastle Drive, Newcastle, NE1 1AA',
    '22 Nottingham Place, Nottingham, NG1 1AA'
];

$medical_histories = [
    'No significant medical history. Patient is generally healthy.',
    'Diabetes Type 2 diagnosed in 2015. Currently managed with diet and medication.',
    'History of hypertension and asthma. Regular medication required.',
    'Allergic to penicillin and shellfish. No other known allergies.',
    'Previous surgery: appendectomy in 2010. Recovery was uneventful.',
    'Chronic back pain reported. Under physiotherapy treatment.',
    'Undergoing treatment for thyroid disorder. Regular blood tests required.',
    'History of heart disease in family. Regular cardiac checkups.',
    'Mild arthritis in knees. Pain management with over-the-counter medication.',
    'Previous fracture of left wrist in 2018. Fully recovered.',
    'Seasonal allergies to pollen. Uses antihistamines as needed.',
    'Sleep apnea diagnosed in 2019. Uses CPAP machine.',
    'History of depression. Under psychiatric care.',
    'Mild hearing loss in right ear. No treatment required.',
    'Asthma since childhood. Uses inhaler as prescribed.'
];

function randomDate($start_date, $end_date) {
    $min = strtotime($start_date);
    $max = strtotime($end_date);
    $val = rand($min, $max);
    return date('Y-m-d', $val);
}

$uk_locations = [
    ['name' => 'London', 'lat' => 51.5074, 'lng' => -0.1278],
    ['name' => 'Manchester', 'lat' => 53.4808, 'lng' => -2.2426],
    ['name' => 'Birmingham', 'lat' => 52.4862, 'lng' => -1.8904],
    ['name' => 'Liverpool', 'lat' => 53.4084, 'lng' => -2.9916],
    ['name' => 'Leeds', 'lat' => 53.8008, 'lng' => -1.5491],
    ['name' => 'Sheffield', 'lat' => 53.3811, 'lng' => -1.4701],
    ['name' => 'Edinburgh', 'lat' => 55.9533, 'lng' => -3.1883],
    ['name' => 'Bristol', 'lat' => 51.4545, 'lng' => -2.5879],
    ['name' => 'Cardiff', 'lat' => 51.4816, 'lng' => -3.1791],
    ['name' => 'Glasgow', 'lat' => 55.8642, 'lng' => -4.2518]
];

$total_patients_added = 0;

foreach ($caretakers as $caretaker_id) {
    echo "🔐 Processing Caretaker ID: $caretaker_id\n";
    
    try {
        $conn->begin_transaction();

        $check_count_sql = "SELECT COUNT(*) as patient_count FROM patients WHERE user_id = ?";
        $check_count_stmt = $conn->prepare($check_count_sql);
        $check_count_stmt->bind_param("i", $caretaker_id);
        $check_count_stmt->execute();
        $count_result = $check_count_stmt->get_result();
        $patient_count = $count_result->fetch_assoc()['patient_count'];
        
        echo "📈 Current patient count for this caretaker: $patient_count\n";
        
        $gender = rand(0, 1) ? 'Male' : 'Female';

        if ($gender == 'Male') {
            $first_name = $first_names_male[array_rand($first_names_male)];
        } else {
            $first_name = $first_names_female[array_rand($first_names_female)];
        }

        $last_name = $last_names[array_rand($last_names)];

        $date_of_birth = randomDate('1925-01-01', '1965-12-31');

        $uk_area_codes = ['20', '21', '24', '28', '29', '11', '12', '13', '14', '15', '16', '17', '18', '19'];
        $area_code = $uk_area_codes[array_rand($uk_area_codes)];
        $contact_number = '+44' . $area_code . rand(10000000, 99999999);

        $email = strtolower($first_name . '.' . $last_name . '@example.com');

        $address = $addresses[array_rand($addresses)];
        $medical_history = $medical_histories[array_rand($medical_histories)];

        $check_sql = "SELECT patient_id FROM patients WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            echo "⚠️ Email already exists for $first_name $last_name, skipping...\n";
            continue;
        }

        $patient_sql = "INSERT INTO patients (first_name, last_name, date_of_birth, gender, contact_number, email, address, medical_history, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $patient_stmt = $conn->prepare($patient_sql);
        $patient_stmt->bind_param("ssssssssi", $first_name, $last_name, $date_of_birth, $gender, $contact_number, $email, $address, $medical_history, $caretaker_id);

        if (!$patient_stmt->execute()) {
            throw new Exception("❌ Error adding patient: " . $patient_stmt->error);
        }

        $patient_id = $conn->insert_id;
        echo "✅ New patient added: $first_name $last_name (ID: $patient_id)\n";

        $heart_rate = rand(65, 95);
        $blood_pressure_systolic = rand(100, 130);
        $blood_pressure_diastolic = rand(65, 85);
        $blood_pressure = $blood_pressure_systolic . '/' . $blood_pressure_diastolic . ' mmHg';
        $step_count = rand(8000, 15000);
        $oxygen_level = rand(96, 99);
        $body_temperature = rand(365, 375) / 10;
        $fall_detected = 0;

        $health_sql = "INSERT INTO health_data (patient_id, heart_rate, blood_pressure, step_count, oxygen_level, body_temperature, fall_detected, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        $health_stmt = $conn->prepare($health_sql);
        $health_stmt->bind_param("isiiids", $patient_id, $heart_rate, $blood_pressure, $step_count, $oxygen_level, $body_temperature, $fall_detected);

        if (!$health_stmt->execute()) {
            throw new Exception("❌ Error adding health data: " . $health_stmt->error);
        }

        echo "✅ Normal health data added for $first_name $last_name\n";

        $location = $uk_locations[array_rand($uk_locations)];
        $location_lat = $location['lat'] + (rand(-100, 100) / 1000);
        $location_lng = $location['lng'] + (rand(-100, 100) / 1000);

        $location_sql = "INSERT INTO patient_locations (patient_id, latitude, longitude, timestamp) VALUES (?, ?, ?, NOW())";
        $location_stmt = $conn->prepare($location_sql);
        $location_stmt->bind_param("idd", $patient_id, $location_lat, $location_lng);

        if (!$location_stmt->execute()) {
            throw new Exception("❌ Error adding location data: " . $location_stmt->error);
        }

        echo "✅ Location data added for $first_name $last_name\n";

        $conn->commit();
        echo "🎉 All data successfully added for $first_name $last_name!\n";
        echo "📊 New patient count for this caretaker: " . ($patient_count + 1) . "\n\n";
        
        $total_patients_added++;

    } catch (Exception $e) {
        $conn->rollback();
        echo "❌ Error for Caretaker $caretaker_id: " . $e->getMessage() . "\n\n";
    } finally {
        if (isset($check_count_stmt)) $check_count_stmt->close();
        if (isset($check_stmt)) $check_stmt->close();
        if (isset($patient_stmt)) $patient_stmt->close();
        if (isset($health_stmt)) $health_stmt->close();
        if (isset($location_stmt)) $location_stmt->close();
    }
}

echo "🎉 Simulation completed!\n";
echo "📊 Total patients added: $total_patients_added\n";
echo "👥 Processed " . count($caretakers) . " caretakers\n";
?>
