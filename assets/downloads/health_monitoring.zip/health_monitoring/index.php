<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Healthcare Monitoring System - Caretaker Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="animations.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        body {
            background: linear-gradient(135deg, #00416A, #E4E5E6);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="%23FFFFFF10" d="M42.7,-68.2C54.9,-62.3,64.2,-49.7,69.5,-35.8C74.8,-21.9,76.2,-6.7,73.7,7.8C71.2,22.3,64.8,36.2,54.8,46.6C44.8,57,31.1,64,16.9,66.5C2.7,69,-11.9,67,-24.9,61.5C-37.9,56,-49.3,47,-57.6,35.3C-65.9,23.5,-71.1,9,-69.7,-4.8C-68.3,-18.7,-60.3,-31.9,-49.8,-38.8C-39.3,-45.7,-26.3,-46.3,-14.6,-52.5C-2.8,-58.7,7.7,-70.5,21.2,-74.4C34.7,-78.3,51.2,-74.4,42.7,-68.2Z" transform="translate(100 100)" /></svg>') no-repeat center center;
            opacity: 0.1;
            z-index: -1;
        }

        .welcome-card {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 50px 30px;
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            text-align: center;
            backdrop-filter: blur(10px);
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        h1 {
            font-weight: 700;
            color: #00416A;
            margin-bottom: 20px;
            font-size: 2.5rem;
        }

        .lead {
            color: #5D6D7E;
            margin-bottom: 40px;
            font-size: 1.25rem;
            font-weight: 400;
        }

        .main-icon {
            font-size: 4rem;
            background: linear-gradient(45deg, #00416A, #0078b4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 20px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            margin: 40px 0;
            padding: 0 20px;
        }

        .feature-item {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            transition: transform 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .feature-item:hover {
            transform: translateY(-5px);
        }

        .feature-item i {
            font-size: 2rem;
            color: #00416A;
            margin-bottom: 15px;
        }

        .feature-item h3 {
            color: #2C3E50;
            font-size: 1.2rem;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .feature-item p {
            color: #5D6D7E;
            font-size: 0.9rem;
            line-height: 1.5;
        }

        .btn-custom {
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            margin: 8px;
            min-width: 200px;
            position: relative;
            overflow: hidden;
        }

        .btn-custom::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), transparent);
            transform: rotate(45deg);
            transition: all 0.3s ease;
        }

        .btn-custom:hover::after {
            transform: rotate(45deg) translate(50%, 50%);
        }

        .btn-primary {
            background: linear-gradient(45deg, #00416A, #0078b4);
            border: none;
            box-shadow: 0 4px 15px rgba(0, 65, 106, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 65, 106, 0.3);
        }

        .btn-outline-primary {
            background: transparent;
            border: 2px solid #00416A;
            color: #00416A;
        }

        .btn-outline-primary:hover {
            background: #00416A;
            color: white;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .welcome-card {
                padding: 30px 20px;
            }

            h1 {
                font-size: 2rem;
            }

            .features-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }

        .btn-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .login-options {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            justify-content: center;
        }

        .login-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
            padding: 2rem;
            border-radius: var(--border-radius);
            text-decoration: none;
            transition: var(--transition);
            min-width: 200px;
            border: 2px solid transparent;
        }

        .login-btn.caretaker {
            background: #00416A;
            color: #fff;
            border: 2px solid #00416A;
        }
        .login-btn.caretaker:hover {
            background: #0078b4;
            color: #fff;
            border: 2px solid #0078b4;
        }

        .login-btn.patient {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
        }

        .login-btn.family {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .login-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            color: white;
            text-decoration: none;
        }

        .login-btn i {
            font-size: 2.5rem;
        }

        .login-btn span {
            font-size: 1.1rem;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="welcome-card">
        <i class="fas fa-user-md main-icon"></i>
        <h1>Healthcare Monitoring System</h1>
        <p class="lead">Empowering healthcare professionals and families with advanced monitoring tools</p>

        <div class="features-grid">
            <div class="feature-item">
                <i class="fas fa-heartbeat"></i>
                <h3>Real-time Monitoring</h3>
                <p>Monitor patient vitals and health metrics in real-time</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-bell"></i>
                <h3>Instant Alerts</h3>
                <p>Receive immediate notifications for critical situations</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-chart-line"></i>
                <h3>Health Analytics</h3>
                <p>Access detailed patient health analytics and reports</p>
            </div>
        </div>

        <div class="login-options">
            <a href="caretaker_login.php" class="login-btn caretaker">
                <i class="fas fa-user-nurse"></i>
                <span>Caretaker Login</span>
            </a>
        </div>

        <div class="button-group">
            <a href="caretaker_register.php" class="btn btn-outline-primary btn-custom">
                <i class="fas fa-user-plus me-2"></i>Caretaker Register
            </a>
        </div>
        
        <div class="alert alert-warning mt-5" role="alert">
            <i class="fas fa-shield-alt me-2"></i>
            <strong>Security & Privacy:</strong> All your data is kept confidential and stored on secure servers. Your personal information is never shared with third parties.
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 