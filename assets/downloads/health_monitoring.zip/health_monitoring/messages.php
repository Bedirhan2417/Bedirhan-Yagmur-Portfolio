<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

include('config.php');

$caretaker_id = $_SESSION['user_id'];


$patients_result = mysqli_query($conn, "
    SELECT 
        p.patient_id, 
        p.first_name, 
        p.last_name,
        p.gender,
        m.message as last_message,
        m.message_date as last_message_time,
        m.is_read,
        (SELECT COUNT(*) FROM messages 
         WHERE patient_id = p.patient_id 
         AND is_read = 0) as unread_count
    FROM patients p
    LEFT JOIN (
        SELECT 
            patient_id,
            message,
            message_date,
            is_read
        FROM messages m1
        WHERE message_date = (
            SELECT MAX(message_date)
            FROM messages m2
            WHERE m1.patient_id = m2.patient_id
        )
    ) m ON p.patient_id = m.patient_id
    WHERE p.user_id = $caretaker_id
    ORDER BY m.message_date DESC
");

if (!$patients_result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Messages | Health Monitoring System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
            padding: 2rem;
        }



        .page-header {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%);
            pointer-events: none;
        }

        .page-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .page-header p {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin: 0;
        }

        .search-container {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .search-box {
            position: relative;
            max-width: 500px;
        }

        .search-box input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            border: 2px solid var(--gray-200);
            border-radius: 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--gray-100);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary-color);
            background: var(--white);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-600);
            font-size: 1.1rem;
        }

        .messages-container {
            background: var(--white);
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            overflow: hidden;
        }

        .messages-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .messages-header h3 {
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-count {
            background: rgba(255, 255, 255, 0.2);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .message-list {
            max-height: calc(100vh - 400px);
            overflow-y: auto;
        }

        .message-item {
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--gray-200);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: inherit;
            position: relative;
            background: var(--white);
        }

        .message-item:hover {
            background: var(--gray-100);
            transform: translateX(5px);
            box-shadow: var(--shadow-md);
        }

        .message-item:last-child {
            border-bottom: none;
        }

        .avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1.2rem;
            margin-right: 20px;
            box-shadow: var(--shadow-md);
            position: relative;
        }





        .message-content {
            flex: 1;
            min-width: 0;
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .patient-name {
            font-weight: 600;
            color: var(--gray-800);
            font-size: 1.1rem;
        }

        .message-time {
            font-size: 0.85rem;
            color: var(--gray-600);
            font-weight: 500;
        }

        .message-preview {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .last-message {
            color: var(--gray-600);
            font-size: 0.95rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            flex: 1;
        }

        .unread-badge {
            background: linear-gradient(135deg, var(--danger-color) 0%, #dc2626 100%);
            color: white;
            border-radius: 20px;
            padding: 4px 10px;
            font-size: 0.75rem;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .unread-message {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%);
            border-left: 4px solid var(--primary-color);
        }

        .unread-message .patient-name {
            color: var(--primary-color);
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray-600);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 1rem;
        }

        .empty-state h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 0;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--gray-600) 0%, var(--gray-700) 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        @media (max-width: 768px) {
            body {
                padding: 1rem;
            }
            .page-header h1 {
                font-size: 2rem;
            }
            .message-item {
                padding: 1rem;
            }
            .avatar {
                width: 50px;
                height: 50px;
                font-size: 1rem;
            }
        }

        /* Custom scrollbar */
        .message-list::-webkit-scrollbar {
            width: 8px;
        }

        .message-list::-webkit-scrollbar-track {
            background: var(--gray-100);
        }

        .message-list::-webkit-scrollbar-thumb {
            background: var(--gray-300);
            border-radius: 4px;
        }

        .message-list::-webkit-scrollbar-thumb:hover {
            background: var(--gray-400);
        }
    </style>
</head>
<body>
        <div class="main-content">
            
            <a href="caretaker_dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i>
                Back to Dashboard
            </a>

            
            <div class="page-header">
                <h1><i class="fas fa-comments"></i> Messages</h1>
                <p>Communicate with your patients and manage conversations</p>
            </div>

           
            <div class="search-container">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search patients by name..." class="form-control">
                </div>
            </div>

          
        <div class="messages-container">
                <div class="messages-header">
                    <h3><i class="fas fa-inbox"></i> Patient Conversations</h3>
                    <span class="message-count">
                        <?php 
                       
                        $tempCount = 0;
                        $tempResult = mysqli_query($conn, "SELECT COUNT(*) as total FROM patients WHERE user_id = $caretaker_id");
                        if ($tempResult) {
                            $tempCount = $tempResult->fetch_assoc()['total'];
                        }
                        echo $tempCount . ' patients';
                        ?>
                    </span>
                </div>

            <div class="message-list">
                    <?php 
                   
                    mysqli_data_seek($patients_result, 0);
                    $unreadTotal = 0;
                    $patientCount = 0;
                    
                    while ($row = mysqli_fetch_assoc($patients_result)): 
                        $patientCount++;
                        $initials = strtoupper(substr($row['first_name'], 0, 1) . substr($row['last_name'], 0, 1));
                        $last_message = $row['last_message'] ? $row['last_message'] : 'No messages yet';
                        $time_ago = $row['last_message_time'] ? timeAgo($row['last_message_time']) : '';
                        $unread_count = $row['unread_count'];
                        $unreadTotal += $unread_count;
                        $is_unread = $row['is_read'] == 0 && $row['last_message'] != null;
                    ?>
                        <a href="chat.php?patient_id=<?= $row['patient_id'] ?>" 
                           class="message-item <?= $is_unread ? 'unread-message' : '' ?>">
                            <div class="avatar">
                                <?= $initials ?>
                            </div>
                            <div class="message-content">
                                <div class="message-header">
                                    <span class="patient-name">
                                        <?= htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) ?>
                                    </span>
                                    <?php if ($time_ago): ?>
                                        <span class="message-time"><?= $time_ago ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="message-preview">
                                    <div class="last-message">
                                        <?= htmlspecialchars($last_message) ?>
                                    </div>
                                    <?php if ($unread_count > 0): ?>
                                        <span class="unread-badge"><?= $unread_count ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endwhile; ?>
                    
                    <?php if($patientCount === 0): ?>
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h4>No Patients Found</h4>
                            <p>Start by adding patients to begin messaging</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
        
        let searchTimeout;
document.getElementById('searchInput').addEventListener('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
    const filter = this.value.toLowerCase();
    const items = document.getElementsByClassName('message-item');
    
    Array.from(items).forEach(item => {
        const name = item.querySelector('.patient-name').textContent.toLowerCase();
                    if (name.includes(filter)) {
                        item.style.display = '';
                        item.style.animation = 'fadeIn 0.3s ease';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }, 300);
        });

       
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);

        
        setInterval(() => {
            
            console.log('Checking for new messages...');
        }, 30000);
</script>
</body>
</html>

<?php
function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->y > 0) {
        return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    }
    if ($diff->m > 0) {
        return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    }
    if ($diff->d > 0) {
        return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    }
    if ($diff->h > 0) {
        return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    }
    if ($diff->i > 0) {
        return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    }
    return 'Just now';
} 
?> 