<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

$username = $_SESSION['email'];
$caretaker_id = $_SESSION['user_id'];


$servername = "localhost";
$dbusername = "root"; 
$dbpassword = ""; 
$dbname = "health_monitoring"; 


$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM patients WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $caretaker_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient List - Health Monitoring</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .container-fluid {
            padding: 2rem;
        }

        .header-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .header-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(37, 99, 235, 0.1);
        }

        .header-subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .search-section {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .search-box {
            position: relative;
            background: var(--gray-100);
            border-radius: 15px;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .search-box:focus-within {
            background: var(--white);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .search-box input {
            border: none;
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 1rem;
            color: var(--gray-800);
        }

        .search-box input::placeholder {
            color: var(--gray-600);
        }

        .search-icon {
            color: var(--primary-color);
            font-size: 1.2rem;
        }

        .add-btn {
            background: linear-gradient(135deg, var(--success-color), #059669);
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--gray-600);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .patient-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }

        .patient-card {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            position: relative;
        }

        .patient-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }

        .patient-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(37, 99, 235, 0.05) 50%, transparent 70%);
            transform: translateX(-100%);
            transition: transform 0.6s ease;
            z-index: 0;
        }

        .patient-card:hover::before {
            transform: translateX(100%);
        }

        .patient-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            padding: 2rem 1.5rem;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .patient-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem auto;
            box-shadow: var(--shadow-md);
            border: 4px solid rgba(255, 255, 255, 0.3);
            font-weight: 700;
            font-size: 1.8rem;
            overflow: hidden;
        }

        .patient-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .patient-header h5 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }

        .patient-header small {
            opacity: 0.9;
            font-weight: 500;
        }

        .patient-info {
            padding: 1.5rem;
            position: relative;
            z-index: 1;
        }

        .patient-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .stat-item {
            background: var(--gray-100);
            padding: 1rem;
            border-radius: 12px;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .stat-item:hover {
            background: var(--gray-200);
            border-color: var(--primary-color);
            transform: translateY(-2px);
        }

        .stat-item i {
            color: var(--primary-color);
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            display: block;
        }

        .stat-item div {
            color: var(--gray-600);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.25rem;
        }

        .stat-item strong, .stat-item small {
            color: var(--gray-800);
            font-weight: 700;
            font-size: 0.9rem;
        }

        .quick-actions {
            padding: 1.5rem;
            border-top: 2px solid var(--gray-200);
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0.75rem;
            background: var(--gray-100);
        }

        .action-btn {
            color: var(--gray-700);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            background: var(--white);
            border: 2px solid transparent;
            font-weight: 600;
        }

        .action-btn:hover {
            color: var(--primary-color);
            background: var(--white);
            border-color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            text-decoration: none;
        }

        .delete-btn {
            color: var(--danger-color) !important;
        }

        .delete-btn:hover {
            color: var(--white) !important;
            background: var(--danger-color) !important;
            border-color: var(--danger-color) !important;
        }

        .action-btn i {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
        }

        .action-btn span {
            font-size: 0.85rem;
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: var(--white);
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            opacity: 0.7;
        }

        .empty-state h4 {
            color: var(--gray-800);
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .empty-state p {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        /* Animation for cards */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .patient-card {
            animation: fadeInUp 0.6s ease forwards;
        }

        .patient-card:nth-child(1) { animation-delay: 0.1s; }
        .patient-card:nth-child(2) { animation-delay: 0.2s; }
        .patient-card:nth-child(3) { animation-delay: 0.3s; }
        .patient-card:nth-child(4) { animation-delay: 0.4s; }
        .patient-card:nth-child(5) { animation-delay: 0.5s; }
        .patient-card:nth-child(6) { animation-delay: 0.6s; }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }

            .header-section {
                padding: 1.5rem;
            }

            .header-title {
                font-size: 2rem;
            }

            .search-section {
                padding: 1rem;
            }

            .patient-grid {
                grid-template-columns: 1fr;
            }

            .patient-stats {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }

        /* Loading animation */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid var(--gray-200);
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        
        <a href="caretaker_dashboard.php" class="back-btn">
            <i class="fas fa-arrow-left"></i>
            Back to Dashboard
        </a>

        
        <div class="header-section">
            <h1 class="header-title">
                <i class="fas fa-users me-3"></i>
                Patient List
            </h1>
            <p class="header-subtitle">
                Manage and monitor your assigned patients with comprehensive health tracking
            </p>
        </div>

        
        <?php 
        $total_patients = $result->num_rows;
        $male_patients = 0;
        $female_patients = 0;
        $result->data_seek(0);
        while ($row = $result->fetch_assoc()) {
            if (strtolower($row['gender']) == 'male') {
                $male_patients++;
            } else {
                $female_patients++;
            }
        }
        $result->data_seek(0); 
        ?>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_patients; ?></div>
                <div class="stat-label">Total Patients</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $male_patients; ?></div>
                <div class="stat-label">Male Patients</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $female_patients; ?></div>
                <div class="stat-label">Female Patients</div>
            </div>
        </div>

        
        <div class="search-section">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="search-box">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" class="form-control" id="patientSearch" placeholder="Search patients by name, ID, or contact information...">
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <button class="add-btn" onclick="window.location.href='add_patient.php'">
                        <i class="fas fa-user-plus"></i>
                        Add New Patient
                    </button>
                </div>
            </div>
        </div>

        
        <?php if ($result->num_rows == 0): ?>
            <div class="empty-state">
                <i class="fas fa-users"></i>
                <h4>No Patients Found</h4>
                <p>Start by adding your first patient to begin health monitoring and management.</p>
                <button class="add-btn" onclick="window.location.href='add_patient.php'">
                    <i class="fas fa-user-plus"></i>
                    Add First Patient
                </button>
            </div>
        <?php else: ?>
            <div class="patient-grid" id="patientGrid">
                <?php 
                while($row = $result->fetch_assoc()) {
                    $patient_id = $row['patient_id'];
                    $patient_name = $row['first_name'] . ' ' . $row['last_name'];
                    $dob = new DateTime($row['date_of_birth']);
                    $age = $dob->diff(new DateTime())->y;
                ?>
                <div class="patient-card">
                    <div class="patient-header">
                        <div class="patient-avatar">
                            <?php
                                
                                $initials = strtoupper(substr($row['first_name'], 0, 1) . substr($row['last_name'], 0, 1));
                                echo '<span style="font-size: 2rem; font-weight: 700; color: white;">' . $initials . '</span>';
                            ?>
                        </div>
                        <h5><?php echo htmlspecialchars($patient_name); ?></h5>
                        <small>ID: <?php echo $patient_id; ?></small>
                    </div>
                    <div class="patient-info">
                        <div class="patient-stats">
                            <div class="stat-item">
                                <i class="fas fa-birthday-cake"></i>
                                <div>Age</div>
                                <strong><?php echo $age; ?> years</strong>
                            </div>
                            <div class="stat-item">
                                <i class="fas fa-venus-mars"></i>
                                <div>Gender</div>
                                <strong><?php echo htmlspecialchars($row['gender']); ?></strong>
                            </div>
                            <div class="stat-item">
                                <i class="fas fa-phone"></i>
                                <div>Contact</div>
                                <strong><?php echo htmlspecialchars($row['contact_number']); ?></strong>
                            </div>
                            <div class="stat-item">
                                <i class="fas fa-envelope"></i>
                                <div>Email</div>
                                <small><?php echo htmlspecialchars($row['email']); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="quick-actions">
                        <a href="patient_details.php?patient_id=<?php echo $patient_id; ?>" class="action-btn">
                            <i class="fas fa-eye"></i>
                            <span>View Details</span>
                        </a>
                        <a href="edit_patient.php?patient_id=<?php echo $patient_id; ?>" class="action-btn">
                            <i class="fas fa-edit"></i>
                            <span>Edit</span>
                        </a>
                        <a href="delete_patient.php?patient_id=<?php echo $patient_id; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this patient? This action cannot be undone.')">
                            <i class="fas fa-trash"></i>
                            <span>Delete</span>
                        </a>
                        <a href="patient_history.php?patient_id=<?php echo $patient_id; ?>" class="action-btn">
                            <i class="fas fa-history"></i>
                            <span>History</span>
                        </a>
                        <a href="contact_emergency.php?patient_id=<?php echo $patient_id; ?>" class="action-btn">
                            <i class="fas fa-ambulance"></i>
                            <span>Emergency</span>
                        </a>
                    </div>
                </div>
                <?php 
                }
                ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        
        let searchTimeout;
        document.getElementById('patientSearch').addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const searchText = e.target.value.toLowerCase();
                const patientCards = document.querySelectorAll('.patient-card');
                let visibleCount = 0;
                
                patientCards.forEach(card => {
                    const patientName = card.querySelector('h5').textContent.toLowerCase();
                    const patientInfo = card.querySelector('.patient-info').textContent.toLowerCase();
                    const patientId = card.querySelector('small').textContent.toLowerCase();
                    
                    if (patientName.includes(searchText) || patientInfo.includes(searchText) || patientId.includes(searchText)) {
                        card.style.display = '';
                        card.style.animation = 'fadeInUp 0.5s ease';
                        visibleCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });

                
                const emptyState = document.querySelector('.empty-state');
                if (emptyState) {
                    if (visibleCount === 0 && searchText !== '') {
                        emptyState.style.display = 'block';
                        emptyState.innerHTML = `
                            <i class="fas fa-search"></i>
                            <h4>No Results Found</h4>
                            <p>Try adjusting your search terms or browse all patients.</p>
                        `;
                    } else {
                        emptyState.style.display = 'none';
                    }
                }
            }, 300);
        });

        
        window.addEventListener('load', function() {
            const cards = document.querySelectorAll('.patient-card');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
            });
        });

        
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-3px) scale(1.02)';
            });
            
            btn.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    </script>
</body>
</html> 