<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

include('config.php');

$caretaker_id = $_SESSION['user_id'];
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search)) {
    
    $sql_active = "SELECT ea.*, p.first_name, p.last_name 
                   FROM emergency_alerts ea 
                   JOIN patients p ON ea.patient_id = p.patient_id 
                   WHERE (p.first_name LIKE ? OR p.last_name LIKE ? OR ea.alert_message LIKE ?) 
                     AND ea.is_resolved = 0
                     AND p.user_id = ?
                   ORDER BY ea.created_at DESC";
    $stmt_active = $conn->prepare($sql_active);
    $search_param = '%' . $search . '%';
    $stmt_active->bind_param("sssi", $search_param, $search_param, $search_param, $caretaker_id);
    $stmt_active->execute();
    $result_active_alerts = $stmt_active->get_result();

    
    $sql_resolved = "SELECT ea.*, p.first_name, p.last_name 
                     FROM emergency_alerts ea 
                     JOIN patients p ON ea.patient_id = p.patient_id 
                     WHERE (p.first_name LIKE ? OR p.last_name LIKE ? OR ea.alert_message LIKE ?) 
                       AND ea.is_resolved = 1
                       AND p.user_id = ?
                     ORDER BY ea.created_at DESC";
    $stmt_resolved = $conn->prepare($sql_resolved);
    $stmt_resolved->bind_param("sssi", $search_param, $search_param, $search_param, $caretaker_id);
    $stmt_resolved->execute();
    $result_resolved_alerts = $stmt_resolved->get_result();
} else {
    
    $sql_active = "SELECT ea.*, p.first_name, p.last_name 
                   FROM emergency_alerts ea 
                   JOIN patients p ON ea.patient_id = p.patient_id 
                   WHERE ea.is_resolved = 0
                     AND p.user_id = ?
                   ORDER BY ea.created_at DESC";
    $stmt_active = $conn->prepare($sql_active);
    $stmt_active->bind_param("i", $caretaker_id);
    $stmt_active->execute();
    $result_active_alerts = $stmt_active->get_result();

    
    $sql_resolved = "SELECT ea.*, p.first_name, p.last_name 
                     FROM emergency_alerts ea 
                     JOIN patients p ON ea.patient_id = p.patient_id 
                     WHERE ea.is_resolved = 1
                       AND p.user_id = ?
                     ORDER BY ea.created_at DESC";
    $stmt_resolved = $conn->prepare($sql_resolved);
    $stmt_resolved->bind_param("i", $caretaker_id);
    $stmt_resolved->execute();
    $result_resolved_alerts = $stmt_resolved->get_result();
}


$sql_family = "SELECT fm.*, p.first_name as patient_first_name, p.last_name as patient_last_name 
               FROM family_members fm
               JOIN patients p ON fm.patient_id = p.patient_id
               WHERE p.user_id = ?
               ORDER BY fm.patient_id, fm.emergency_contact DESC";
$stmt_family = $conn->prepare($sql_family);
$stmt_family->bind_param("i", $caretaker_id);
$stmt_family->execute();
$result_family = $stmt_family->get_result();


if (isset($_POST['resolve_alert'])) {
    $alert_id = intval($_POST['alert_id']);
    $caretaker_id = $_SESSION['user_id']; 
    
    $sql_resolve = "UPDATE emergency_alerts 
                    SET is_resolved = 1, 
                        resolved_by = ? 
                    WHERE alert_id = ?";
    
    $stmt = $conn->prepare($sql_resolve);
    $stmt->bind_param("ii", $caretaker_id, $alert_id);
    $stmt->execute();
    
    header("Location: emergency_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Emergency Dashboard | Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #ef4444;
            --secondary-color: #dc2626;
            --accent-color: #f87171;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --info-color: #3b82f6;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .main-content {
            flex-grow: 1;
            margin-left: 280px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .container-fluid {
            padding: 2rem;
        }

        .header-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .header-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--warning-color), var(--danger-color));
            animation: emergencyPulse 2s ease-in-out infinite;
        }

        @keyframes emergencyPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .header-title {
            color: var(--primary-color);
            font-weight: 800;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(239, 68, 68, 0.1);
        }

        .header-subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
        }

        .back-btn {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: var(--white);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            margin-bottom: 1rem;
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            color: var(--white);
            text-decoration: none;
        }

        .search-section {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .search-box {
            position: relative;
            background: var(--gray-100);
            border-radius: 15px;
            padding: 0.75rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .search-box:focus-within {
            background: var(--white);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
        }

        .search-box input {
            border: none;
            outline: none;
            background: transparent;
            width: 100%;
            font-size: 1rem;
            color: var(--gray-800);
        }

        .search-box input::placeholder {
            color: var(--gray-600);
        }

        .search-icon {
            color: var(--primary-color);
            font-size: 1.2rem;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            padding: 2rem;
            border-radius: 20px;
            text-align: center;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--warning-color));
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-xl);
        }

        .stat-card.danger {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
        }

        .stat-card.warning {
            background: linear-gradient(135deg, var(--warning-color), #d97706);
            color: var(--white);
        }

        .stat-card.info {
            background: linear-gradient(135deg, var(--info-color), #2563eb);
            color: var(--white);
        }

        .stat-card.success {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: var(--white);
        }

        .stat-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.9;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-weight: 600;
            font-size: 1rem;
            opacity: 0.9;
        }

        .alert-card {
            background: var(--white);
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .alert-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: var(--primary-color);
            transition: all 0.3s ease;
        }

        .alert-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-xl);
        }

        .alert-card.resolved {
            opacity: 0.7;
        }

        .alert-card.resolved::before {
            background: var(--success-color);
        }

        .alert-type-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 1rem;
            box-shadow: var(--shadow-md);
        }

        .alert-card.resolved .alert-type-icon {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .badge-emergency {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            animation: emergencyBlink 1.5s ease-in-out infinite;
        }

        @keyframes emergencyBlink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .badge-resolved {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: var(--white);
        }

        .resolve-btn {
            background: linear-gradient(135deg, var(--success-color), #059669);
            border: none;
            color: var(--white);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
        }

        .resolve-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            color: var(--white);
        }

        .family-card {
            background: var(--white);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .family-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .family-card.emergency-contact {
            border-left: 4px solid var(--warning-color);
            background: linear-gradient(135deg, var(--white) 0%, rgba(245, 158, 11, 0.05) 100%);
        }

        .emergency-badge {
            background: linear-gradient(135deg, var(--warning-color), #d97706);
            color: var(--white);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .contact-info {
            background: var(--gray-100);
            padding: 1rem;
            border-radius: 10px;
            margin-top: 1rem;
        }

        .contact-info p {
            margin: 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--gray-700);
            font-size: 0.9rem;
        }

        .contact-info i {
            color: var(--primary-color);
            width: 16px;
            text-align: center;
        }

        .section-title {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            font-size: 1.8rem;
        }

        /* Animation for cards */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-card, .family-card {
            animation: fadeInUp 0.6s ease forwards;
        }

        .alert-card:nth-child(1) { animation-delay: 0.1s; }
        .alert-card:nth-child(2) { animation-delay: 0.2s; }
        .alert-card:nth-child(3) { animation-delay: 0.3s; }
        .family-card:nth-child(1) { animation-delay: 0.1s; }
        .family-card:nth-child(2) { animation-delay: 0.2s; }
        .family-card:nth-child(3) { animation-delay: 0.3s; }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }

            .header-section {
                padding: 1.5rem;
            }

            .header-title {
                font-size: 2rem;
            }

            .search-section {
                padding: 1rem;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }

            .stat-card {
                padding: 1.5rem;
            }
        }

        /* Emergency specific animations */
        .emergency-pulse {
            animation: emergencyPulse 2s ease-in-out infinite;
        }

        .shake {
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
               
                <a href="caretaker_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>


<body>

        
        <a href="emergency_messages_dashboard.php" class="btn btn-info mb-3">
            <i class="fas fa-envelope"></i> Emergency Dashboard Messages
        </a>
      
        <div class="header-section">
            <h1 class="header-title">
                <i class="fas fa-exclamation-triangle me-3 emergency-pulse"></i>
                Emergency Dashboard
            </h1>
            <p class="header-subtitle">
                Monitor and manage emergency alerts and family contacts in real-time
            </p>
        </div>
        <div class="search-section">
            <form method="GET" class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search by patient name or alert message..." 
                    value="<?php echo htmlspecialchars($search); ?>"
                >
            </form>
        </div>

    
        <div class="stats-container">
            <?php
            $active_count = mysqli_num_rows($result_active_alerts);
            
            $emergency_contacts = mysqli_query($conn, "SELECT COUNT(*) as count FROM family_members WHERE emergency_contact = 1");
            $contacts_count = mysqli_fetch_assoc($emergency_contacts)['count'];
            
            $resolved_count = mysqli_num_rows($result_resolved_alerts);
            
            $total_alerts = $active_count + $resolved_count;
            ?>
            
            <div class="stat-card danger">
                <i class="fas fa-exclamation-triangle stat-icon"></i>
                <div class="stat-number"><?php echo $active_count; ?></div>
                <div class="stat-label">Active Alerts</div>
            </div>
            

            
            <div class="stat-card info">
                <i class="fas fa-check-circle stat-icon"></i>
                <div class="stat-number"><?php echo $resolved_count; ?></div>
                <div class="stat-label">Resolved Alerts</div>
            </div>
            
            <div class="stat-card success">
                <i class="fas fa-chart-line stat-icon"></i>
                <div class="stat-number"><?php echo $total_alerts > 0 ? round(($resolved_count / $total_alerts) * 100) : 0; ?>%</div>
                <div class="stat-label">Resolution Rate</div>
            </div>
        </div>

     
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="section-title">
                        <i class="fas fa-bell"></i>
                        Emergency Alerts
                    </h3>
                    <div>
                        <button id="showActiveBtn" class="btn btn-danger me-2">Show Active</button>
                        <button id="showResolvedBtn" class="btn btn-success">Show Resolved</button>
                    </div>
                </div>
                <div id="activeAlertsList">
                    <?php if ($active_count == 0): ?>
                        <div class="alert-card">
                            <div class="text-center text-muted">
                                <i class="fas fa-check-circle" style="font-size: 3rem; color: var(--success-color);"></i>
                                <h4 class="mt-3">No Active Emergency Alerts</h4>
                                <p>All systems are running normally. No active emergency alerts at this time.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php while ($alert = mysqli_fetch_assoc($result_active_alerts)): ?>
                            <div class="alert-card">
                                <div class="d-flex align-items-start">
                                    <div class="alert-type-icon">
                                        <i class="fas fa-exclamation-triangle"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h5 class="mb-0 fw-bold">
                                                <?php echo htmlspecialchars($alert['first_name'] . ' ' . $alert['last_name']); ?>
                                            </h5>
                                            <span class="status-badge badge-emergency">
                                                Active
                                            </span>
                                        </div>
                                        <p class="mb-2 text-muted"><?php echo htmlspecialchars($alert['alert_message']); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i> 
                                                <?php echo date('M d, Y H:i', strtotime($alert['created_at'])); ?>
                                            </small>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="alert_id" value="<?php echo $alert['alert_id']; ?>">
                                                <button type="submit" name="resolve_alert" class="resolve-btn">
                                                    <i class="fas fa-check me-1"></i> Mark as Resolved
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
                <div id="resolvedAlertsList" style="display:none;">
                    <?php if ($resolved_count == 0): ?>
                        <div class="alert-card">
                            <div class="text-center text-muted">
                                <i class="fas fa-users" style="font-size: 3rem; color: var(--gray-400);"></i>
                                <h4 class="mt-3">No Resolved Emergency Alerts</h4>
                                <p>No alerts have been marked as resolved yet.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php while ($alert = mysqli_fetch_assoc($result_resolved_alerts)): ?>
                            <div class="alert-card resolved">
                                <div class="d-flex align-items-start">
                                    <div class="alert-type-icon" style="background: linear-gradient(135deg, #10b981, #059669);">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h5 class="mb-0 fw-bold">
                                                <?php echo htmlspecialchars($alert['first_name'] . ' ' . $alert['last_name']); ?>
                                            </h5>
                                            <span class="status-badge badge-resolved">
                                                Resolved
                                            </span>
                                        </div>
                                        <p class="mb-2 text-muted"><?php echo htmlspecialchars($alert['alert_message']); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i> 
                                                <?php echo date('M d, Y H:i', strtotime($alert['created_at'])); ?>
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const activeBtn = document.getElementById('showActiveBtn');
            const resolvedBtn = document.getElementById('showResolvedBtn');
            const activeList = document.getElementById('activeAlertsList');
            const resolvedList = document.getElementById('resolvedAlertsList');

            activeBtn.addEventListener('click', function() {
                activeList.style.display = 'block';
                resolvedList.style.display = 'none';
                activeBtn.disabled = true;
                resolvedBtn.disabled = false;
            });

            resolvedBtn.addEventListener('click', function() {
                activeList.style.display = 'none';
                resolvedList.style.display = 'block';
                activeBtn.disabled = false;
                resolvedBtn.disabled = true;
            });

        
            activeBtn.disabled = true;
            resolvedBtn.disabled = false;
        });
    </script>
</body>
</html>