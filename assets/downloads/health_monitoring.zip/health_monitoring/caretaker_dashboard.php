<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';


if ($_SESSION['user_type'] !== 'caretaker') {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['email'])) {
    $username = "Unknown User";
} else {
    $username = $_SESSION['email'];
}

if (!$conn) {
    die("Database connection failed");
}

$caretaker_id = $_SESSION['user_id'];


$patientCount = $conn->query("SELECT COUNT(*) AS total FROM patients WHERE user_id = $caretaker_id")->fetch_assoc()['total'];


$totalAppointments = $conn->query("SELECT COUNT(*) AS total FROM appointments a 
                                  JOIN patients p ON a.patient_id = p.patient_id 
                                  WHERE p.user_id = $caretaker_id")->fetch_assoc()['total'];


$messageCount = $conn->query("SELECT COUNT(*) AS total FROM messages m 
                             JOIN patients p ON m.patient_id = p.patient_id 
                             WHERE p.user_id = $caretaker_id AND m.is_read = 0")->fetch_assoc()['total'];


$todayAppointments = $conn->query("SELECT COUNT(*) AS total FROM appointments a 
                                  JOIN patients p ON a.patient_id = p.patient_id 
                                  WHERE p.user_id = $caretaker_id AND DATE(a.appointment_date) = CURDATE()")->fetch_assoc()['total'];


$recentPatients = $conn->query("SELECT COUNT(*) AS total FROM patients WHERE user_id = $caretaker_id")->fetch_assoc()['total'];


$appointmentsData = [];
$labels = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('D', strtotime("-$i days"));
    $labels[] = $label;

    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_date) = ?");
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $appointmentsData[] = $result['count'];
}


$genderResult = $conn->query("SELECT gender, COUNT(*) as count FROM patients GROUP BY gender");
$genderLabels = [];
$genderCounts = [];
while ($row = $genderResult->fetch_assoc()) {
    $genderLabels[] = $row['gender'];
    $genderCounts[] = (int)$row['count'];
}


$recentAlerts = $conn->query("SELECT ea.*, p.first_name, p.last_name 
                             FROM emergency_alerts ea 
                             JOIN patients p ON ea.patient_id = p.patient_id 
                             WHERE p.user_id = $caretaker_id
                             ORDER BY ea.alert_id DESC LIMIT 3")->fetch_all(MYSQLI_ASSOC);


$activeAlertsCount = $conn->query("SELECT COUNT(*) AS total FROM emergency_alerts ea 
                                  JOIN patients p ON ea.patient_id = p.patient_id
                                  WHERE p.user_id = $caretaker_id AND ea.is_resolved = 0")->fetch_assoc()['total'];

$recentActivities = [];


$newPatients = $conn->query("
    SELECT 'patient' as type, NOW() as date, CONCAT(first_name, ' ', last_name) as patient_name, 
           CONCAT('New patient assigned: ', first_name, ' ', last_name, ' (ID: ', patient_id, ')') as description,
           NOW() as sort_date
    FROM patients 
    WHERE user_id = $caretaker_id
    AND patient_id >= (SELECT MAX(patient_id) - 5 FROM patients)
    ORDER BY patient_id DESC
    LIMIT 3
")->fetch_all(MYSQLI_ASSOC);


$newFamilyMembers = $conn->query("
    SELECT 'family' as type, NOW() as date, CONCAT(fm.first_name, ' ', fm.last_name) as patient_name, 
           CONCAT('New family member added: ', fm.first_name, ' ', fm.last_name, ' (Relationship: ', COALESCE(fm.relationship, 'Not specified'), ')') as description,
           NOW() as sort_date
    FROM family_members fm 
    JOIN patients p ON fm.patient_id = p.patient_id
    WHERE p.user_id = $caretaker_id
    AND fm.member_id >= (SELECT MAX(member_id) - 3 FROM family_members)
    ORDER BY fm.member_id DESC
    LIMIT 2
")->fetch_all(MYSQLI_ASSOC);


$recentMessages = $conn->query("
    SELECT 'message' as type, m.message_date as date, CONCAT(p.first_name, ' ', p.last_name) as patient_name, 
           CONCAT('New message: ', LEFT(m.message, 50), '...') as description,
           m.message_date as sort_date
    FROM messages m
    JOIN patients p ON m.patient_id = p.patient_id
    WHERE p.user_id = $caretaker_id
    AND m.message_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ORDER BY m.message_date DESC
    LIMIT 2
")->fetch_all(MYSQLI_ASSOC);

$allActivities = array_merge($newPatients, $newFamilyMembers, $recentMessages);

usort($allActivities, function($a, $b) {
    return strtotime($b['sort_date']) - strtotime($a['sort_date']);
});

$recentActivities = array_slice($allActivities, 0, 8);


$topPatients = $conn->query("
    SELECT p.first_name, p.last_name, COUNT(a.appointment_id) as appointment_count
    FROM patients p 
    LEFT JOIN appointments a ON p.patient_id = a.patient_id 
    WHERE p.user_id = $caretaker_id
    GROUP BY p.patient_id 
    ORDER BY appointment_count DESC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);


$upcomingAppointments = $conn->query("
    SELECT a.appointment_date, a.appointment_time, a.reason,
           p.first_name, p.last_name, p.patient_id,
           d.first_name as doctor_first_name, d.last_name as doctor_last_name
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.patient_id 
    JOIN doctors d ON a.doctor_id = d.doctor_id 
    WHERE p.user_id = $caretaker_id
    AND a.appointment_date >= CURDATE() 
    AND a.appointment_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    AND a.status = 'Scheduled'
    ORDER BY a.appointment_date ASC, a.appointment_time ASC 
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Caretaker Dashboard - Healthcare System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="animations.js"></script>

    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            color: white;
            padding-top: 30px;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-xl);
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-brand {
            padding: 0 25px;
            margin-bottom: 30px;
        }

        .sidebar-brand h4 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-item {
            position: relative;
            margin: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            padding: 12px 20px !important;
            border-radius: 12px;
            display: flex !important;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white !important;
            transform: translateX(5px);
            box-shadow: var(--shadow-md);
        }

        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
            box-shadow: var(--shadow-lg);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 24px;
            text-align: center;
        }

        .main-content {
            flex-grow: 1;
            margin-left: 280px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .welcome-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            opacity: 0.05;
        }

        .welcome-text {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }

        .welcome-subtext {
            font-size: 1.1rem;
            color: var(--gray-600);
            position: relative;
            z-index: 1;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }

        .stat-card::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 100px;
            height: 100px;
            background: radial-gradient(circle, rgba(37, 99, 235, 0.03) 0%, transparent 70%);
            border-radius: 50%;
            transform: translate(30px, -30px);
            pointer-events: none;
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            box-shadow: var(--shadow-md);
            position: relative;
            z-index: 1;
        }

        .stat-icon::after {
            content: '';
            position: absolute;
            top: -5px;
            left: -5px;
            right: -5px;
            bottom: -5px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 20px;
            opacity: 0.2;
            z-index: -1;
        }

        .stat-title {
            font-size: 0.9rem;
            color: var(--gray-600);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 1;
        }

        .stat-change {
            font-size: 0.85rem;
            color: var(--success-color);
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        .quick-actions {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .quick-actions::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 20%, rgba(37, 99, 235, 0.02) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(59, 130, 246, 0.02) 0%, transparent 50%);
            pointer-events: none;
        }

        .quick-actions-title {
            color: var(--primary-color);
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            position: relative;
            z-index: 1;
        }

        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            position: relative;
            z-index: 1;
        }

        .action-btn {
            background: var(--gray-100);
            border: 2px solid transparent;
            border-radius: 15px;
            padding: 1.5rem;
            text-decoration: none;
            color: var(--gray-700);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
            font-weight: 600;
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05), rgba(59, 130, 246, 0.05));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .action-btn:hover {
            background: var(--white);
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
            text-decoration: none;
        }

        .action-btn:hover::before {
            opacity: 1;
        }

        .action-btn i {
            font-size: 2rem;
            color: var(--primary-color);
            position: relative;
            z-index: 1;
        }

        .action-btn span {
            position: relative;
            z-index: 1;
        }

        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .chart-card {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .chart-title {
            font-size: 1.3rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .recent-activities {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            border: 1px solid var(--gray-200);
        }

        .activity-item:hover {
            background: var(--gray-100);
            transform: translateX(5px);
        }

        .activity-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            color: white;
        }

        .activity-icon.appointment {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        .activity-icon.patient {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .activity-icon.family {
            background: linear-gradient(135deg, #8b5cf6, #a78bfa);
        }

        .activity-icon.emergency {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            animation: pulse 2s infinite;
        }

        .activity-icon.message {
            background: linear-gradient(135deg, #f59e0b, #fbbf24);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .activity-content h6 {
            margin: 0;
            color: var(--gray-800);
            font-weight: 600;
        }

        .activity-content p {
            margin: 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .activity-time {
            color: var(--gray-500);
            font-size: 0.8rem;
        }

        .emergency-section {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            color: white;
            box-shadow: var(--shadow-xl);
            position: relative;
            overflow: hidden;
        }

        .emergency-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            opacity: 0.1;
        }

        .emergency-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 1.5rem;
            position: relative;
            z-index: 1;
        }

        .emergency-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
        }

        .emergency-badge {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            backdrop-filter: blur(10px);
        }

        .alert-item {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .alert-item.resolved {
            background: rgba(16, 185, 129, 0.2);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .top-patients {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .patient-item {
            display: flex;
            justify-content: between;
            align-items: center;
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 0.75rem;
            background: var(--gray-100);
            transition: all 0.3s ease;
        }

        .patient-item:hover {
            background: var(--gray-200);
            transform: translateX(5px);
        }

        .patient-info h6 {
            margin: 0;
            color: var(--gray-800);
            font-weight: 600;
        }

        .patient-info p {
            margin: 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .appointment-count {
            background: var(--primary-color);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        @media (max-width: 1200px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }

            .action-grid {
                grid-template-columns: 1fr;
            }
        }

        .menu-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px;
            cursor: pointer;
            box-shadow: var(--shadow-md);
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in {
            animation: fadeInUp 0.6s ease forwards;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }
        .stat-card:nth-child(5) { animation-delay: 0.5s; }
    </style>
</head>
<body>
    <button class="menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <div class="sidebar">
        <div class="sidebar-brand">
            <h4><i class="fas fa-heartbeat"></i> Caretaker</h4>
        </div>
        <nav class="nav flex-column">
            <div class="nav-item">
                <a class="nav-link active" href="caretaker_dashboard.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="patient_list.php">
                    <i class="fas fa-users"></i> Patients
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="appointments_doctor_calendar.php">
                    <i class="fas fa-calendar-alt"></i> Doctor Appointment Calendar
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="family_members.php">
                    <i class="fas fa-user-friends"></i> Family Members
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="patient_location.php">
                    <i class="fas fa-map"></i> Patient Locations
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="messages.php">
                    <i class="fas fa-comment-dots"></i> Messages
                    <?php if ($messageCount > 0): ?>
                        <span class="badge bg-danger rounded-pill ms-2"><?php echo $messageCount; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="emergency_dashboard.php">
                    <i class="fas fa-exclamation-triangle"></i> Emergency
                    <?php if ($activeAlertsCount > 0): ?>
                        <span class="badge bg-danger rounded-pill ms-2"><?php echo $activeAlertsCount; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item mt-auto">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>
    </div>

    <div class="main-content">
       
        <div class="welcome-section animate-fade-in">
            <div class="welcome-text">
                Good <?php 
                    $hour = date('H');
                    if ($hour < 12) echo 'Morning';
                    elseif ($hour < 17) echo 'Afternoon';
                    else echo 'Evening';
                ?>, <?php 
                    $caretaker_name_query = $conn->prepare("SELECT first_name, last_name FROM users WHERE user_id = ?");
                    $caretaker_name_query->bind_param("i", $caretaker_id);
                    $caretaker_name_query->execute();
                    $caretaker_name_result = $caretaker_name_query->get_result();
                    if ($caretaker_name = $caretaker_name_result->fetch_assoc()) {
                        echo htmlspecialchars($caretaker_name['first_name'] . ' ' . $caretaker_name['last_name']);
                    } else {
                        echo 'Healthcare Hero';
                    }
                ?>! 🌟
            </div>
            <div class="welcome-subtext">
                Ready to make a difference in your patients' lives today
            </div>
        </div>
        <div class="stats-container">
            <div class="stat-card animate-fade-in">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-title">Total Patients</div>
                <div class="stat-value"><?php echo $patientCount; ?></div>
                <div class="stat-change">+<?php echo $recentPatients; ?> this week</div>
            </div>

            <div class="stat-card animate-fade-in">
                <div class="stat-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-title">Total Appointments</div>
                <div class="stat-value"><?php echo $totalAppointments; ?></div>
                <div class="stat-change"><?php echo $todayAppointments; ?> today</div>
            </div>

            <div class="stat-card animate-fade-in">
                <div class="stat-icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="stat-title"> Messages</div>
                <div class="stat-value"><?php echo $messageCount; ?></div>
                <div class="stat-change">Requires attention</div>
            </div>


        </div>


        <?php if (!empty($recentAlerts)): ?>
            <div class="emergency-section animate-fade-in">
                <div class="emergency-header">
                    <h3 class="emergency-title">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Recent Emergency Alerts
                    </h3>
                    <span class="emergency-badge"><?php echo $activeAlertsCount; ?> Active</span>
                </div>
                <?php foreach ($recentAlerts as $alert): ?>
                    <div class="alert-item <?php echo $alert['is_resolved'] ? 'resolved' : ''; ?>">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo htmlspecialchars($alert['first_name'] . ' ' . $alert['last_name']); ?></strong>
                                <p class="mb-0"><?php echo htmlspecialchars($alert['alert_message']); ?></p>
                            </div>
                            <div class="text-end">
                                <small class="d-block mb-1">Emergency Alert</small>
                                <?php if (!$alert['is_resolved']): ?>
                                    <a href="emergency_dashboard.php" class="btn btn-light btn-sm">Respond</a>
                                <?php else: ?>
                                    <span class="badge bg-success">Resolved</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="text-end mt-3">
                    <a href="emergency_dashboard.php" class="btn btn-light">View All Alerts</a>
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="recent-activities animate-fade-in">
                    <h3 class="chart-title">
                        <i class="fas fa-history"></i>
                        Recent Activities
                    </h3>
                    <?php if (empty($recentActivities)): ?>
                        <div style="text-align:center;">
                            <img src="https://undraw.co/api/illustrations/undraw_not_found_re_bh2e.svg" alt="No Activities" style="max-width:160px;width:100%;margin-bottom:1rem;" />
                            <p class="text-center text-muted">No recent activities</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($recentActivities as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon <?php echo $activity['type']; ?>">
                                    <i class="fas fa-<?php 
                                        switch($activity['type']) {
                                            case 'patient': echo 'user-plus'; break;
                                            case 'family': echo 'user-friends'; break;
                                            case 'message': echo 'envelope'; break;
                                            default: echo 'info-circle';
                                        }
                                    ?>"></i>
                                </div>
                                <div class="activity-content flex-grow-1">
                                    <h6><?php echo htmlspecialchars($activity['patient_name']); ?></h6>
                                    <p><?php echo htmlspecialchars($activity['description']); ?></p>
                                </div>
                                <div class="activity-time">
                                    <?php 
                                        if ($activity['type'] == 'patient' || $activity['type'] == 'family') {
                                            echo 'Recently';
                                        } else {
                                            echo date('M d, H:i', strtotime($activity['date']));
                                        }
                                    ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="top-patients animate-fade-in">
                    <h3 class="chart-title">
                        <i class="fas fa-calendar-alt"></i>
                        Upcoming Appointments
                    </h3>
                    <?php if (empty($upcomingAppointments)): ?>
                        <div style="text-align:center;">
                            <img src="https://undraw.co/api/illustrations/undraw_empty_re_opql.svg" alt="No Appointments" style="max-width:120px;width:100%;margin-bottom:1rem;" />
                            <p class="text-center text-muted">No upcoming appointments</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($upcomingAppointments as $appointment): ?>
                            <div class="patient-item">
                                <div class="patient-info">
                                    <h6><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></h6>
                                    <p>
                                        <i class="fas fa-user-md me-1"></i>
                                        Dr. <?php echo htmlspecialchars($appointment['doctor_first_name'] . ' ' . $appointment['doctor_last_name']); ?>
                                    </p>
                                    <small class="text-muted">
                                        <i class="fas fa-calendar me-1"></i>
                                        <?php echo date('M d, Y', strtotime($appointment['appointment_date'])); ?>
                                        at <?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?>
                                    </small>
                                </div>
                                <div class="appointment-count">
                                    <i class="fas fa-clock"></i>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div class="text-center mt-3">
                            <a href="all_appointments.php" class="btn btn-primary btn-sm">
                                <i class="fas fa-calendar-alt me-1"></i>
                                View All Appointments
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <script>

        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }
        window.addEventListener('load', function() {
            const cards = document.querySelectorAll('.animate-fade-in');
            cards.forEach((card, index) => {
                card.style.animationDelay = `${index * 0.1}s`;
            });
        });
    </script>
</body>
</html> 