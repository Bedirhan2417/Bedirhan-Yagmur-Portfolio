<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$appointment_id = isset($_GET['appointment_id']) ? (int)$_GET['appointment_id'] : 0;


$sql = "SELECT 
            a.appointment_id, a.appointment_date, a.appointment_time, a.reason, a.status, a.created_at,
            p.patient_id, p.first_name AS patient_first_name, p.last_name AS patient_last_name, p.date_of_birth,
            d.doctor_id, d.first_name AS doctor_first_name, d.last_name AS doctor_last_name, d.specialty
        FROM 
            appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        JOIN doctors d ON a.doctor_id = d.doctor_id
        WHERE a.appointment_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Appointment not found.";
    exit();
}

$appointment = $result->fetch_assoc();


$patient_age = date('Y') - date('Y', strtotime($appointment['date_of_birth']));


$appointment_datetime = new DateTime($appointment['appointment_date']);
$formatted_date = $appointment_datetime->format('l, F j, Y');
$formatted_time = $appointment_datetime->format('g:i A');


$status_colors = [
    'Scheduled' => 'primary',
    'Completed' => 'success',
    'Cancelled' => 'danger',
    'Rescheduled' => 'warning'
];
$status_color = $status_colors[$appointment['status']] ?? 'secondary';

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointment Details | Health Monitoring System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --border-radius: 16px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            color: #1e293b;
        }

        .main-container {
            min-height: 100vh;
            padding: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .appointment-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255, 255, 255, 0.2);
            max-width: 800px;
            width: 100%;
            animation: slideInUp 0.6s ease-out;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            padding: 2rem;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }

        .card-header h1 {
            font-weight: 700;
            font-size: 2rem;
            margin: 0;
            position: relative;
            z-index: 1;
        }

        .card-header p {
            margin: 0.5rem 0 0 0;
            opacity: 0.9;
            font-weight: 400;
            position: relative;
            z-index: 1;
        }

        .card-body {
            padding: 2.5rem;
        }

        .section {
            margin-bottom: 2.5rem;
            animation: fadeInUp 0.6s ease-out;
        }

        .section:nth-child(2) { animation-delay: 0.1s; }
        .section:nth-child(3) { animation-delay: 0.2s; }
        .section:nth-child(4) { animation-delay: 0.3s; }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #e2e8f0;
        }

        .section-title i {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .info-item {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 1.25rem;
            transition: var(--transition);
        }

        .info-item:hover {
            border-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.1);
            transform: translateY(-2px);
        }

        .info-label {
            font-weight: 600;
            color: var(--secondary-color);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
        }

        .info-value {
            font-weight: 500;
            color: #1e293b;
            font-size: 1.1rem;
        }

        .avatar-section {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.2rem;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .patient-avatar {
            background: linear-gradient(135deg, var(--success-color), #059669);
        }

        .doctor-avatar {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
        }

        .person-details h5 {
            margin: 0;
            color: #1e293b;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .person-details p {
            margin: 0.25rem 0 0 0;
            color: var(--secondary-color);
            font-size: 0.9rem;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-primary {
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            color: var(--primary-color);
            border: 1px solid #bfdbfe;
        }

        .status-success {
            background: linear-gradient(135deg, #ecfdf5, #d1fae5);
            color: var(--success-color);
            border: 1px solid #a7f3d0;
        }

        .status-danger {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: var(--danger-color);
            border: 1px solid #fecaca;
        }

        .status-warning {
            background: linear-gradient(135deg, #fffbeb, #fef3c7);
            color: var(--warning-color);
            border: 1px solid #fde68a;
        }

        .appointment-datetime {
            background: linear-gradient(135deg, #eff6ff, #f8fafc);
            border: 2px solid #dbeafe;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .datetime-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 1.5rem;
        }

        .datetime-text h4 {
            color: #1e293b;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .datetime-text p {
            color: var(--secondary-color);
            font-size: 1.1rem;
            margin: 0;
        }

        .reason-section {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 1.5rem;
        }

        .reason-text {
            color: #1e293b;
            line-height: 1.6;
            font-size: 1rem;
            margin: 0;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .btn {
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-hover), #6d28d9);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
            color: white;
        }

        .btn-secondary {
            background: white;
            color: var(--secondary-color);
            border: 2px solid #e2e8f0;
        }

        .btn-secondary:hover {
            background: #f8fafc;
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-1px);
        }

        .btn-success {
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .btn-success:hover {
            background: linear-gradient(135deg, #059669, #047857);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
            color: white;
        }

        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 2rem;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        @media (max-width: 768px) {
            .main-container {
                padding: 1rem;
            }
            .card-body {
                padding: 1.5rem;
            }
            .info-grid {
                grid-template-columns: 1fr;
            }
            .action-buttons {
                flex-direction: column;
            }
            .avatar-section {
                flex-direction: column;
                text-align: center;
            }
        }

        /* Print styles */
        @media print {
            body {
                background: white;
            }
            .appointment-card {
                box-shadow: none;
                border: 1px solid #ddd;
            }
            .action-buttons {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="main-container">
    <div class="appointment-card">
        <div class="card-header">
            <h1><i class="fas fa-calendar-check"></i> Appointment Details</h1>
            <p>Appointment ID: #<?= $appointment_id ?></p>
        </div>
        
        <div class="card-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="patient_list.php">Patients</a></li>
                    <li class="breadcrumb-item"><a href="patient_details.php?patient_id=<?= $appointment['patient_id'] ?>">Patient Details</a></li>
                    <li class="breadcrumb-item active">Appointment Details</li>
                </ol>
            </nav>

            <div class="section">
                <h5 class="section-title">
                    <i class="fas fa-calendar-alt"></i>
                    Appointment Information
                </h5>
                
                <div class="appointment-datetime">
                    <div class="datetime-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="datetime-text">
                        <h4><?= $formatted_date ?></h4>
                        <p><?= $formatted_time ?></p>
                    </div>
                </div>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Status</div>
                        <div class="status-badge status-<?= $status_color ?>">
                            <i class="fas fa-circle"></i>
                            <?= $appointment['status'] ?>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Created</div>
                        <div class="info-value"><?= date('M j, Y g:i A', strtotime($appointment['created_at'])) ?></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <h5 class="section-title">
                    <i class="fas fa-user"></i>
                    Patient Information
                </h5>
                
                <div class="avatar-section">
                    <div class="avatar patient-avatar">
                        <?= strtoupper(substr($appointment['patient_first_name'], 0, 1) . substr($appointment['patient_last_name'], 0, 1)) ?>
                    </div>
                    <div class="person-details">
                        <h5><?= htmlspecialchars($appointment['patient_first_name'] . " " . $appointment['patient_last_name']) ?></h5>
                        <p>Patient ID: <?= $appointment['patient_id'] ?> • Age: <?= $patient_age ?> years</p>
                    </div>
                </div>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Date of Birth</div>
                        <div class="info-value"><?= date('F j, Y', strtotime($appointment['date_of_birth'])) ?></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <h5 class="section-title">
                    <i class="fas fa-user-md"></i>
                    Doctor Information
                </h5>
                
                <div class="avatar-section">
                    <div class="avatar doctor-avatar">
                        <?= strtoupper(substr($appointment['doctor_first_name'], 0, 1) . substr($appointment['doctor_last_name'], 0, 1)) ?>
                    </div>
                    <div class="person-details">
                        <h5>Dr. <?= htmlspecialchars($appointment['doctor_first_name'] . " " . $appointment['doctor_last_name']) ?></h5>
                        <p><?= htmlspecialchars($appointment['specialty']) ?></p>
                    </div>
                </div>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Specialty</div>
                        <div class="info-value"><?= htmlspecialchars($appointment['specialty']) ?></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <h5 class="section-title">
                    <i class="fas fa-clipboard"></i>
                    Appointment Details
                </h5>
                
                <div class="reason-section">
                    <div class="info-label">Reason for Visit</div>
                    <div class="reason-text"><?= nl2br(htmlspecialchars($appointment['reason'])) ?></div>
                </div>
            </div>

            <div class="action-buttons">
                <a href="patient_details.php?patient_id=<?= $appointment['patient_id'] ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Patient Details
                </a>
                <a href="all_appointments.php" class="btn btn-primary">
                    <i class="fas fa-calendar-alt"></i> View All Appointments
                </a>
                <button onclick="window.print()" class="btn btn-success">
                    <i class="fas fa-print"></i> Print Details
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.addEventListener('DOMContentLoaded', function() {
   
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);


    document.querySelectorAll('.section').forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'all 0.6s ease-out';
        observer.observe(section);
    });

    
    document.querySelectorAll('.info-item').forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.02)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

 
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
});


function showPrintNotification() {
    const notification = document.createElement('div');
    notification.className = 'alert alert-info';
    notification.innerHTML = '<i class="fas fa-info-circle"></i> Preparing print view...';
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '10000';
    notification.style.minWidth = '300px';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}


const originalPrint = window.print;
window.print = function() {
    showPrintNotification();
    setTimeout(originalPrint, 100);
};
</script>

</body>
</html>
