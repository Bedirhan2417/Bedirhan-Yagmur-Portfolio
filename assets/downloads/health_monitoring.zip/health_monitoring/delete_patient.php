<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'config.php';

$success_message = '';
$error_message = '';


if (!isset($_GET['patient_id']) || empty($_GET['patient_id'])) {
    $error_message = "Patient ID is required.";
} else {
    $patient_id = intval($_GET['patient_id']);
    

    $stmt = $conn->prepare("SELECT * FROM patients WHERE patient_id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $error_message = "Patient not found.";
    } else {
        $patient = $result->fetch_assoc();
        
      
        $conn->begin_transaction();
        
        try {
         
            
       
            $stmt = $conn->prepare("DELETE FROM health_data WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
          
            $stmt = $conn->prepare("DELETE FROM appointments WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
           
            $stmt = $conn->prepare("DELETE FROM messages WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
           
            $stmt = $conn->prepare("DELETE FROM emergency_alerts WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
        
            $stmt = $conn->prepare("DELETE FROM patient_locations WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
       
            $stmt = $conn->prepare("DELETE FROM patient_history WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
            
            $stmt = $conn->prepare("DELETE FROM family_members WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
            
            $stmt = $conn->prepare("DELETE FROM patients WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
       
            $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ? AND user_type = 'patient'");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            
        
            $conn->commit();
            
            $success_message = "Patient '{$patient['first_name']} {$patient['last_name']}' has been successfully deleted.";
            
        } catch (Exception $e) {
         
            $conn->rollback();
            $error_message = "Error deleting patient: " . $e->getMessage();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Patient - Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="animations.js"></script>
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --dark-color: #1e293b;
            --light-bg: #f8fafc;
            --card-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            --border-radius: 20px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .result-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            padding: 3rem;
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 500px;
            text-align: center;
            animation: slideInUp 0.6s ease-out;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .result-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2rem;
            color: white;
        }

        .success-icon {
            background: linear-gradient(135deg, var(--success-color), #059669);
            box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
        }

        .error-icon {
            background: linear-gradient(135deg, var(--danger-color), #dc2626);
            box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
        }

        .result-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .success-title {
            color: var(--success-color);
        }

        .error-title {
            color: var(--danger-color);
        }

        .result-message {
            color: var(--dark-color);
            font-size: 1.1rem;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .btn-group {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
            color: white;
            text-decoration: none;
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--dark-color);
        }

        .btn-secondary:hover {
            background: var(--gray-300);
            transform: translateY(-2px);
            color: var(--dark-color);
            text-decoration: none;
        }

        @media (max-width: 768px) {
            .result-container {
                padding: 2rem;
                margin: 1rem;
            }

            .btn-group {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="result-container">
        <?php if (!empty($success_message)): ?>
            <div class="result-icon success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h2 class="result-title success-title">Success!</h2>
            <p class="result-message"><?php echo htmlspecialchars($success_message); ?></p>
        <?php elseif (!empty($error_message)): ?>
            <div class="result-icon error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2 class="result-title error-title">Error</h2>
            <p class="result-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        
        <div class="btn-group">
            <a href="patient_list.php" class="btn btn-primary">
                <i class="fas fa-users"></i>
                Back to Patient List
            </a>
            <a href="caretaker_dashboard.php" class="btn btn-secondary">
                <i class="fas fa-home"></i>
                Dashboard
            </a>
        </div>
    </div>

    <script>
   
        <?php if (!empty($success_message)): ?>
        setTimeout(function() {
            window.location.href = 'patient_list.php';
        }, 3000);
        <?php endif; ?>
    </script>
</body>
</html> 