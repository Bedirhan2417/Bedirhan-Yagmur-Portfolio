<?php
session_start();


$logged_in_user_id = null;
$logged_in_user_type = null;

if (isset($_SESSION['user_id']) && isset($_SESSION['user_type'])) {
    $logged_in_user_id = $_SESSION['user_id'];
    $logged_in_user_type = $_SESSION['user_type'];
    echo "🔐 Detected logged-in user: ID=$logged_in_user_id, Type=$logged_in_user_type\n\n";
} else {
    echo "⚠️ No active session detected. Will process all patients.\n\n";
}

require_once 'config.php';

try {
  
    if ($logged_in_user_id && $logged_in_user_type === 'caretaker') {
        echo "🔄 Starting health data update for logged-in caretaker ID: $logged_in_user_id\n\n";
        
        
        $patient_query = "SELECT patient_id, user_id FROM patients WHERE user_id = ?";
        $stmt = $conn->prepare($patient_query);
        $stmt->bind_param("i", $logged_in_user_id);
        $stmt->execute();
        $patient_result = $stmt->get_result();
        
        if (!$patient_result) {
            die("❌ Error: " . $conn->error);
        }
        
        $caretaker_name = "Logged-in Caretaker ID: $logged_in_user_id";
        
    } else {
        echo "🔄 Starting health data update for all patients...\n\n";
        
        
        $patient_query = "SELECT patient_id, user_id FROM patients";
        $patient_result = $conn->query($patient_query);
        
        if (!$patient_result) {
            throw new Exception("Query failed: " . $conn->error);
        }
        
        $caretaker_name = "All Caretakers";
    }

    $conn->begin_transaction();

    $updated_count = 0;
    $alert_count = 0;
    $caretaker_stats = [];

    while ($row = $patient_result->fetch_assoc()) {
        $patient_id = $row['patient_id'];
        $user_id = $row['user_id'];

        
        $current_query = "SELECT heart_rate, blood_pressure, oxygen_level, body_temperature 
                          FROM health_data WHERE patient_id = ?";
        $stmt = $conn->prepare($current_query);
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $current_result = $stmt->get_result();

        if ($current_result->num_rows === 0) {
            continue; 
        }

        $current_data = $current_result->fetch_assoc();

        
        $condition = "HR: {$current_data['heart_rate']} | BP: {$current_data['blood_pressure']} | O2: {$current_data['oxygen_level']} | Temp: {$current_data['body_temperature']}°C";

        $insert_history = "INSERT INTO patient_history 
            (patient_id, date_recorded, previous_condition, created_at)
            VALUES (?, NOW(), ?, NOW())";

        $stmt_insert = $conn->prepare($insert_history);
        $stmt_insert->bind_param("is", $patient_id, $condition);
        $stmt_insert->execute();

        
        $heart_rate = rand(50, 120);
        $blood_pressure_systolic = rand(90, 170);
        $blood_pressure_diastolic = rand(60, 110);
        $blood_pressure = $blood_pressure_systolic . '/' . $blood_pressure_diastolic;
        $step_count = rand(0, 15000);
        $oxygen_level = rand(85, 100);
        $body_temperature = rand(350, 400) / 10; // 35.0°C - 40.0°C
        $fall_detected = rand(0, 1);

        
        $update_sql = "UPDATE health_data SET 
            heart_rate = ?, 
            blood_pressure = ?, 
            step_count = ?, 
            oxygen_level = ?, 
            body_temperature = ?, 
            fall_detected = ?, 
            updated_at = NOW()
            WHERE patient_id = ?";

        $stmt_update = $conn->prepare($update_sql);
        $stmt_update->bind_param("isiidsi", $heart_rate, $blood_pressure, $step_count, $oxygen_level, $body_temperature, $fall_detected, $patient_id);
        $stmt_update->execute();

        
        $alerts = [];
        $alert_severity = [];

        
        if ($heart_rate < 50) {
            $alerts[] = "Critical: Very low heart rate: $heart_rate bpm";
            $alert_severity[] = 'critical';
        } elseif ($heart_rate > 100) {
            $alerts[] = "Critical: High heart rate: $heart_rate bpm";
            $alert_severity[] = 'critical';
        }

        
        if ($blood_pressure_systolic > 160 || $blood_pressure_diastolic > 100) {
            $alerts[] = "Critical: High blood pressure: $blood_pressure";
            $alert_severity[] = 'critical';
        }

        
        if ($oxygen_level < 90) {
            $alerts[] = "Critical: Low oxygen level: $oxygen_level%";
            $alert_severity[] = 'critical';
        }

        
        if ($body_temperature > 39.0 || $body_temperature < 35.0) {
            $alerts[] = "Critical: Abnormal body temperature: $body_temperature °C";
            $alert_severity[] = 'critical';
        }

        
        if ($fall_detected == 1) {
            $alerts[] = "Critical: Fall detected!";
            $alert_severity[] = 'critical';
        }

        
        foreach ($alerts as $index => $alert_message) {
            if ($alert_severity[$index] === 'critical') {
                $alert_sql = "INSERT INTO emergency_alerts 
                              (patient_id, alert_message, is_resolved, created_at)
                              VALUES (?, ?, 0, NOW())";

                $stmt_alert = $conn->prepare($alert_sql);
                $stmt_alert->bind_param("is", $patient_id, $alert_message);
                $stmt_alert->execute();
                $alert_count++;
            }
        }

        
        if (!isset($caretaker_stats[$user_id])) {
            $caretaker_stats[$user_id] = 0;
        }
        $caretaker_stats[$user_id]++;

        $updated_count++;
    }

    
    $conn->commit();
    
    echo "✅ Successfully updated health data for $updated_count patients\n";
    echo "⚠️ Generated $alert_count new critical alerts\n";
    echo "\n📊 Caretaker Statistics:\n";
    
    foreach ($caretaker_stats as $caretaker_id => $patient_count) {
        echo "   Caretaker ID $caretaker_id: $patient_count patients updated\n";
    }
    
    echo "\n🎉 Health data update completed successfully!\n";

} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
    }
    echo "❌ Error: " . $e->getMessage() . "\n";
} finally {
    if (isset($stmt)) $stmt->close();
    if (isset($stmt_insert)) $stmt_insert->close();
    if (isset($stmt_update)) $stmt_update->close();
    if (isset($stmt_alert)) $stmt_alert->close();
}
?>
