<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['user_type'] !== 'caretaker') {
    header('Location: login.php');
    exit();
}

$caretaker_id = $_SESSION['user_id'];

require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_POST['patient_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $relationship = $_POST['relationship'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $emergency_contact = isset($_POST['emergency_contact']) ? 1 : 0;
    $notification_preferences = $_POST['notification_preferences'];


    $verify_stmt = $conn->prepare("SELECT patient_id FROM patients WHERE patient_id = ? AND user_id = ?");
    $verify_stmt->bind_param("ii", $patient_id, $caretaker_id);
    $verify_stmt->execute();
    $verify_result = $verify_stmt->get_result();
    
    if ($verify_result->num_rows === 0) {
        $error = "Error: Patient not found or not assigned to you";
    } else {
        $stmt = $conn->prepare("INSERT INTO family_members (patient_id, first_name, last_name, relationship, phone, email, emergency_contact, notification_preferences, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("isssssis", $patient_id, $first_name, $last_name, $relationship, $phone, $email, $emergency_contact, $notification_preferences);
        
        if ($stmt->execute()) {
            header("Location: family_members.php");
            exit();
        } else {
            $error = "Error: " . $stmt->error;
        }
    }
}


$patients = $conn->prepare("SELECT patient_id, first_name, last_name FROM patients WHERE user_id = ? ORDER BY first_name, last_name");
$patients->bind_param("i", $caretaker_id);
$patients->execute();
$patients_result = $patients->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Family Member - Healthcare System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            padding: 40px 0;
        }

        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .form-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            backdrop-filter: blur(10px);
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .form-header {
            background: linear-gradient(45deg, #00416A, #0078b4);
            padding: 25px 30px;
            color: white;
        }

        .form-title {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .form-subtitle {
            margin: 5px 0 0;
            opacity: 0.8;
            font-size: 0.9rem;
        }

        .form-body {
            padding: 30px;
        }

        .input-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-label {
            color: #00416A;
            font-weight: 500;
            margin-bottom: 8px;
            font-size: 0.95rem;
        }

        .form-control, .form-select {
            border: 2px solid #e1e1e1;
            border-radius: 12px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
        }

        .form-control:focus, .form-select:focus {
            border-color: #00416A;
            box-shadow: 0 0 0 0.2rem rgba(0, 65, 106, 0.1);
            transform: translateY(-2px);
        }

        .relationship-suggestions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 10px;
        }

        .relationship-tag {
            background: rgba(0, 65, 106, 0.1);
            color: #00416A;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .relationship-tag:hover {
            background: rgba(0, 65, 106, 0.2);
            transform: translateY(-2px);
        }

        .form-check {
            margin: 25px 0;
            padding-left: 35px;
        }

        .form-check-input {
            width: 20px;
            height: 20px;
            margin-left: -35px;
            border: 2px solid #00416A;
        }

        .form-check-input:checked {
            background-color: #00416A;
            border-color: #00416A;
        }

        .form-check-label {
            font-weight: 500;
            color: #00416A;
            padding-top: 2px;
        }

        .notification-options {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }

        .notification-option {
            flex: 1;
            text-align: center;
            padding: 15px;
            border: 2px solid #e1e1e1;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .notification-option:hover {
            border-color: #00416A;
            transform: translateY(-2px);
        }

        .notification-option.active {
            border-color: #00416A;
            background: rgba(0, 65, 106, 0.1);
        }

        .notification-option i {
            font-size: 1.5rem;
            color: #00416A;
            margin-bottom: 8px;
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn-submit {
            flex: 2;
            background: linear-gradient(45deg, #00416A, #0078b4);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 65, 106, 0.2);
        }

        .btn-cancel {
            flex: 1;
            background: #f8f9fa;
            border: none;
            color: #00416A;
            padding: 12px 30px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-cancel:hover {
            background: #e9ecef;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 15px;
            }

            .form-header {
                padding: 20px;
            }

            .form-body {
                padding: 20px;
            }

            .btn-group {
                flex-direction: column;
            }

            .notification-options {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="form-card">
            <div class="form-header">
                <h2 class="form-title">
                    <i class="fas fa-user-plus me-2"></i>Add Family Member
                </h2>
                <p class="form-subtitle">Connect family members to patient care network</p>
            </div>

            <div class="form-body">
                <form method="post" action="" id="familyMemberForm">
                    <div class="input-group">
                        <label class="form-label">
                            <i class="fas fa-hospital-user me-2"></i>Select Patient
                        </label>
                        <select class="form-select" name="patient_id" required>
                            <option value="">-- Select Patient --</option>
                            <?php while ($row = $patients_result->fetch_assoc()): ?>
                                <option value="<?php echo $row['patient_id']; ?>">
                                    <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <label class="form-label">
                                    <i class="fas fa-user me-2"></i>First Name
                                </label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <label class="form-label">
                                    <i class="fas fa-user me-2"></i>Last Name
                                </label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="form-label">
                            <i class="fas fa-heart me-2"></i>Relationship
                        </label>
                        <input type="text" name="relationship" class="form-control" placeholder="e.g., Parent, Sibling, Spouse, Child, Guardian" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <label class="form-label">
                                    <i class="fas fa-phone me-2"></i>Phone Number
                                </label>
                                <input type="tel" name="phone" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <label class="form-label">
                                    <i class="fas fa-envelope me-2"></i>Email Address
                                </label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="emergency_contact" id="emergency_contact">
                        <label class="form-check-label" for="emergency_contact">
                            Set as Emergency Contact
                        </label>
                    </div>

                    <div class="input-group">
                        <label class="form-label">
                            <i class="fas fa-bell me-2"></i>Notification Preferences
                        </label>
                        <select name="notification_preferences" class="form-control" required>
                            <option value="">Select Notification Method</option>
                            <option value="Email">Email</option>
                            <option value="SMS">SMS</option>
                        </select>
                    </div>



                    <div class="btn-group">
                        <button type="submit" class="btn btn-submit">
                            <i class="fas fa-save me-2"></i>Save Family Member
                        </button>
                        <a href="family_members.php" class="btn btn-cancel">
                            <i class="fas fa-times me-2"></i>Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>


</body>
</html> 