<?php
session_start();


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
if ($patient_id <= 0) {
    die("Invalid patient ID.");
}


$sql_patient = "SELECT * FROM patients WHERE patient_id = ?";
$stmt_patient = $conn->prepare($sql_patient);
$stmt_patient->bind_param("i", $patient_id);
$stmt_patient->execute();
$result_patient = $stmt_patient->get_result();

if ($result_patient->num_rows === 0) {
    die("Patient not found.");
}
$patient = $result_patient->fetch_assoc();


$sql_health_data = "SELECT * FROM health_data WHERE patient_id = ?";
$stmt_health_data = $conn->prepare($sql_health_data);
$stmt_health_data->bind_param("i", $patient_id);
$stmt_health_data->execute();
$result_health_data = $stmt_health_data->get_result();

if ($result_health_data->num_rows > 0) {
    $health_data = $result_health_data->fetch_assoc();
    $health_data_exists = true;
} else {
    $health_data_exists = false;
    $health_data = [
        'heart_rate' => '',
        'blood_pressure' => '',
        'step_count' => '',
        'oxygen_level' => '',
        'body_temperature' => '',

        'fall_detected' => '0'
    ];
}

$messages = [
    'success' => '',
    'error' => ''
];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF kontrolü
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('Invalid CSRF token.');
    }


    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $contact_number = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');

    $heart_rate = trim($_POST['heart_rate'] ?? '');
    $blood_pressure = trim($_POST['blood_pressure'] ?? '');
    $step_count = intval($_POST['step_count'] ?? 0);
    $oxygen_level = trim($_POST['oxygen_level'] ?? '');
    $body_temperature = trim($_POST['body_temperature'] ?? '');

    $fall_detected = $_POST['fall_detected'] ?? '0';


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $messages['error'] = "Invalid email format.";
    } elseif (!in_array($gender, ['Male', 'Female', 'Other'])) {
        $messages['error'] = "Invalid gender selection.";
    } else {
     
        $sql_update_patient = "UPDATE patients SET first_name=?, last_name=?, date_of_birth=?, gender=?, contact_number=?, email=?, address=? WHERE patient_id=?";
        $stmt_update_patient = $conn->prepare($sql_update_patient);
        $stmt_update_patient->bind_param("sssssssi", $first_name, $last_name, $date_of_birth, $gender, $contact_number, $email, $address, $patient_id);
        $res_patient = $stmt_update_patient->execute();

        if ($health_data_exists) {
            
            $sql_update_health_data = "UPDATE health_data SET heart_rate=?, blood_pressure=?, step_count=?, oxygen_level=?, body_temperature=?, fall_detected=? WHERE patient_id=?";
            $stmt_update_health_data = $conn->prepare($sql_update_health_data);
            $stmt_update_health_data->bind_param("ssssssi", $heart_rate, $blood_pressure, $step_count, $oxygen_level, $body_temperature, $fall_detected, $patient_id);
            $res_health = $stmt_update_health_data->execute();
        } else {
            
            $sql_insert_health_data = "INSERT INTO health_data (patient_id, heart_rate, blood_pressure, step_count, oxygen_level, body_temperature, fall_detected) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt_insert_health_data = $conn->prepare($sql_insert_health_data);
            $stmt_insert_health_data->bind_param("isssssi", $patient_id, $heart_rate, $blood_pressure, $step_count, $oxygen_level, $body_temperature, $fall_detected);
            $res_health = $stmt_insert_health_data->execute();
        }

        if ($res_patient && $res_health) {
           
            $_SESSION['success_message'] = "Patient details and health data updated successfully.";
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit();
        } else {
            $messages['error'] = "Error updating patient or health data: " . $conn->error;
        }
    }
}


if (!empty($_SESSION['success_message'])) {
    $messages['success'] = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Patient Details | Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --border-radius: 16px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            color: #1e293b;
        }

        .main-container {
            min-height: 100vh;
            padding: 2rem;
        }

        .page-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInUp 0.6s ease-out;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-header h2 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            font-weight: 700;
            font-size: 2rem;
        }

        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 1rem;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .edit-form-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInUp 0.6s ease-out;
            animation-delay: 0.1s;
        }

        .form-section {
            padding: 2.5rem;
            border-bottom: 1px solid #e2e8f0;
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #e2e8f0;
        }

        .section-title i {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .form-control, .form-select {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            outline: none;
        }

        .form-label {
            font-weight: 600;
            color: #374151;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .health-metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .metric-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 1.5rem;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .metric-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), #7c3aed);
        }

        .metric-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.15);
            transform: translateY(-2px);
        }

        .metric-icon {
            color: var(--primary-color);
            margin-right: 0.75rem;
            font-size: 1.1rem;
        }

        .btn {
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-hover), #6d28d9);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
            color: white;
        }

        .btn-secondary {
            background: white;
            color: var(--secondary-color);
            border: 2px solid #e2e8f0;
        }

        .btn-secondary:hover {
            background: #f8fafc;
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-1px);
        }

        .alert {
            border-radius: var(--border-radius);
            margin-bottom: 2rem;
            border: none;
            padding: 1.25rem 1.5rem;
            font-weight: 500;
        }

        .alert-success {
            background: linear-gradient(135deg, #ecfdf5, #d1fae5);
            color: var(--success-color);
            border-left: 4px solid var(--success-color);
        }

        .alert-danger {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: var(--danger-color);
            border-left: 4px solid var(--danger-color);
        }

        .alert i {
            margin-right: 0.75rem;
        }

        .patient-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--success-color), #059669);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .patient-info {
            text-align: center;
            margin-bottom: 2rem;
        }

        .patient-info h4 {
            color: #1e293b;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .patient-info p {
            color: var(--secondary-color);
            font-size: 0.9rem;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        @media (max-width: 768px) {
            .main-container {
                padding: 1rem;
            }
            .form-section {
                padding: 1.5rem;
            }
            .health-metrics {
                grid-template-columns: 1fr;
            }
            .action-buttons {
                flex-direction: column;
            }
        }

        /* Loading animation */
        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(5px);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #e2e8f0;
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Form validation styles */
        .form-control.is-invalid {
            border-color: var(--danger-color);
            box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1);
        }

        .invalid-feedback {
            color: var(--danger-color);
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>

<div class="main-container">
    <div class="page-header">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="patient_list.php">Patients</a></li>
                <li class="breadcrumb-item"><a href="patient_details.php?patient_id=<?= $patient_id ?>">Patient Details</a></li>
                <li class="breadcrumb-item active">Edit Patient</li>
            </ol>
        </nav>
        <h2><i class="fas fa-user-edit"></i> Edit Patient Details</h2>
        <p class="text-muted">Update information for <?php echo htmlspecialchars($patient['first_name'] . " " . $patient['last_name']); ?></p>
    </div>

    <?php if ($messages['success']): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $messages['success']; ?>
        </div>
    <?php endif; ?>

    <?php if ($messages['error']): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> <?php echo $messages['error']; ?>
        </div>
    <?php endif; ?>

    <div class="edit-form-card">
        <div class="patient-info">
            <div class="patient-avatar">
                <?= strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1)) ?>
            </div>
            <h4><?php echo htmlspecialchars($patient['first_name'] . " " . $patient['last_name']); ?></h4>
            <p>Patient ID: <?= $patient_id ?> • Age: <?= date('Y') - date('Y', strtotime($patient['date_of_birth'])) ?> years</p>
        </div>

        <form method="POST" id="editForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <div class="form-section">
                <h3 class="section-title">
                    <i class="fas fa-user"></i>
                    Personal Information
                </h3>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="first_name" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" 
                               value="<?php echo htmlspecialchars($patient['first_name']); ?>" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" 
                               value="<?php echo htmlspecialchars($patient['last_name']); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label for="date_of_birth" class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 
                               value="<?php echo htmlspecialchars($patient['date_of_birth']); ?>" required>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="">Select gender</option>
                            <option value="Male" <?php echo ($patient['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo ($patient['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo ($patient['gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label for="contact_number" class="form-label">Contact Number</label>
                        <input type="tel" class="form-control" id="contact_number" name="contact_number" 
                               value="<?php echo htmlspecialchars($patient['contact_number']); ?>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?php echo htmlspecialchars($patient['email']); ?>" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3" 
                                  required><?php echo htmlspecialchars($patient['address']); ?></textarea>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h3 class="section-title">
                    <i class="fas fa-heartbeat"></i>
                    Health Metrics
                </h3>
                <div class="health-metrics">
                    <div class="metric-card">
                        <label for="heart_rate" class="form-label">
                            <i class="fas fa-heart metric-icon"></i> Heart Rate (bpm)
                        </label>
                        <input type="number" class="form-control" id="heart_rate" name="heart_rate" 
                               value="<?php echo htmlspecialchars($health_data['heart_rate']); ?>" required>
                    </div>

                    <div class="metric-card">
                        <label for="blood_pressure" class="form-label">
                            <i class="fas fa-tachometer-alt metric-icon"></i> Blood Pressure
                        </label>
                        <input type="text" class="form-control" id="blood_pressure" name="blood_pressure" 
                               value="<?php echo htmlspecialchars($health_data['blood_pressure']); ?>" 
                               placeholder="120/80" required>
                    </div>

                    <div class="metric-card">
                        <label for="oxygen_level" class="form-label">
                            <i class="fas fa-lungs metric-icon"></i> Oxygen Level (%)
                        </label>
                        <input type="number" class="form-control" id="oxygen_level" name="oxygen_level" 
                               value="<?php echo htmlspecialchars($health_data['oxygen_level']); ?>" 
                               min="0" max="100" required>
                    </div>

                    <div class="metric-card">
                        <label for="body_temperature" class="form-label">
                            <i class="fas fa-thermometer-half metric-icon"></i> Body Temperature (°C)
                        </label>
                        <input type="number" step="0.1" class="form-control" id="body_temperature" name="body_temperature" 
                               value="<?php echo htmlspecialchars($health_data['body_temperature']); ?>" 
                               min="30" max="45" required>
                    </div>

                    <div class="metric-card">
                        <label for="step_count" class="form-label">
                            <i class="fas fa-walking metric-icon"></i> Step Count
                        </label>
                        <input type="number" class="form-control" id="step_count" name="step_count" 
                               value="<?php echo htmlspecialchars($health_data['step_count']); ?>" 
                               min="0" required>
                    </div>


                </div>
            </div>

            <div class="form-section">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="fall_detected" class="form-label">Fall Detected</label>
                        <select class="form-select" id="fall_detected" name="fall_detected" required>
                            <option value="0" <?php echo ($health_data['fall_detected'] == '0') ? 'selected' : ''; ?>>No</option>
                            <option value="1" <?php echo ($health_data['fall_detected'] == '1') ? 'selected' : ''; ?>>Yes</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="action-buttons">
                <a href="patient_list.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary" id="submitBtn">
                    <i class="fas fa-save"></i> Update Patient Details
                </button>
            </div>
        </form>
    </div>
</div>


<div class="loading" id="loading">
    <div class="spinner"></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.getElementById('editForm').addEventListener('submit', function(e) {
  
    document.getElementById('loading').style.display = 'flex';
    

    const requiredFields = this.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    

    const email = document.getElementById('email');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email.value && !emailRegex.test(email.value)) {
        email.classList.add('is-invalid');
        isValid = false;
    }
    
    if (!isValid) {
        e.preventDefault();
        document.getElementById('loading').style.display = 'none';
        alert('Please fill in all required fields correctly.');
        return false;
    }
    
    return true;
});


document.querySelectorAll('.form-control, .form-select').forEach(field => {
    field.addEventListener('blur', function() {
        if (this.hasAttribute('required') && !this.value.trim()) {
            this.classList.add('is-invalid');
        } else {
            this.classList.remove('is-invalid');
        }
    });
    
    field.addEventListener('input', function() {
        if (this.classList.contains('is-invalid')) {
            this.classList.remove('is-invalid');
        }
    });
});


document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('.form-section');
    sections.forEach((section, index) => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(20px)';
        section.style.transition = 'all 0.6s ease-out';
        
        setTimeout(() => {
            section.style.opacity = '1';
            section.style.transform = 'translateY(0)';
        }, index * 100);
    });
});
</script>
</body>
</html> 