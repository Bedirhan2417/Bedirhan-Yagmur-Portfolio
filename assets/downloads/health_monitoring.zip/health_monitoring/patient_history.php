<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if (!isset($_GET['patient_id']) || empty($_GET['patient_id'])) {
    die('Patient ID is missing');
}

$patient_id = intval($_GET['patient_id']);


$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT first_name, last_name, date_of_birth, gender FROM patients WHERE patient_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('Patient not found');
}

$patient = $result->fetch_assoc();


$patient_medical_sql = "SELECT medical_history FROM patients WHERE patient_id = ?";
$patient_medical_stmt = $conn->prepare($patient_medical_sql);
$patient_medical_stmt->bind_param("i", $patient_id);
$patient_medical_stmt->execute();
$patient_medical_result = $patient_medical_stmt->get_result();
$patient_medical = $patient_medical_result->fetch_assoc();





$sql_history = "SELECT date_recorded, previous_condition FROM patient_history WHERE patient_id = ? ORDER BY date_recorded DESC";
$stmt_history = $conn->prepare($sql_history);
$stmt_history->bind_param("i", $patient_id);
$stmt_history->execute();
$result_history = $stmt_history->get_result();


function getWeeklyTrends($conn, $patient_id, $metric) {
    $sql = "SELECT 
                DATE(date_recorded) as date,
                AVG($metric) as avg_value,
                COUNT(*) as record_count
            FROM patient_history 
            WHERE patient_id = ? 
            AND date_recorded >= DATE_SUB(NOW(), INTERVAL 4 WEEK)
            AND $metric IS NOT NULL
            GROUP BY DATE(date_recorded)
            ORDER BY date ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    return $stmt->get_result();
}

function getMonthlyTrends($conn, $patient_id, $metric) {
    $sql = "SELECT 
                DATE_FORMAT(date_recorded, '%Y-%m') as month,
                AVG($metric) as avg_value,
                COUNT(*) as record_count
            FROM patient_history 
            WHERE patient_id = ? 
            AND date_recorded >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            AND $metric IS NOT NULL
            GROUP BY DATE_FORMAT(date_recorded, '%Y-%m')
            ORDER BY month ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    return $stmt->get_result();
}


$health_data_sql = "SELECT 
                        DATE(date_recorded) as date_only,
                        previous_condition
                    FROM patient_history 
                    WHERE patient_id = ? 
                    AND date_recorded >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
                    ORDER BY date_recorded ASC";
$health_stmt = $conn->prepare($health_data_sql);
$health_stmt->bind_param("i", $patient_id);
$health_stmt->execute();
$health_data_result = $health_stmt->get_result();


$daily_data = [
    'heart_rate' => [],
    'blood_pressure' => [],
    'temperature' => [],
    'oxygen' => []
];

while ($row = $health_data_result->fetch_assoc()) {
    $date = $row['date_only'];
    $condition = $row['previous_condition'];
    
    
    if ($condition) {
        
        if (preg_match('/HR:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['heart_rate'][$date][] = intval($matches[1]);
        } elseif (preg_match('/Heart Rate:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['heart_rate'][$date][] = intval($matches[1]);
        } elseif (preg_match('/Heart:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['heart_rate'][$date][] = intval($matches[1]);
        }
        
        
        if (preg_match('/BP:\s*(\d+)\/(\d+)/i', $condition, $matches)) {
            $daily_data['blood_pressure'][$date][] = [
                'systolic' => intval($matches[1]),
                'diastolic' => intval($matches[2])
            ];
        } elseif (preg_match('/Blood Pressure:\s*(\d+)\/(\d+)/i', $condition, $matches)) {
            $daily_data['blood_pressure'][$date][] = [
                'systolic' => intval($matches[1]),
                'diastolic' => intval($matches[2])
            ];
        } elseif (preg_match('/Pressure:\s*(\d+)\/(\d+)/i', $condition, $matches)) {
            $daily_data['blood_pressure'][$date][] = [
                'systolic' => intval($matches[1]),
                'diastolic' => intval($matches[2])
            ];
        }
        
        
        if (preg_match('/Temp:\s*(\d+\.?\d*)/i', $condition, $matches)) {
            $daily_data['temperature'][$date][] = floatval($matches[1]);
        } elseif (preg_match('/Temperature:\s*(\d+\.?\d*)/i', $condition, $matches)) {
            $daily_data['temperature'][$date][] = floatval($matches[1]);
        } elseif (preg_match('/Temp[^:]*:\s*(\d+\.?\d*)/i', $condition, $matches)) {
            $daily_data['temperature'][$date][] = floatval($matches[1]);
        }
        
        
        if (preg_match('/O2:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['oxygen'][$date][] = intval($matches[1]);
        } elseif (preg_match('/Oxygen:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['oxygen'][$date][] = intval($matches[1]);
        } elseif (preg_match('/O2[^:]*:\s*(\d+)/i', $condition, $matches)) {
            $daily_data['oxygen'][$date][] = intval($matches[1]);
        }
    }
}


$trend_data = [
    'heart_rate' => [],
    'blood_pressure' => [],
    'temperature' => [],
    'oxygen' => []
];

foreach ($daily_data['heart_rate'] as $date => $values) {
    if (!empty($values)) {
        $trend_data['heart_rate'][] = [
            'date' => $date, 
            'value' => round(array_sum($values) / count($values), 1)
        ];
    }
}

foreach ($daily_data['blood_pressure'] as $date => $values) {
    if (!empty($values)) {
        $avg_systolic = round(array_sum(array_column($values, 'systolic')) / count($values));
        $avg_diastolic = round(array_sum(array_column($values, 'diastolic')) / count($values));
        $trend_data['blood_pressure'][] = [
            'date' => $date, 
            'systolic' => $avg_systolic,
            'diastolic' => $avg_diastolic
        ];
    }
}

foreach ($daily_data['temperature'] as $date => $values) {
    if (!empty($values)) {
        $trend_data['temperature'][] = [
            'date' => $date, 
            'value' => round(array_sum($values) / count($values), 1)
        ];
    }
}

foreach ($daily_data['oxygen'] as $date => $values) {
    if (!empty($values)) {
        $trend_data['oxygen'][] = [
            'date' => $date, 
            'value' => round(array_sum($values) / count($values))
        ];
    }
}


$trend_data_json = json_encode($trend_data);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?> - Medical History & Trends</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .main-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.2rem 1.2rem 2rem 1.2rem;
        }
        .page-header, .history-container, .trends-container {
            border-radius: 14px;
            margin-left: 0;
            margin-right: 0;
            width: 100%;
        }

        .page-header {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%);
            pointer-events: none;
        }

        .patient-info {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            position: relative;
            z-index: 1;
        }

        .patient-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: 600;
            box-shadow: var(--shadow-lg);
            border: 3px solid var(--white);
            overflow: hidden;
        }

        .patient-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .patient-details h1 {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 0.5rem;
        }

        .patient-details .subtitle {
            color: var(--gray-600);
            font-size: 1.1rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .back-button {
            background: linear-gradient(135deg, var(--gray-600) 0%, var(--gray-700) 100%);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
        }

        .back-button:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .trends-container {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .trends-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .trends-header h2 {
            color: var(--gray-800);
            font-weight: 700;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .trend-filters {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .trend-filter-btn {
            padding: 0.5rem 1rem;
            border: 1px solid var(--gray-200);
            border-radius: 8px;
            background: var(--white);
            color: var(--gray-600);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .trend-filter-btn.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .trend-filter-btn:hover {
            border-color: var(--primary-color);
            color: var(--primary-color);
        }

        .trend-filter-btn.active:hover {
            color: white;
        }

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .chart-card {
            background: var(--gray-100);
            border-radius: 16px;
            padding: 1.5rem;
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .chart-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            background: var(--white);
        }

        .chart-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .chart-title {
            font-weight: 600;
            color: var(--gray-700);
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chart-icon {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
        }

        .chart-icon.heart { background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%); }
        .chart-icon.blood { background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%); }
        .chart-icon.temp { background: linear-gradient(135deg, var(--info-color) 0%, #22d3ee 100%); }
        .chart-icon.oxygen { background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%); }
        .chart-icon.sugar { background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%); }
        .chart-icon.weight { background: linear-gradient(135deg, #f97316 0%, #fb923c 100%); }
        .chart-icon.step { background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); }
        .chart-icon.water { background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%); }

        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }

        .no-data-message {
            text-align: center;
            padding: 2rem;
            color: var(--gray-500);
            font-style: italic;
        }

        .history-container {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .history-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .history-header h2 {
            color: var(--gray-800);
            font-weight: 700;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .history-count {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .timeline {
            position: relative;
            padding-left: 2rem;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 1rem;
            top: 0;
            bottom: 0;
            width: 2px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }

        .history-entry {
            position: relative;
            background: var(--gray-100);
            border-radius: 12px;
            padding: 1.2rem;
            margin-bottom: 1.2rem;
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
            animation: fadeInUp 0.5s ease;
        }

        .history-entry:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            background: var(--white);
        }

        .history-entry::before {
            content: '';
            position: absolute;
            left: -2.5rem;
            top: 1.5rem;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: 3px solid var(--white);
            box-shadow: var(--shadow-md);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .entry-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .entry-date {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary-color);
            font-weight: 600;
            font-size: 1rem;
        }

        .entry-time {
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary-color);
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .entry-content {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }

        .info-section {
            background: var(--white);
            border-radius: 12px;
            padding: 1rem;
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .info-section:hover {
            border-color: var(--primary-color);
            box-shadow: var(--shadow-sm);
        }

        .info-section h6 {
            color: var(--gray-700);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-section p {
            color: var(--gray-800);
            margin: 0;
            line-height: 1.6;
            white-space: pre-line;
        }

        .info-section .icon {
            width: 20px;
            height: 20px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            color: white;
        }

        .icon.condition { background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%); }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray-600);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 1rem;
        }

        .empty-state h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 0;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .btn-modern {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-modern:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-primary-modern {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }

        .btn-success-modern {
            background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%);
            color: white;
        }

        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .entry-content {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .main-content {
                padding: 0.5rem;
            }
            .patient-info {
                flex-direction: column;
                text-align: center;
            }
            .trends-header, .history-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            .trend-filters {
                flex-wrap: wrap;
                justify-content: center;
            }
            .charts-grid {
                grid-template-columns: 1fr;
            }
            .entry-content {
                grid-template-columns: 1fr;
            }
            .timeline {
                padding-left: 1.5rem;
            }
            .timeline::before {
                left: 0.5rem;
            }
            .history-entry::before {
                left: -1.5rem;
            }
            .action-buttons {
                flex-direction: column;
            }
            .btn-modern {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        
        <div class="page-header">
            <div class="patient-info">
                <?php
                
                $dob = isset($patient['date_of_birth']) ? new DateTime($patient['date_of_birth']) : null;
                $now = new DateTime();
                $age = $dob ? $now->diff($dob)->y : '';
                ?>
                <div class="patient-info" style="display: flex; align-items: center; gap: 2rem; margin-bottom: 1.5rem;">
                    <div class="patient-avatar" style="width: 90px; height: 90px; border-radius: 50%; overflow: hidden; box-shadow: 0 4px 16px rgba(37,99,235,0.15); border: 3px solid #fff; background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); display: flex; align-items: center; justify-content: center;">
                        <?php
                            
                            $initials = strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1));
                            echo '<span style="font-size: 2.5rem; font-weight: 700; color: white;">' . $initials . '</span>';
                        ?>
                    </div>
                    <div class="patient-details">
                        <h1 style="font-size:2rem;font-weight:700;margin-bottom:0.3rem;"><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h1>
                        <div class="subtitle" style="color:#475569;font-size:1.1rem;font-weight:500;display:flex;align-items:center;gap:0.5rem;">
                            <i class="fas fa-chart-line"></i>
                            Medical History & Trend Analysis
                        </div>
                        <div style="margin-top:0.5rem;">
                            <span style="background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;padding:0.3rem 1rem;border-radius:20px;font-size:0.95rem;font-weight:600;display:inline-block;margin-right:0.5rem;">
                                ID: <?php echo $patient_id; ?>
                            </span>
                            <?php if ($age !== ''): ?>
                            <span style="background:linear-gradient(135deg,#10b981,#34d399);color:white;padding:0.3rem 1rem;border-radius:20px;font-size:0.95rem;font-weight:600;display:inline-block;">
                                Age: <?php echo $age; ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
        </div>

        
        <div class="history-entry" style="margin-top: 1.5rem; background: var(--gray-100); border-radius: 16px; padding: 1.5rem; border: 1px solid var(--gray-200); box-shadow: var(--shadow-lg);">
            <div class="entry-header" style="border-bottom: 1px solid var(--gray-200); margin-bottom: 1rem; padding-bottom: 0.75rem;">
                <div class="entry-date" style="color: var(--primary-color); font-weight: 600; font-size: 1rem;">
                    <i class="fas fa-user"></i>  Medical Info
                </div>
            </div>
            <div class="entry-content" style="display: grid; grid-template-columns: 1fr; gap: 1rem;">
                <div class="info-section">
                    <h6><div class="icon condition"><i class="fas fa-notes-medical"></i></div>Medical History</h6>
                    <p><?php echo nl2br(htmlspecialchars($patient_medical['medical_history'] ?? 'None')) ?: 'None'; ?></p>
                </div>
            </div>
        </div>

        
        <div class="trends-container">
            <div class="trends-header">
                <h2>
                    <i class="fas fa-chart-line"></i>
                    Health Trends & Analytics
                </h2>
                <div class="trend-filters">
                    <button class="trend-filter-btn active" data-period="weekly">Weekly</button>
                    <button class="trend-filter-btn" data-period="monthly">Monthly</button>
                    <button class="trend-filter-btn" data-period="3months">3 Months</button>
                </div>
            </div>

            <div class="charts-grid">
                
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <div class="chart-icon heart">
                                <i class="fas fa-heartbeat"></i>
                            </div>
                            Heart Rate Trends
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="heartRateChart"></canvas>
                    </div>
                </div>

                
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <div class="chart-icon blood">
                                <i class="fas fa-tint"></i>
                            </div>
                            Blood Pressure Trends
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="bloodPressureChart"></canvas>
                    </div>
                </div>

               
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <div class="chart-icon temp">
                                <i class="fas fa-thermometer-half"></i>
                            </div>
                            Body Temperature Trends
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="temperatureChart"></canvas>
                    </div>
                </div>

                
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <div class="chart-icon oxygen">
                                <i class="fas fa-lungs"></i>
                            </div>
                            Oxygen Level Trends
                        </div>
                    </div>
                    <div class="chart-container">
                        <canvas id="oxygenChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="history-container">
            <div class="history-header">
                <h2>
                    <i class="fas fa-history"></i>
                    Medical History Timeline
                </h2>
                <div class="history-count">
                    <?php echo $result_history->num_rows; ?> Records
                </div>
            </div>

            <?php if ($result_history->num_rows > 0): ?>
                <div class="timeline">
                    <?php while($history = $result_history->fetch_assoc()): ?>
                        <div class="history-entry">
                            <div class="entry-header">
                                <div class="entry-date">
                                    <i class="fas fa-calendar-alt"></i>
                                    <?php echo date("d M Y", strtotime($history['date_recorded'])); ?>
                                </div>
                                <div class="entry-time">
                                    <?php echo date("H:i", strtotime($history['date_recorded'])); ?>
                                </div>
                            </div>
                            
                            <div class="entry-content">
                                <div class="info-section">
                                    <h6>
                                        <div class="icon condition">
                                            <i class="fas fa-stethoscope"></i>
                                        </div>
                                        Previous Condition
                                    </h6>
                                    <p><?php echo htmlspecialchars($history['previous_condition']); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-file-medical"></i>
                    <h4>No Medical History Records</h4>
                    <p>No medical history records found for this patient. Records will appear here once they are added.</p>
                </div>
            <?php endif; ?>

            
            <div class="action-buttons">
                <a href="patient_list.php" class="btn-modern btn-primary-modern">
                    <i class="fas fa-arrow-left"></i>
                    Back to Patient List
                </a>
                <a href="patient_details.php?patient_id=<?php echo $patient_id; ?>" class="btn-modern btn-success-modern">
                    <i class="fas fa-user"></i>
                    View Patient Details
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        
        const trendData = <?php echo $trend_data_json; ?>;
        let currentPeriod = 'weekly';
        let charts = {};

        
        Chart.defaults.font.family = 'Inter, sans-serif';
        Chart.defaults.color = '#475569';

        
        document.querySelectorAll('.trend-filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.trend-filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                currentPeriod = this.dataset.period;
                updateCharts();
            });
        });

        
        function filterDataByPeriod(data, period) {
            if (!data || data.length === 0) return [];
            
            const now = new Date();
            let cutoffDate;
            
            switch(period) {
                case 'weekly':
                    cutoffDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
                    break;
                case 'monthly':
                    cutoffDate = new Date(now.getTime() - (30 * 24 * 60 * 60 * 1000));
                    break;
                case '3months':
                    cutoffDate = new Date(now.getTime() - (90 * 24 * 60 * 60 * 1000));
                    break;
                default:
                    cutoffDate = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
            }
            
            let filteredData = data.filter(item => new Date(item.date) >= cutoffDate);
            
            
            if (filteredData.length > 30) {
                const step = Math.ceil(filteredData.length / 30);
                filteredData = filteredData.filter((_, index) => index % step === 0);
            }
            
            return filteredData;
        }

        
        function updateCharts() {
            Object.keys(charts).forEach(chartName => {
                if (charts[chartName]) {
                    const filteredData = filterDataByPeriod(trendData[chartName] || [], currentPeriod);
                    updateChartData(charts[chartName], filteredData, chartName);
                }
            });
        }

        
        function updateChartData(chart, data, chartType) {
            if (!data || data.length === 0) {
                chart.data.labels = [];
                chart.data.datasets[0].data = [];
                chart.update();
                return;
            }

            const labels = data.map(item => item.date);
            let values;

            if (chartType === 'blood_pressure') {
                values = data.map(item => ({
                    systolic: item.systolic,
                    diastolic: item.diastolic
                }));
                
                chart.data.datasets[0].data = values.map(v => v.systolic);
                chart.data.datasets[1].data = values.map(v => v.diastolic);
            } else {
                values = data.map(item => item.value);
                chart.data.datasets[0].data = values;
            }

            chart.data.labels = labels;
            chart.update();
        }

        
        function createChart(canvasId, chartType, label, color, unit = '') {
            const ctx = document.getElementById(canvasId);
            if (!ctx) return null;

            const config = {
                type: 'line',
                data: {
                    labels: [],
                    datasets: []
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: chartType === 'blood_pressure',
                            position: 'top'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed.y !== null) {
                                        label += context.parsed.y + unit;
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            type: 'time',
                            time: {
                                unit: currentPeriod === 'weekly' ? 'day' : 'week',
                                displayFormats: {
                                    day: 'MMM dd',
                                    week: 'MMM dd'
                                }
                            },
                            title: {
                                display: true,
                                text: 'Date'
                            },
                            ticks: {
                                maxTicksLimit: currentPeriod === 'weekly' ? 7 : 12,
                                maxRotation: 45
                            }
                        },
                        y: {
                            title: {
                                display: true,
                                text: label
                            },
                            beginAtZero: false,
                            ticks: {
                                maxTicksLimit: 8
                            }
                        }
                    },
                    interaction: {
                        mode: 'nearest',
                        axis: 'x',
                        intersect: false
                    },
                    elements: {
                        point: {
                            radius: currentPeriod === 'weekly' ? 4 : 2,
                            hoverRadius: 6,
                            hitRadius: 10
                        },
                        line: {
                            tension: 0.2,
                            borderWidth: 2
                        }
                    }
                }
            };

            if (chartType === 'blood_pressure') {
                config.data.datasets = [
                    {
                        label: 'Systolic',
                        data: [],
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        fill: true,
                        borderWidth: 2,
                        tension: 0.2,
                        pointRadius: currentPeriod === 'weekly' ? 4 : 2
                    },
                    {
                        label: 'Diastolic',
                        data: [],
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        fill: true,
                        borderWidth: 2,
                        tension: 0.2,
                        pointRadius: currentPeriod === 'weekly' ? 4 : 2
                    }
                ];
            } else {
                config.data.datasets = [{
                    label: label,
                    data: [],
                    borderColor: color,
                    backgroundColor: color.replace(')', ', 0.1)').replace('rgb', 'rgba'),
                    fill: true,
                    borderWidth: 2,
                    tension: 0.2,
                    pointRadius: currentPeriod === 'weekly' ? 4 : 2,
                    pointHoverRadius: 6
                }];
            }

            return new Chart(ctx, config);
        }

        
        document.addEventListener('DOMContentLoaded', function() {
            
            charts.heart_rate = createChart('heartRateChart', 'line', 'Heart Rate (BPM)', 'rgb(239, 68, 68)', ' BPM');
            
            
            charts.blood_pressure = createChart('bloodPressureChart', 'blood_pressure', 'Blood Pressure', 'rgb(245, 158, 11)', ' mmHg');
            
            
            charts.temperature = createChart('temperatureChart', 'line', 'Temperature (°C)', 'rgb(6, 182, 212)', '°C');
            
            
            charts.oxygen = createChart('oxygenChart', 'line', 'Oxygen Saturation (%)', 'rgb(16, 185, 129)', '%');
            
            
            updateCharts();
        });

        
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        
        document.querySelectorAll('.history-entry').forEach(entry => {
            entry.style.opacity = '0';
            entry.style.transform = 'translateY(20px)';
            entry.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(entry);
        });

        
        document.querySelectorAll('.info-section').forEach(section => {
            section.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            
            section.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });

        
        document.querySelectorAll('.chart-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-4px)';
                this.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.1)';
            });
        });
    </script>
</body>
</html>
