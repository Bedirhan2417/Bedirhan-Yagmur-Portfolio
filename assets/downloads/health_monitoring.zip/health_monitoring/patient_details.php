<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$username = $_SESSION['email'];


$servername = "localhost"; 
$username_db = "root"; 
$password_db = ""; 
$dbname = "health_monitoring"; 


$conn = new mysqli($servername, $username_db, $password_db, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$patient_id = isset($_GET['patient_id']) ? $_GET['patient_id'] : 0;


$sql_patient = "SELECT * FROM patients WHERE patient_id = ?";
$stmt_patient = $conn->prepare($sql_patient);
$stmt_patient->bind_param("i", $patient_id);
$stmt_patient->execute();
$result_patient = $stmt_patient->get_result();

if ($result_patient->num_rows > 0) {
    $patient = $result_patient->fetch_assoc();
} else {
    echo "Patient not found.";
    exit();
}


$sql_health_data = "SELECT * FROM health_data WHERE patient_id = ?";
$stmt_health_data = $conn->prepare($sql_health_data);
$stmt_health_data->bind_param("i", $patient_id);
$stmt_health_data->execute();
$result_health_data = $stmt_health_data->get_result();

if ($result_health_data->num_rows > 0) {
    $health_data = $result_health_data->fetch_assoc();
} else {
    $health_data = null;
}


function getHealthRecommendations($health_data) {
    $recommendations = [];
    
    
    if ($health_data['heart_rate'] > 120) {
        $recommendations[] = [
            'type' => 'danger',
            'icon' => 'fas fa-heartbeat',
            'title' => 'High Heart Rate Alert',
            'message' => 'Heart rate is significantly elevated. Consider:',
            'actions' => [
                'Rest immediately and avoid physical exertion',
                'Check for stress or anxiety triggers',
                'Monitor for chest pain or shortness of breath',
                'Contact healthcare provider if symptoms persist'
            ]
        ];
    } elseif ($health_data['heart_rate'] > 100) {
        $recommendations[] = [
            'type' => 'warning',
            'icon' => 'fas fa-exclamation-triangle',
            'title' => 'Elevated Heart Rate',
            'message' => 'Heart rate is above normal range. Recommendations:',
            'actions' => [
                'Take deep breaths and relax',
                'Avoid caffeine and stimulants',
                'Monitor for 15-20 minutes',
                'Seek medical attention if it doesn\'t normalize'
            ]
        ];
    } elseif ($health_data['heart_rate'] < 60) {
        $recommendations[] = [
            'type' => 'warning',
            'icon' => 'fas fa-heartbeat',
            'title' => 'Low Heart Rate Alert',
            'message' => 'Heart rate is below normal range. Consider:',
            'actions' => [
                'Check if patient is taking beta-blockers',
                'Monitor for dizziness or fainting',
                'Ensure adequate hydration',
                'Contact healthcare provider if symptoms persist'
            ]
        ];
    }
    
    
    if ($health_data['body_temperature'] > 38.5) {
        $recommendations[] = [
            'type' => 'danger',
            'icon' => 'fas fa-thermometer-half',
            'title' => 'High Fever Alert',
            'message' => 'Body temperature indicates fever. Immediate actions:',
            'actions' => [
                'Take fever-reducing medication (acetaminophen/ibuprofen)',
                'Apply cool compresses to forehead and neck',
                'Stay hydrated with water and clear fluids',
                'Seek immediate medical attention if temperature > 39°C'
            ]
        ];
    } elseif ($health_data['body_temperature'] > 37.5) {
        $recommendations[] = [
            'type' => 'warning',
            'icon' => 'fas fa-thermometer-half',
            'title' => 'Elevated Temperature',
            'message' => 'Temperature is slightly elevated. Monitor and:',
            'actions' => [
                'Rest and avoid strenuous activities',
                'Monitor for other symptoms (cough, fatigue)',
                'Stay hydrated and cool',
                'Contact doctor if symptoms worsen'
            ]
        ];
    } elseif ($health_data['body_temperature'] < 36.1) {
        $recommendations[] = [
            'type' => 'danger',
            'icon' => 'fas fa-thermometer-half',
            'title' => 'Low Body Temperature',
            'message' => 'Body temperature is below normal. Consider:',
            'actions' => [
                'Ensure patient is warm and dry',
                'Check for hypothermia symptoms',
                'Provide warm blankets and fluids',
                'Contact healthcare provider if temperature < 35°C'
            ]
        ];
    }
    
    
    if ($health_data['oxygen_level'] < 90) {
        $recommendations[] = [
            'type' => 'danger',
            'icon' => 'fas fa-lungs',
            'title' => 'Critical Oxygen Level',
            'message' => 'Oxygen saturation is dangerously low! Emergency actions:',
            'actions' => [
                'Call emergency services immediately',
                'Sit upright to improve breathing',
                'Remove any tight clothing around chest',
                'Do not delay seeking medical help'
            ]
        ];
    } elseif ($health_data['oxygen_level'] < 95) {
        $recommendations[] = [
            'type' => 'warning',
            'icon' => 'fas fa-lungs',
            'title' => 'Low Oxygen Level',
            'message' => 'Oxygen saturation is below normal. Consider:',
            'actions' => [
                'Practice deep breathing exercises',
                'Avoid lying flat on back',
                'Monitor for shortness of breath',
                'Contact healthcare provider'
            ]
        ];
    }
    
    
    if (isset($health_data['blood_pressure'])) {
        list($systolic, $diastolic) = explode('/', $health_data['blood_pressure']);
        $systolic = (int)$systolic;
        $diastolic = (int)$diastolic;
        
        if ($systolic > 140 || $diastolic > 90) {
            $recommendations[] = [
                'type' => 'danger',
                'icon' => 'fas fa-tachometer-alt',
                'title' => 'High Blood Pressure Alert',
                'message' => 'Blood pressure is elevated. Immediate actions:',
                'actions' => [
                    'Reduce salt intake immediately',
                    'Practice relaxation techniques',
                    'Monitor blood pressure every 2 hours',
                    'Contact healthcare provider if BP > 160/100'
                ]
            ];
        } elseif ($systolic > 120 || $diastolic > 80) {
            $recommendations[] = [
                'type' => 'warning',
                'icon' => 'fas fa-exclamation-triangle',
                'title' => 'Elevated Blood Pressure',
                'message' => 'Blood pressure is above optimal range. Consider:',
                'actions' => [
                    'Reduce sodium in diet',
                    'Increase physical activity',
                    'Manage stress levels',
                    'Monitor blood pressure daily'
                ]
            ];
        } elseif ($systolic < 90 || $diastolic < 60) {
            $recommendations[] = [
                'type' => 'warning',
                'icon' => 'fas fa-tachometer-alt',
                'title' => 'Low Blood Pressure',
                'message' => 'Blood pressure is below normal. Consider:',
                'actions' => [
                    'Increase salt intake moderately',
                    'Stay hydrated with water',
                    'Avoid sudden position changes',
                    'Contact healthcare provider if symptoms persist'
                ]
            ];
        }
    }
    
    
    if ($health_data['step_count'] < 5000) {
        $recommendations[] = [
            'type' => 'info',
            'icon' => 'fas fa-shoe-prints',
            'title' => 'Low Activity Level',
            'message' => 'Daily step count is below recommended level. Suggestions:',
            'actions' => [
                'Take short walks throughout the day',
                'Use stairs instead of elevator',
                'Park further from destinations',
                'Set daily step goals (start with 6,000)'
            ]
        ];
    } elseif ($health_data['step_count'] > 10000) {
        $recommendations[] = [
            'type' => 'success',
            'icon' => 'fas fa-shoe-prints',
            'title' => 'Excellent Activity Level',
            'message' => 'Daily step count exceeds recommendations! Keep it up:',
            'actions' => [
                'Maintain current activity level',
                'Consider adding strength training',
                'Monitor for any overuse symptoms',
                'Stay hydrated during activities'
            ]
        ];
    }
    
    
    if (isset($health_data['fall_detected']) && $health_data['fall_detected']) {
        $recommendations[] = [
            'type' => 'danger',
            'icon' => 'fas fa-exclamation-triangle',
            'title' => 'Fall Detected!',
            'message' => 'A fall has been detected. Emergency protocol:',
            'actions' => [
                'Check patient immediately for injuries',
                'Assess consciousness and breathing',
                'Call emergency services if needed',
                'Do not move patient if serious injury suspected'
            ]
        ];
    }
    
    
    if (isset($health_data['medicine_status'])) {
        $medicine_status = strtolower(trim($health_data['medicine_status']));
        if ($medicine_status === 'missed' || $medicine_status === 'skipped') {
            $recommendations[] = [
                'type' => 'warning',
                'icon' => 'fas fa-pills',
                'title' => 'Missed Medication Alert',
                'message' => 'Patient has missed medication doses. Actions needed:',
                'actions' => [
                    'Check medication schedule immediately',
                    'Contact patient to confirm status',
                    'Review medication adherence',
                    'Consider medication reminder system'
                ]
            ];
        }
    }
    
    return $recommendations;
}


$dob = new DateTime($patient['date_of_birth']);
$now = new DateTime();
$age = $now->diff($dob)->y;


function getHeartRateClass($heart_rate) {
    if ($heart_rate < 60) {
        return 'text-warning'; 
    } elseif ($heart_rate >= 60 && $heart_rate <= 100) {
        return 'text-success'; 
    } else {
        return 'text-danger'; 
    }
}

function getHeartRateStatus($heart_rate) {
    if ($heart_rate < 60) {
        return 'Low';
    } elseif ($heart_rate <= 100) {
        return 'Normal';
    } else {
        return 'High';
    }
}

function getBloodPressureClass($blood_pressure) {
    if (empty($blood_pressure) || strpos($blood_pressure, '/') === false) {
        return 'text-muted'; 
    }
    
    $parts = explode('/', $blood_pressure);
    if (count($parts) !== 2) {
        return 'text-muted'; 
    }
    
    $systolic = intval($parts[0]);
    $diastolic = intval($parts[1]);
    
    if ($systolic < 90 || $diastolic < 60) {
        return 'text-warning'; 
    } elseif (($systolic >= 90 && $systolic < 120) && ($diastolic >= 60 && $diastolic < 80)) {
        return 'text-success'; 
    } else {
        return 'text-danger'; 
    }
}

function getBloodPressureStatus($blood_pressure) {
    if (empty($blood_pressure)) {
        return 'Unknown';
    }
    
    
    if (strpos($blood_pressure, '/') === false) {
        $systolic = intval($blood_pressure);
        if ($systolic < 90) {
            return 'Low';
        } elseif ($systolic >= 90 && $systolic <= 120) {
            return 'Normal';
        } else {
            return 'High';
        }
    }
    
    
    $parts = explode('/', $blood_pressure);
    if (count($parts) !== 2) {
        return 'Unknown';
    }
    
    $systolic = intval($parts[0]);
    $diastolic = intval($parts[1]);
    
    if ($systolic < 90 || $diastolic < 60) {
        return 'Low';
    } elseif (($systolic >= 90 && $systolic < 120) && ($diastolic >= 60 && $diastolic < 80)) {
        return 'Normal';
    } else {
        return 'High';
    }
}

function getStepCountClass($step_count) {
    if ($step_count < 5000) {
        return 'text-warning'; 
    } elseif ($step_count >= 5000 && $step_count <= 10000) {
        return 'text-success'; 
    } else {
        return 'text-info'; 
    }
}

function getStepCountStatus($step_count) {
    if ($step_count < 5000) {
        return 'Low';
    } elseif ($step_count <= 10000) {
        return 'Normal';
    } else {
        return 'High';
    }
}

function getOxygenLevelClass($oxygen_level) {
    if ($oxygen_level < 95) {
        return 'text-danger'; 
    } else {
        return 'text-success'; 
    }
}

function getOxygenLevelStatus($oxygen_level) {
    if ($oxygen_level < 95) {
        return 'Low';
    } else {
        return 'Normal';
    }
}

function getTemperatureClass($body_temperature) {
    if ($body_temperature < 36.1) {
        return 'text-warning'; 
    } elseif ($body_temperature >= 36.1 && $body_temperature <= 37.2) {
        return 'text-success'; 
    } else {
        return 'text-danger'; 
    }
}

function getTemperatureStatus($body_temperature) {
    if ($body_temperature < 36.1) {
        return 'Low';
    } elseif ($body_temperature <= 37.2) {
        return 'Normal';
    } else {
        return 'High';
    }
}





function getMedicineStatusClass($medicine_status) {
    $medicine_status = strtolower(trim($medicine_status));
    if ($medicine_status === 'ok' || $medicine_status === 'completed') {
        return 'text-success';
    } elseif ($medicine_status === 'missed' || $medicine_status === 'skipped') {
        return 'text-danger';
    } else {
        return 'text-warning';
    }
}

function getMedicineStatusText($medicine_status) {
    $medicine_status = strtolower(trim($medicine_status));
    if ($medicine_status === 'ok' || $medicine_status === 'completed') {
        return 'On Track';
    } elseif ($medicine_status === 'missed' || $medicine_status === 'skipped') {
        return 'Missed Dose';
    } else {
        return 'Unknown';
    }
}

function getFallDetectionStatusClass($fall_detected) {
    if ($fall_detected) { // 1 veya true ise
        return 'text-danger';
    } else {
        return 'text-success';
    }
}

function getFallDetectionStatusText($fall_detected) {
    if ($fall_detected) {
        return 'Fall Detected';
    } else {
        return 'No Falls';
    }
}






$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Patient Details - Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .main-content {
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .page-header {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%);
            pointer-events: none;
        }

        .patient-profile {
            display: flex;
            align-items: center;
            gap: 2rem;
            position: relative;
            z-index: 1;
        }

        .patient-avatar {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            font-weight: 600;
            box-shadow: 0 4px 16px rgba(37,99,235,0.15);
            border: 3px solid #fff;
            overflow: hidden;
        }

        .patient-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }



        .patient-info h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 0.5rem;
        }

        .patient-info .age-badge {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
            margin-bottom: 1rem;
        }

        .patient-info .patient-id {
            color: var(--gray-600);
            font-size: 1rem;
            font-weight: 500;
        }

        .card {
            background: var(--white);
            border-radius: 20px;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            margin-bottom: 2rem;
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-xl);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 1.5rem 2rem;
            border: none;
        }

        .card-header h5 {
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 2rem;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--gray-100);
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .info-item:hover {
            background: var(--gray-200);
            transform: translateX(5px);
        }

        .info-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            flex-shrink: 0;
        }

        .info-icon.primary { background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); }
        .info-icon.success { background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%); }
        .info-icon.warning { background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%); }
        .info-icon.danger { background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%); }
        .info-icon.info { background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%); }

        .info-content h6 {
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 0.25rem;
        }

        .info-content p {
            color: var(--gray-600);
            margin: 0;
            font-size: 0.95rem;
        }

        .health-data-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: var(--white);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
        }

        .health-data-table th {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            padding: 1.25rem 1rem;
            text-align: left;
            font-weight: 600;
            color: white;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .health-data-table td {
            padding: 1.25rem 1rem;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
            transition: all 0.3s ease;
        }

        .health-data-table tr {
            transition: all 0.3s ease;
        }

        .health-data-table tr:hover {
            background: var(--gray-50);
            transform: scale(1.01);
            box-shadow: var(--shadow-md);
        }

        .health-data-table tr:last-child td {
            border-bottom: none;
        }

        .health-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
            margin-right: 1rem;
            box-shadow: var(--shadow-md);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .health-icon::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }

        .health-icon:hover::before {
            left: 100%;
        }

        .health-icon:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: var(--shadow-lg);
        }

        .health-icon.heart-rate { 
            background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);
            animation: pulse 2s infinite;
        }

        .health-icon.blood-pressure { 
            background: linear-gradient(135deg, #3b82f6 0%, #60a5fa 100%);
        }

        .health-icon.step-count { 
            background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
        }

        .health-icon.oxygen-level { 
            background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
        }

        .health-icon.temperature { 
            background: linear-gradient(135deg, #8b5cf6 0%, #a78bfa 100%);
        }



        .health-icon.medication { 
            background: linear-gradient(135deg, #ec4899 0%, #f472b6 100%);
        }

        .health-icon.fall-detection { 
            background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
            animation: shake 0.5s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-2px); }
            75% { transform: translateX(2px); }
        }

        .health-metric {
            display: flex;
            align-items: center;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .health-metric .value {
            font-size: 1.3rem;
            margin-left: 0.5rem;
            font-weight: 700;
        }

        .health-metric .unit {
            font-size: 0.9rem;
            color: var(--gray-600);
            margin-left: 0.25rem;
        }

        .status-badge {
            padding: 0.6rem 1.2rem;
            border-radius: 25px;
            font-weight: 700;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .status-badge::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }

        .status-badge:hover::before {
            left: 100%;
        }

        .status-badge:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .status-badge.success {
            background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
            color: white;
        }

        .status-badge.danger {
            background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);
            color: white;
            animation: pulse 2s infinite;
        }

        .status-badge.warning {
            background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
            color: white;
        }

        .status-badge.info {
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            color: white;
        }

        .status-badge.low {
            background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%);
            color: white;
        }

        .status-badge.high {
            background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);
            color: white;
        }

        .status-badge.normal {
            background: linear-gradient(135deg, #10b981 0%, #34d399 100%);
            color: white;
        }

        /* Special handling for metrics where "high" is good */
        .status-badge.high.step-count {
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            color: white;
        }

        /* Special handling for oxygen level where "low" is dangerous */
        .status-badge.low.oxygen-level {
            background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);
            color: white;
            animation: pulse 2s infinite;
        }

        .health-data-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(59, 130, 246, 0.05) 100%);
            border-radius: 16px;
            border: 1px solid var(--gray-200);
        }

        .health-data-header h4 {
            color: var(--gray-800);
            font-weight: 700;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin: 0;
        }

        .health-summary {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .summary-item {
            background: var(--white);
            padding: 0.75rem 1rem;
            border-radius: 12px;
            border: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            font-weight: 600;
            box-shadow: var(--shadow-sm);
        }

        .summary-item .count {
            background: var(--primary-color);
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
        }

        .metric-name {
            font-weight: 600;
            color: var(--gray-800);
            font-size: 1rem;
        }

        .metric-description {
            color: var(--gray-600);
            font-size: 0.85rem;
            margin-top: 0.25rem;
        }

        .normal-range {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .range-text {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            color: var(--gray-700);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            border: 1px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }

        .range-text:hover {
            background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%);
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 2rem;
        }

        .btn-modern {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-modern:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-primary-modern {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }

        .btn-success-modern {
            background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%);
            color: white;
        }

        .btn-warning-modern {
            background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%);
            color: white;
        }

        .btn-info-modern {
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            color: white;
        }

        .btn-secondary-modern {
            background: linear-gradient(135deg, var(--gray-600) 0%, var(--gray-700) 100%);
            color: white;
        }

        .btn-danger-modern {
            background: linear-gradient(135deg, #ef4444 0%, #f87171 100%);
            color: white;
        }
        .btn-danger-modern:hover {
            background: linear-gradient(135deg, #b91c1c 0%, #ef4444 100%);
            color: white;
        }

        .charts-section {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
        }

        .charts-section h4 {
            color: var(--gray-800);
            font-weight: 600;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .chart-container {
            background: var(--gray-50);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid var(--gray-200);
        }

        .chart-container canvas {
            max-height: 300px;
        }

        /* Health Recommendations Styling */
        .recommendations-grid {
            display: grid;
            gap: 1.5rem;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        }

        .recommendation-card {
            border-radius: 16px;
            padding: 1.5rem;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .recommendation-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            transition: all 0.3s ease;
        }

        .recommendation-card.danger {
            background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
            border-color: #ef4444;
        }

        .recommendation-card.danger::before {
            background: linear-gradient(90deg, #ef4444, #dc2626);
        }

        .recommendation-card.warning {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-color: #f59e0b;
        }

        .recommendation-card.warning::before {
            background: linear-gradient(90deg, #f59e0b, #d97706);
        }

        .recommendation-card.info {
            background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
            border-color: #3b82f6;
        }

        .recommendation-card.info::before {
            background: linear-gradient(90deg, #3b82f6, #2563eb);
        }

        .recommendation-card.success {
            background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
            border-color: #10b981;
        }

        .recommendation-card.success::before {
            background: linear-gradient(90deg, #10b981, #059669);
        }

        .recommendation-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.15);
        }

        .recommendation-header {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .recommendation-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            flex-shrink: 0;
        }

        .recommendation-card.danger .recommendation-icon {
            background: linear-gradient(135deg, #ef4444, #dc2626);
        }

        .recommendation-card.warning .recommendation-icon {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }

        .recommendation-card.info .recommendation-icon {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
        }

        .recommendation-title h6 {
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .recommendation-title p {
            color: #475569;
            margin: 0;
            font-size: 0.95rem;
        }

        .recommendation-priority {
            margin-left: auto;
        }

        .priority-badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .priority-badge.critical {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            animation: pulse 2s infinite;
        }

        .priority-badge.warning {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }

        .priority-badge.info {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
        }

        .priority-badge.success {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }

        .recommendation-actions h6 {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 1rem;
            font-size: 1rem;
        }

        .recommendation-actions ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .recommendation-actions li {
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            color: #475569;
            font-size: 0.9rem;
            position: relative;
            padding-left: 1.5rem;
        }

        .recommendation-actions li:before {
            content: '✓';
            position: absolute;
            left: 0;
            color: #10b981;
            font-weight: 700;
        }

        .recommendation-actions li:last-child {
            border-bottom: none;
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }
            
            .patient-profile {
                flex-direction: column;
                text-align: center;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn-modern {
                justify-content: center;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }

        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--gray-600);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 1rem;
        }

        .empty-state h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <div class="main-content">
        
        <a href="caretaker_dashboard.php" class="btn-modern btn-secondary-modern mb-3" style="position:relative; top:0; left:0; z-index:10;">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-user"></i> Patient Information</h5>
            </div>
            <div class="card-body">
                <div class="d-flex flex-wrap align-items-center mb-4 gap-4">
                    <div class="patient-avatar flex-shrink-0" style="width: 90px; height: 90px; border-radius: 50%; overflow: hidden; box-shadow: 0 4px 16px rgba(37,99,235,0.15); border: 3px solid #fff; background: #f1f5f9;">
                        <?php
                            
                            $initials = strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1));
                            echo '<span style="font-size: 2rem; font-weight: 700; color: white;">' . $initials . '</span>';
                        ?>
                    </div>
                    <div class="flex-grow-1">
                        <h1 class="mb-1"><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h1>
                        <span class="age-badge">Age: <?php echo $age; ?> years</span>
                        <p class="patient-id mb-2">Patient ID: <?php echo $patient['patient_id']; ?></p>
                        
                        <div class="d-flex flex-wrap gap-2 mt-2 justify-content-start">
                            <a href="edit_patient.php?patient_id=<?php echo $patient['patient_id']; ?>" class="btn-modern btn-primary-modern">
                                <i class="fas fa-user-edit"></i> Edit Patient
                            </a>
                            <a href="chat.php?patient_id=<?php echo $patient['patient_id']; ?>" class="btn-modern btn-info-modern">
                                <i class="fas fa-comments"></i> Contact Patient
                            </a>
                            <a href="create_appointment.php?patient_id=<?php echo $patient['patient_id']; ?>" class="btn-modern btn-success-modern">
                                <i class="fas fa-calendar-plus"></i> Create Appointment
                            </a>
                            <a href="delete_patient.php?patient_id=<?php echo $patient['patient_id']; ?>" class="btn-modern btn-danger-modern" onclick="return confirm('Are you sure you want to delete this patient? This action cannot be undone.');">
                                <i class="fas fa-trash"></i> Delete Patient
                            </a>
                        </div>
                    </div>
                </div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon primary">
                            <i class="fas fa-venus-mars"></i>
                        </div>
                        <div class="info-content">
                            <h6>Gender</h6>
                            <p><?php echo htmlspecialchars($patient['gender']); ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon success">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="info-content">
                            <h6>Contact Number</h6>
                            <p><?php echo htmlspecialchars($patient['contact_number']); ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon warning">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-content">
                            <h6>Address</h6>
                            <p><?php echo htmlspecialchars($patient['address']); ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon info">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-content">
                            <h6>Email</h6>
                            <p><?php echo htmlspecialchars($patient['email']); ?></p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon danger">
                            <i class="fas fa-birthday-cake"></i>
                        </div>
                        <div class="info-content">
                            <h6>Date of Birth</h6>
                            <p><?php echo htmlspecialchars($patient['date_of_birth']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card">
                    <div class="card-header">
                <h5><i class="fas fa-heartbeat"></i> Health Data</h5>
                    </div>
            <div class="card-body">
                    <?php if ($health_data): ?>
                    
                    <div class="health-data-header">
                        <h4>
                            <i class="fas fa-chart-line"></i>
                            Real-time Health Monitoring
                        </h4>
                        <div class="health-summary">
                            <div class="summary-item">
                                <div class="count">6</div>
                                <span>Parameters</span>
                            </div>
                            <div class="summary-item">
                                <div class="count" style="background: var(--success-color);">
                                    <?php 
                                    $normalCount = 0;
                                    if (getHeartRateStatus($health_data['heart_rate']) === 'Normal') $normalCount++;
                                    if (getBloodPressureStatus($health_data['blood_pressure']) === 'Normal') $normalCount++;
                                    if (getStepCountStatus($health_data['step_count']) === 'Normal') $normalCount++;
                                    if (getOxygenLevelStatus($health_data['oxygen_level']) === 'Normal') $normalCount++;
                                    if (getTemperatureStatus($health_data['body_temperature']) === 'Normal') $normalCount++;
                                    echo $normalCount;
                                    ?>
                                </div>
                                <span>Normal</span>
                            </div>
                            <div class="summary-item">
                                <div class="count" style="background: var(--warning-color);">
                                    <?php 
                                    $lowCount = 0;
                                    if (getHeartRateStatus($health_data['heart_rate']) === 'Low') $lowCount++;
                                    if (getBloodPressureStatus($health_data['blood_pressure']) === 'Low') $lowCount++;
                                    if (getStepCountStatus($health_data['step_count']) === 'Low') $lowCount++;
                                    if (getTemperatureStatus($health_data['body_temperature']) === 'Low') $lowCount++;
                                    echo $lowCount;
                                    ?>
                                </div>
                                <span>Low</span>
                            </div>
                            <div class="summary-item">
                                <div class="count" style="background: var(--danger-color);">
                                    <?php 
                                    $highCount = 0;
                                    if (getHeartRateStatus($health_data['heart_rate']) === 'High') $highCount++;
                                    if (getBloodPressureStatus($health_data['blood_pressure']) === 'High') $highCount++;
                                    if (getOxygenLevelStatus($health_data['oxygen_level']) === 'Low') $highCount++; // Oxygen low is dangerous
                                    if (getTemperatureStatus($health_data['body_temperature']) === 'High') $highCount++;
                                    echo $highCount;
                                    ?>
                                </div>
                                <span>High/Danger</span>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="health-data-table">
                            <thead>
                                <tr>
                                    <th>Health Parameter</th>
                                    <th>Current Value</th>
                                    <th>Normal Range</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon heart-rate">
                                                <i class="fas fa-heartbeat"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Heart Rate</div>
                                                <div class="metric-description">Beats per minute (bpm)</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo htmlspecialchars($health_data['heart_rate']); ?></span>
                                            <span class="unit">bpm</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">60-100 bpm</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower(getHeartRateStatus($health_data['heart_rate'])); ?>">
                                            <i class="fas fa-<?php echo getHeartRateStatus($health_data['heart_rate']) === 'Normal' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                                            <?php echo getHeartRateStatus($health_data['heart_rate']); ?>
                                        </span>
                                    </td>
                            </tr>
                            <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon blood-pressure">
                                                <i class="fas fa-tachometer-alt"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Blood Pressure</div>
                                                <div class="metric-description">Systolic/Diastolic (mmHg)</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo htmlspecialchars($health_data['blood_pressure']); ?></span>
                                            <span class="unit">mmHg</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">90-120/60-80 mmHg</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower(getBloodPressureStatus($health_data['blood_pressure'])); ?>">
                                            <i class="fas fa-<?php echo getBloodPressureStatus($health_data['blood_pressure']) === 'Normal' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                                            <?php echo getBloodPressureStatus($health_data['blood_pressure']); ?>
                                        </span>
                                    </td>
                            </tr>
                            <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon step-count">
                                                <i class="fas fa-shoe-prints"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Daily Steps</div>
                                                <div class="metric-description">Physical activity tracking</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo number_format($health_data['step_count']); ?></span>
                                            <span class="unit">steps</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">5,000-10,000 steps</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower(getStepCountStatus($health_data['step_count'])); ?> step-count">
                                            <i class="fas fa-<?php echo getStepCountStatus($health_data['step_count']) === 'Normal' ? 'check-circle' : (getStepCountStatus($health_data['step_count']) === 'High' ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                            <?php echo getStepCountStatus($health_data['step_count']); ?>
                                        </span>
                                    </td>
                            </tr>
                            <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon oxygen-level">
                                                <i class="fas fa-lungs"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Oxygen Saturation</div>
                                                <div class="metric-description">Blood oxygen level (%)</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo htmlspecialchars($health_data['oxygen_level']); ?></span>
                                            <span class="unit">%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">≥95%</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower(getOxygenLevelStatus($health_data['oxygen_level'])); ?> oxygen-level">
                                            <i class="fas fa-<?php echo getOxygenLevelStatus($health_data['oxygen_level']) === 'Normal' ? 'check-circle' : 'exclamation-triangle'; ?>"></i>
                                            <?php echo getOxygenLevelStatus($health_data['oxygen_level']); ?>
                                        </span>
                                    </td>
                            </tr>
                            <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon temperature">
                                                <i class="fas fa-thermometer-half"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Body Temperature</div>
                                                <div class="metric-description">Core body temperature (°C)</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo htmlspecialchars($health_data['body_temperature']); ?></span>
                                            <span class="unit">°C</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">36.1-37.2°C</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo strtolower(getTemperatureStatus($health_data['body_temperature'])); ?>">
                                            <i class="fas fa-<?php echo getTemperatureStatus($health_data['body_temperature']) === 'Normal' ? 'check-circle' : 'exclamation-triangle'; ?>"></i>
                                            <?php echo getTemperatureStatus($health_data['body_temperature']); ?>
                                        </span>
                                    </td>
                            </tr>

                            <tr>
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="health-icon fall-detection">
                                                <i class="fas fa-exclamation-triangle"></i>
                                            </div>
                                            <div>
                                                <div class="metric-name">Fall Detection</div>
                                                <div class="metric-description">Safety monitoring system</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="health-metric">
                                            <span class="value"><?php echo isset($health_data['fall_detected']) && $health_data['fall_detected'] ? 'Yes' : 'No'; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="normal-range">
                                            <span class="range-text">No falls</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo isset($health_data['fall_detected']) ? (getFallDetectionStatusClass($health_data['fall_detected']) === 'text-danger' ? 'danger' : 'success') : 'warning'; ?>">
                                            <i class="fas fa-<?php echo isset($health_data['fall_detected']) ? (getFallDetectionStatusClass($health_data['fall_detected']) === 'text-danger' ? 'exclamation-triangle' : 'shield-alt') : 'question-circle'; ?>"></i>
                                            <?php echo isset($health_data['fall_detected']) ? getFallDetectionStatusText($health_data['fall_detected']) : 'No data'; ?>
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-heartbeat"></i>
                        <h4>No Health Data Available</h4>
                        <p>Health monitoring data has not been recorded for this patient yet.</p>
                    </div>
                    <?php endif; ?>
                </div>
                </div>

        
        <?php 
        $health_recommendations = getHealthRecommendations($health_data);
        if (!empty($health_recommendations)): 
        ?>
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-lightbulb"></i> Health Recommendations</h5>
            </div>
            <div class="card-body">
                <div class="recommendations-grid">
                    <?php foreach ($health_recommendations as $rec): ?>
                    <div class="recommendation-card <?php echo $rec['type']; ?>">
                        <div class="recommendation-header">
                            <div class="recommendation-icon">
                                <i class="<?php echo $rec['icon']; ?>"></i>
                            </div>
                            <div class="recommendation-title">
                                <h6><?php echo htmlspecialchars($rec['title']); ?></h6>
                                <p><?php echo htmlspecialchars($rec['message']); ?></p>
                            </div>
                            <div class="recommendation-priority">
                                <?php if ($rec['type'] === 'danger'): ?>
                                    <span class="priority-badge critical">Critical</span>
                                <?php elseif ($rec['type'] === 'warning'): ?>
                                    <span class="priority-badge warning">Warning</span>
                                <?php elseif ($rec['type'] === 'success'): ?>
                                    <span class="priority-badge success">Excellent</span>
                                <?php else: ?>
                                    <span class="priority-badge info">Info</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="recommendation-actions">
                            <h6>Recommended Actions:</h6>
                            <ul>
                                <?php foreach ($rec['actions'] as $action): ?>
                                <li><?php echo htmlspecialchars($action); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-map-marker-alt"></i> Patient GPS Location</h5>
            </div>
            <div class="card-body">
                <div id="patientMapContainer">
                    <div id="patientMap" style="height: 350px; border-radius: 15px; border: 2px solid #e2e8f0;"></div>
                    <div id="locationStatus" class="mt-3 text-muted"></div>
                </div>
            </div>
        </div>
</div>

    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    
    document.addEventListener('DOMContentLoaded', function() {
        var map = L.map('patientMap').setView([39.0, 35.0], 5); 
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var patientId = <?php echo json_encode($patient['patient_id']); ?>;
        fetch('get_locations.php')
            .then(response => response.json())
            .then(patients => {
                var found = false;
                for (const patient of patients) {
                    if (parseInt(patient.patient_id) === parseInt(patientId) && patient.latitude && patient.longitude) {
                        found = true;
                        var marker = L.marker([patient.latitude, patient.longitude], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: `<i class=\"fas fa-user-md\" style=\"color: #ef4444; font-size: 28px;\"></i>`,
                                iconSize: [28, 28]
                            })
                        }).addTo(map);
                        marker.bindPopup(`<b>${patient.first_name} ${patient.last_name}</b><br>${patient.location_name || 'No location info'}<br><small>${patient.timestamp ? new Date(patient.timestamp).toLocaleString('en-US') : ''}</small>`).openPopup();
                        map.setView([patient.latitude, patient.longitude], 14);
                        document.getElementById('locationStatus').innerHTML = `<span class='text-success'><i class='fas fa-check-circle'></i> Location found and displayed on map.</span>`;
                        break;
                    }
                }
                if (!found) {
                    document.getElementById('locationStatus').innerHTML = `<span class='text-danger'><i class='fas fa-exclamation-triangle'></i> No GPS location data available for this patient.</span>`;
                }
            })
            .catch(error => {
                document.getElementById('locationStatus').innerHTML = `<span class='text-danger'><i class='fas fa-exclamation-triangle'></i> Error loading location data.</span>`;
            });
    });
</script>
</body>
</html>
