<?php
session_start();

error_log("Session Debug - user_id: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET'));

include('config.php');

if (!$conn) {
    error_log("Database connection failed");
    die("Database connection failed");
} else {
    error_log("Database connection successful");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] == 'true') {
    header('Content-Type: application/json');
    
    error_log("AJAX POST Data: " . print_r($_POST, true));
    
    $doctor_id = isset($_POST['doctor_id']) ? $_POST['doctor_id'] : '';
    $datetime = isset($_POST['appointment_date']) ? $_POST['appointment_date'] : '';
    $reason = isset($_POST['reason']) ? $_POST['reason'] : '';
    $patient_id = isset($_POST['patient_id']) ? intval($_POST['patient_id']) : 0;
    
    if (empty($doctor_id) || empty($datetime) || empty($reason) || empty($patient_id)) {
        echo json_encode(['success' => false, 'error' => 'All fields are required']);
        exit();
    }
    
    $datetime_obj = new DateTime($datetime);
    $appointment_date = $datetime_obj->format('Y-m-d');
    $appointment_time = $datetime_obj->format('H:i:s');
    
    $status = "Scheduled";
    $created_at = date('Y-m-d H:i:s');
    $updated_at = $created_at;

    $check_sql = "SELECT COUNT(*) as count FROM appointments 
                  WHERE doctor_id = ? AND appointment_date = ? 
                  AND appointment_time = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("iss", $doctor_id, $appointment_date, $appointment_time);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $count = $check_result->fetch_assoc()['count'];
    
    if ($count > 0) {
        echo json_encode(['success' => false, 'error' => 'This time slot is already booked. Please select another time.']);
        exit();
    }
    
    $sql_appointment = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt_appointment = $conn->prepare($sql_appointment);
    if (!$stmt_appointment) {
        echo json_encode(['success' => false, 'error' => 'Prepare statement failed: ' . $conn->error]);
        exit();
    }
    
    $stmt_appointment->bind_param("iissssss", $patient_id, $doctor_id, $appointment_date, $appointment_time, $reason, $status, $created_at, $updated_at);
    
    if ($stmt_appointment->execute()) {
        $appointment_id = $stmt_appointment->insert_id;
        echo json_encode(['success' => true, 'appointment_id' => $appointment_id]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error creating appointment: ' . $stmt_appointment->error]);
    }
    exit();
}

$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;

$sql_patient = "SELECT * FROM patients WHERE patient_id = ?";
$stmt_patient = $conn->prepare($sql_patient);
$stmt_patient->bind_param("i", $patient_id);
$stmt_patient->execute();
$result_patient = $stmt_patient->get_result();

if ($result_patient->num_rows === 0) {
    echo "Patient not found.";
    exit();
}
$patient = $result_patient->fetch_assoc();

$sql_doctors = "SELECT d.*, 
                (SELECT COUNT(*) FROM appointments 
                 WHERE doctor_id = d.doctor_id 
                 AND appointment_date >= CURDATE()) as upcoming_appointments
                FROM doctors d
                ORDER BY d.last_name";
$result_doctors = $conn->query($sql_doctors);


if (!$result_doctors) {
    echo "Error: " . $conn->error;
    exit();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Appointment | Health Monitoring System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            --border-radius: 16px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            color: #1e293b;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding-top: 30px;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-xl);
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-brand {
            padding: 0 25px;
            margin-bottom: 30px;
        }

        .sidebar-brand h4 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-item {
            position: relative;
            margin: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            padding: 12px 20px !important;
            border-radius: 12px;
            display: flex !important;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white !important;
            transform: translateX(5px);
            box-shadow: var(--shadow-md);
        }

        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
            box-shadow: var(--shadow-lg);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 24px;
            text-align: center;
        }

        .main-content {
            flex-grow: 1;
            margin-left: 280px;
            padding: 2rem;
            transition: all 0.3s ease;
        }

        .page-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .page-header h2 {
            color: #1e293b;
            margin-bottom: 0.5rem;
            font-weight: 700;
            font-size: 2rem;
        }

        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 1rem;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .appointment-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            padding: 2.5rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInUp 0.6s ease-out;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title i {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .doctor-list {
            display: grid;
            gap: 1rem;
        }

        .doctor-card {
            background: white;
            border: 2px solid #e2e8f0;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .doctor-card:hover {
            border-color: var(--primary-color);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.15);
            transform: translateY(-2px);
        }

        .doctor-card.selected {
            border-color: var(--primary-color);
            background: linear-gradient(135deg, #eff6ff, #f8fafc);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.2);
        }

        .doctor-info {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .doctor-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.2rem;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }

        .doctor-details h6 {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .specialty-badge {
            background: linear-gradient(135deg, #f1f5f9, #e2e8f0);
            color: var(--secondary-color);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
            margin-left: 0.75rem;
            border: 1px solid #e2e8f0;
        }

        .appointment-count {
            color: var(--secondary-color);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .appointment-count i {
            color: var(--success-color);
        }

        .form-control {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            font-size: 1rem;
            transition: var(--transition);
            background: white;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
            outline: none;
        }

        .btn {
            padding: 1rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1rem;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
            justify-content: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-hover), #6d28d9);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
            color: white;
        }

        .btn-light {
            background: white;
            color: var(--secondary-color);
            border: 2px solid #e2e8f0;
        }

        .btn-light:hover {
            background: #f8fafc;
            border-color: var(--primary-color);
            color: var(--primary-color);
            transform: translateY(-1px);
        }

        .patient-info {
            background: linear-gradient(135deg, #eff6ff, #f8fafc);
            border: 1px solid #dbeafe;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .patient-avatar {
            width: 90px;
            height: 90px;
            background: linear-gradient(135deg, var(--primary-color), #7c3aed);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.8rem;
            box-shadow: 0 4px 16px rgba(37,99,235,0.15);
            border: 3px solid #fff;
        }



        .patient-details h5 {
            margin: 0;
            color: #1e293b;
            font-weight: 600;
            font-size: 1.5rem;
            margin-bottom: 0.3rem;
        }

        .form-section {
            margin-bottom: 2.5rem;
        }

        .datetime-wrapper {
            position: relative;
        }

        .datetime-wrapper i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary-color);
            z-index: 2;
        }

        .datetime-wrapper .form-control {
            padding-left: 3rem;
        }

        .textarea-wrapper {
            position: relative;
        }

        .textarea-wrapper i {
            position: absolute;
            left: 1rem;
            top: 1rem;
            color: var(--secondary-color);
            z-index: 2;
        }

        .textarea-wrapper textarea {
            padding-left: 3rem;
            padding-top: 1rem;
            resize: vertical;
            min-height: 120px;
        }

        .action-buttons {
            display: grid;
            gap: 1rem;
            margin-top: 2rem;
        }

        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(5px);
            z-index: 9999;
            justify-content: center;
            align-items: center;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #e2e8f0;
            border-top: 4px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                padding: 1rem;
            }
            .appointment-card {
                padding: 1.5rem;
            }
            .doctor-info {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
        }

        .menu-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1001;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px;
            cursor: pointer;
            box-shadow: var(--shadow-md);
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <button class="menu-toggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <div class="sidebar">
        <div class="sidebar-brand">
            <h4><i class="fas fa-heartbeat"></i> Caretaker</h4>
        </div>
        <nav class="nav flex-column">
            <div class="nav-item">
                <a class="nav-link" href="caretaker_dashboard.php">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="patient_list.php">
                    <i class="fas fa-users"></i> Patients
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link active" href="appointments_doctor_calendar.php">
                    <i class="fas fa-calendar-alt"></i> Doctor Appointment Calendar
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="family_members.php">
                    <i class="fas fa-user-friends"></i> Family Members
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="patient_location.php">
                    <i class="fas fa-map"></i> Patient Locations
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="messages.php">
                    <i class="fas fa-comment-dots"></i> Messages
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="emergency_dashboard.php">
                    <i class="fas fa-exclamation-triangle"></i> Emergency Dashboard
                </a>
            </div>
            <div class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>
    </div>

<div class="main-content">
    <div class="page-header">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="patient_list.php">Patients</a></li>
                <li class="breadcrumb-item"><a href="patient_details.php?patient_id=<?= $patient_id ?>">Patient Details</a></li>
                <li class="breadcrumb-item active">Create Appointment</li>
            </ol>
        </nav>
        <h2><i class="fas fa-calendar-plus"></i> Create Appointment</h2>
        <p class="text-muted">Schedule an appointment for your patient</p>
    </div>

    <div class="patient-info">
        <div class="patient-avatar">
            <?= strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1)) ?>
        </div>
        <div class="patient-details">
            <h5><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h5>
            <div style="margin-top:0.5rem;">
                <span style="background:linear-gradient(135deg,#2563eb,#3b82f6);color:white;padding:0.3rem 1rem;border-radius:20px;font-size:0.95rem;font-weight:600;display:inline-block;margin-right:0.5rem;">
                    ID: <?php echo $patient_id; ?>
                </span>
                <span style="background:linear-gradient(135deg,#10b981,#34d399);color:white;padding:0.3rem 1rem;border-radius:20px;font-size:0.95rem;font-weight:600;display:inline-block;">
                    Age: <?php echo date('Y') - date('Y', strtotime($patient['date_of_birth'])); ?> years
                </span>
            </div>
        </div>
    </div>

    <div class="appointment-card">
        <form method="POST" id="appointmentForm">
            <input type="hidden" name="ajax" value="false" id="ajaxField">
            <input type="hidden" name="patient_id" value="<?= $patient_id ?>">
            <div class="form-section">
                <h5 class="section-title">
                    <i class="fas fa-user-md"></i>
                    Select Doctor
                </h5>
                <div class="doctor-list">
                    <?php while ($doctor = $result_doctors->fetch_assoc()): ?>
                        <div class="doctor-card" onclick="selectDoctor(this, <?= $doctor['doctor_id'] ?>)">
                            <div class="doctor-info">
                                <div class="doctor-avatar">
                                    <?= strtoupper(substr($doctor['first_name'], 0, 1) . substr($doctor['last_name'], 0, 1)) ?>
                                </div>
                                <div class="doctor-details">
                                    <h6>
                                        Dr. <?= htmlspecialchars($doctor['first_name'] . " " . $doctor['last_name']) ?>
                                        <span class="specialty-badge"><?= htmlspecialchars($doctor['specialty']) ?></span>
                                    </h6>
                                    <span class="appointment-count">
                                        <i class="fas fa-calendar-check"></i> 
                                        <?= $doctor['upcoming_appointments'] ?> upcoming appointments
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                <input type="hidden" name="doctor_id" id="doctor_id" required>
            </div>

            <div class="form-section">
                <h5 class="section-title">
                    <i class="fas fa-calendar-alt"></i>
                    Select Date & Time
                </h5>
                <div class="datetime-wrapper">
                    <i class="fas fa-clock"></i>
                    <input type="datetime-local" id="appointment_date" name="appointment_date" 
                           class="form-control" required min="<?= date('Y-m-d\TH:i') ?>">
                </div>
            </div>

            <div class="form-section">
                <h5 class="section-title">
                    <i class="fas fa-clipboard"></i>
                    Appointment Details
                </h5>
                <div class="textarea-wrapper">
                    <i class="fas fa-edit"></i>
                    <textarea id="reason" name="reason" class="form-control" required
                              placeholder="Please describe the reason for this appointment, any specific concerns, or symptoms the patient is experiencing..."></textarea>
                </div>
            </div>

            <div class="action-buttons">
                <button type="submit" class="btn btn-primary" id="submitBtn">
                    <i class="fas fa-calendar-check"></i> Schedule Appointment
                </button>
                <a href="patient_details.php?patient_id=<?= $patient_id ?>" class="btn btn-light">
                    <i class="fas fa-arrow-left"></i> Back to Patient Details
                </a>
            </div>
        </form>
    </div>
</div>

<div class="loading" id="loading">
    <div class="spinner"></div>
</div>

<script>
function selectDoctor(element, doctorId) {
    document.querySelectorAll('.doctor-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    element.classList.add('selected');
    document.getElementById('doctor_id').value = doctorId;
}

document.getElementById('appointment_date').min = new Date().toISOString().slice(0, 16);

document.getElementById('appointmentForm').onsubmit = function(e) {
    e.preventDefault();
    
    if (!document.getElementById('doctor_id').value) {
        alert('Please select a doctor');
        return false;
    }
    
    document.getElementById('loading').style.display = 'flex';
    
    const formData = new FormData(this);
    formData.set('ajax', 'true');
    
    fetch('create_appointment.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('loading').style.display = 'none';
            alert('Appointment created successfully!');
            window.location.href = 'appointments_doctor_calendar.php';
        } else {
            throw new Error(data.error || 'Appointment creation failed');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('loading').style.display = 'none';
        alert('Error: ' + error.message);
    });
    
    return false;
};

function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('active');
}
</script>

</body>
</html>
