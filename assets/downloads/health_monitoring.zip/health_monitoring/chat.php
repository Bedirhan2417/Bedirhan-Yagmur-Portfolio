<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('config.php');


$sender_id = 13; 

if (!isset($_GET['patient_id']) || !is_numeric($_GET['patient_id'])) {
    die("Invalid patient ID");
}

$patient_id = intval($_GET['patient_id']);


$patient_res = mysqli_query($conn, "SELECT first_name, last_name FROM patients WHERE patient_id = $patient_id");
if (mysqli_num_rows($patient_res) == 0) {
    die("Patient not found");
}
$patient = mysqli_fetch_assoc($patient_res);


mysqli_query($conn, "UPDATE messages SET is_read = 1 WHERE patient_id = $patient_id AND sender_id = $patient_id");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $message_escaped = mysqli_real_escape_string($conn, $message);
        $insert_sql = "INSERT INTO messages (patient_id, sender_id, message, message_date, is_read)
                       VALUES ($patient_id, $sender_id, '$message_escaped', NOW(), 0)";
        mysqli_query($conn, $insert_sql);
        header("Location: chat.php?patient_id=$patient_id");
        exit();
    }
}


$msg_sql = "
    SELECT m.message_id, m.patient_id, m.sender_id, m.message, m.message_date, u.user_type
    FROM messages m
    JOIN users u ON m.sender_id = u.user_id
    WHERE m.patient_id = $patient_id
    ORDER BY m.message_date ASC
";
$msg_result = mysqli_query($conn, $msg_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat with <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            height: 100vh;
            display: flex;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding-top: 30px;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            box-shadow: var(--shadow-xl);
            position: fixed;
            height: 100vh;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-brand {
            padding: 0 25px;
            margin-bottom: 30px;
        }

        .sidebar-brand h4 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-item {
            position: relative;
            margin: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            padding: 12px 20px !important;
            border-radius: 12px;
            display: flex !important;
            align-items: center;
            gap: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
            text-decoration: none;
        }

        .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            color: white !important;
            transform: translateX(5px);
            box-shadow: var(--shadow-md);
        }

        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white !important;
            box-shadow: var(--shadow-lg);
        }

        .nav-link i {
            font-size: 1.2rem;
            width: 24px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            display: flex;
            flex-direction: column;
            height: 100vh;
            background: var(--white);
            border-radius: 20px 0 0 20px;
            box-shadow: var(--shadow-xl);
            overflow: hidden;
        }

        .chat-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 1.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow-lg);
        }

        .back-button {
            text-decoration: none;
            color: rgba(255, 255, 255, 0.9);
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.95rem;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 12px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
        }

        .back-button:hover {
            color: white;
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(-3px);
        }

        .patient-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .patient-avatar {
            width: 50px;
            height: 50px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1.3rem;
            box-shadow: var(--shadow-md);
            border: 2px solid rgba(255, 255, 255, 0.3);
        }

        .patient-details h5 {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 0;
            color: white;
        }

        .patient-details small {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
        }

        .chat-container {
            flex: 1;
            padding: 1.5rem 2.5rem;
            overflow-y: auto;
            background: #fff;
            position: relative;
        }

        .date-separator {
            text-align: center;
            margin: 2rem 0;
            position: relative;
        }

        .date-separator::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: var(--gray-300);
            z-index: 1;
        }

        .date-separator span {
            background: var(--white);
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--gray-600);
            box-shadow: var(--shadow-sm);
            position: relative;
            z-index: 2;
        }

        .message {
            margin: 1rem 0;
            display: flex;
            align-items: flex-end;
            gap: 12px;
            animation: fadeInUp 0.3s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.sent {
            flex-direction: row-reverse;
        }

        .message-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        .message.sent .message-avatar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }

        .message.received .message-avatar {
            background: var(--gray-300);
            color: var(--gray-700);
        }

        .message-content {
            max-width: 98%;
            position: relative;
        }

        .message-bubble {
            padding: 16px 24px;
            border-radius: 20px;
            position: relative;
            word-wrap: break-word;
            box-shadow: var(--shadow-sm);
            font-size: 1.05rem;
        }

        .message.sent .message-bubble {
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            color: white;
            border-bottom-right-radius: 8px;
        }

        .message.received .message-bubble {
            background: #f1f5f9;
            color: var(--gray-800);
            border-bottom-left-radius: 8px;
            border: 1px solid var(--gray-200);
        }

        .message-time {
            font-size: 0.75rem;
            margin-top: 6px;
            opacity: 0.8;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .message.sent .message-time {
            justify-content: flex-end;
            color: rgba(255, 255, 255, 0.8);
        }

        .message.received .message-time {
            color: var(--gray-600);
        }

        .message-status {
            font-size: 0.7rem;
            margin-top: 4px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .message.sent .message-status {
            justify-content: flex-end;
            color: rgba(255, 255, 255, 0.7);
        }

        .message.received .message-status {
            color: var(--gray-500);
        }

        .message-input-container {
            background: #fff;
            padding: 1.5rem 2.5rem;
            border-top: 1px solid var(--gray-200);
            box-shadow: var(--shadow-lg);
        }

        .message-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
        }

        .message-input-wrapper {
            flex: 1;
            position: relative;
        }

        .message-input {
            width: 100%;
            border: 2px solid var(--gray-200);
            border-radius: 25px;
            padding: 18px 24px;
            resize: none;
            min-height: 50px;
            max-height: 120px;
            font-family: inherit;
            font-size: 1.05rem;
            transition: all 0.3s ease;
            background: #f8fafc;
        }

        .message-input:focus {
            outline: none;
            border-color: var(--primary-color);
            background: var(--white);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .send-button {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-md);
            flex-shrink: 0;
        }

        .send-button:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow-lg);
        }

        .send-button:active {
            transform: scale(0.95);
        }

        .typing-indicator {
            padding: 1rem 2rem;
            display: none;
            background: var(--white);
            border-top: 1px solid var(--gray-200);
        }

        .typing-dots {
            display: flex;
            gap: 4px;
            align-items: center;
        }

        .typing-dots span {
            height: 8px;
            width: 8px;
            background: var(--primary-color);
            border-radius: 50%;
            animation: typing 1.4s infinite ease-in-out;
        }

        .typing-dots span:nth-child(1) { animation-delay: -0.32s; }
        .typing-dots span:nth-child(2) { animation-delay: -0.16s; }

        @keyframes typing {
            0%, 80%, 100% { 
                transform: scale(0.8);
                opacity: 0.5;
            }
            40% { 
                transform: scale(1);
                opacity: 1;
            }
        }

        .empty-chat {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray-600);
        }

        .empty-chat i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 1rem;
        }

        .empty-chat h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
        }

        .empty-chat p {
            font-size: 1rem;
            margin-bottom: 0;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .main-content {
                margin-left: 0;
                border-radius: 0;
            }
            .chat-header {
                padding: 1rem;
            }
            .chat-container {
                padding: 1rem;
            }
            .message-input-container {
                padding: 1rem;
            }
            .message-content {
                max-width: 100%;
            }
        }

        /* Custom scrollbar */
        .chat-container::-webkit-scrollbar {
            width: 8px;
        }

        .chat-container::-webkit-scrollbar-track {
            background: var(--gray-100);
        }

        .chat-container::-webkit-scrollbar-thumb {
            background: var(--gray-300);
            border-radius: 4px;
        }

        .chat-container::-webkit-scrollbar-thumb:hover {
            background: var(--gray-400);
        }

        .main-content, .chat-container {
            width: 100% !important;
            max-width: 100% !important;
            padding-left: 0 !important;
            padding-right: 0 !important;
            border-radius: 0 !important;
            box-shadow: none !important;
        }

        .chat-container {
            padding: 0.5rem 0.5rem !important;
            background: #fff !important;
        }

        .message-content, .message-bubble {
            width: 100% !important;
            max-width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }

        .message-bubble {
            padding: 16px 24px;
            border-radius: 16px;
            font-size: 1.08rem;
        }

        .message.sent .message-bubble {
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            color: white;
            border-bottom-right-radius: 8px;
        }

        .message.received .message-bubble {
            background: #f1f5f9;
            color: var(--gray-800);
            border-bottom-left-radius: 8px;
            border: 1px solid var(--gray-200);
        }

        .message-input-container {
            background: #fff !important;
            padding: 0.5rem 0.5rem !important;
            border-top: 1px solid var(--gray-200);
            box-shadow: none !important;
        }

        .message-input {
            width: 100%;
            border: 2px solid var(--gray-200);
            border-radius: 25px;
            padding: 18px 24px;
            resize: none;
            min-height: 50px;
            max-height: 120px;
            font-family: inherit;
            font-size: 1.08rem;
            background: #f8fafc;
        }
    </style>
</head>
<body>
    <div class="d-flex">
 
        <div class="sidebar">
            <div class="sidebar-brand">
                <h4><i class="fas fa-heartbeat"></i> Caretaker</h4>
            </div>
            <nav class="nav flex-column">
                <div class="nav-item">
                    <a class="nav-link" href="caretaker_dashboard.php">
                        <i class="fas fa-home"></i> Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="patient_list.php">
                        <i class="fas fa-users"></i> Patients
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="appointments_doctor_calendar.php">
                        <i class="fas fa-calendar-alt"></i> Doctor Appointment Calendar
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="family_members.php">
                        <i class="fas fa-user-friends"></i> Family Members
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="patient_location.php">
                        <i class="fas fa-map"></i> Patient Locations
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="messages.php">
                        <i class="fas fa-comment-dots"></i> Messages
                    </a>
                </div>
                <div class="nav-item">
                    <a class="nav-link" href="emergency_dashboard.php">
                        <i class="fas fa-exclamation-triangle"></i> Emergency
                    </a>
                </div>
                <div class="nav-item mt-auto">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </nav>
        </div>

        <div class="main-content" style="margin-left: 280px; flex: 1; display: flex; flex-direction: column; height: 100vh; background: var(--white); border-radius: 20px 0 0 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); overflow: hidden;">
        
            <div class="chat-header" style="background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); color: white; padding: 1.5rem 2rem; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1);">
                <a href="messages.php" class="back-button" style="text-decoration: none; color: rgba(255,255,255,0.9); display: flex; align-items: center; gap: 8px; font-size: 0.95rem; font-weight: 500; padding: 8px 16px; border-radius: 12px; transition: all 0.3s ease; background: rgba(255,255,255,0.1);">
                    <i class="fas fa-arrow-left"></i>
                    Back to Messages
                </a>
                <div class="patient-info" style="display: flex; align-items: center; gap: 1.5rem;">
                    <div class="patient-avatar" style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; box-shadow: 0 4px 16px rgba(37,99,235,0.15); border: 3px solid #fff; background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%); display: flex; align-items: center; justify-content: center;">
                        <?php
                    
                            $initials = strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1));
                            echo '<span style="font-size: 1.8rem; font-weight: 700; color: white;">' . $initials . '</span>';
                        ?>
                    </div>
                    <div class="patient-details">
                        <h5 style="font-size:1.2rem;font-weight:600;margin:0;color:white;">
                            <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                        </h5>
                        <small style="color:rgba(255,255,255,0.8);font-size:0.9rem;">Patient</small>
                    </div>
                </div>
                <div style="width: 100px;"></div> 
            </div>

     
            <div class="chat-container" id="chatContainer">
                <?php 
                $prev_date = null;
                $message_count = 0;
                while ($msg = mysqli_fetch_assoc($msg_result)): 
                    $message_count++;
                    $msg_date = date('Y-m-d', strtotime($msg['message_date']));
                    if ($prev_date !== $msg_date):
                ?>
                    <div class="date-separator">
                        <span><?= date('F d, Y', strtotime($msg['message_date'])) ?></span>
                    </div>
                <?php 
                    endif;
                    $prev_date = $msg_date;
                    $is_sent = $msg['sender_id'] == $sender_id;
                    $initials = $is_sent ? 'CA' : strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1));
                ?>
                    <div class="message <?= $is_sent ? 'sent' : 'received' ?>">
                        <div class="message-avatar">
                            <?= $initials ?>
                        </div>
                        <div class="message-content">
                            <div class="message-bubble">
                                <?= nl2br(htmlspecialchars($msg['message'])) ?>
                            </div>
                            <div class="message-time">
                                <i class="fas fa-clock"></i>
                                <?= date('H:i', strtotime($msg['message_date'])) ?>
                            </div>
                            <?php if ($is_sent): ?>
                                <div class="message-status">
                                    <i class="fas fa-check-double"></i>
                                    Sent
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
                
                <?php if ($message_count === 0): ?>
                    <div class="empty-chat">
                        <i class="fas fa-comments"></i>
                        <h4>No Messages Yet</h4>
                        <p>Start a conversation with <?= htmlspecialchars($patient['first_name']) ?> by sending your first message.</p>
                    </div>
                <?php endif; ?>
            </div>

          
            <div class="typing-indicator" id="typingIndicator">
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>

         
            <div class="message-input-container">
                <form method="post" class="message-form" id="messageForm">
                    <div class="message-input-wrapper">
                        <textarea 
                            name="message" 
                            placeholder="Type your message..." 
                            required
                            class="message-input"
                            id="messageInput"
                            rows="1"
                        ></textarea>
                    </div>
                    <button type="submit" class="send-button" id="sendButton">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
     
        const chatContainer = document.getElementById('chatContainer');
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        const messageForm = document.getElementById('messageForm');
        const typingIndicator = document.getElementById('typingIndicator');


        function scrollToBottom() {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

    
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        });

     
        messageInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (this.value.trim()) {
                    messageForm.submit();
                }
            }
        });

    
        messageInput.addEventListener('input', function() {
            if (this.value.trim()) {
                sendButton.style.transform = 'scale(1.05)';
            } else {
                sendButton.style.transform = 'scale(1)';
            }
        });

       
        messageForm.addEventListener('submit', function(e) {
            if (!messageInput.value.trim()) {
                e.preventDefault();
                return;
            }
            
            sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            sendButton.disabled = true;
        });

      
        window.addEventListener('load', scrollToBottom);

   
        function checkNewMessages() {
           
            console.log('Checking for new messages...');
        }

       
        setInterval(checkNewMessages, 10000);

       
        function smoothScrollToBottom() {
            chatContainer.scrollTo({
                top: chatContainer.scrollHeight,
                behavior: 'smooth'
            });
        }

     
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList') {
                    smoothScrollToBottom();
                }
            });
        });

        observer.observe(chatContainer, {
            childList: true,
            subtree: true
        });

        
        window.addEventListener('load', function() {
            messageInput.focus();
        });
    </script>
</body>
</html>