<?php
session_start();
header('Content-Type: application/json');

require_once 'config.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'caretaker') {
    echo json_encode(['error' => true, 'message' => 'Unauthorized access']);
    exit();
}

$caretaker_id = $_SESSION['user_id'];

try {
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    $query = "
        SELECT 
            a.appointment_id as id,
            a.appointment_date,
            a.appointment_time,
            a.reason,
            a.status,
            CONCAT(p.first_name, ' ', p.last_name) as patient_name,
            p.contact_number as patient_phone,
            CONCAT(d.first_name, ' ', d.last_name) as doctor_name,
            d.specialty as doctor_specialization
        FROM appointments a
        JOIN patients p ON a.patient_id = p.patient_id
        JOIN doctors d ON a.doctor_id = d.doctor_id
        WHERE a.status != 'Cancelled' AND a.status != 'cancelled'
          AND p.user_id = ?
        ORDER BY a.appointment_date, a.appointment_time
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $caretaker_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        throw new Exception("Query failed: " . $stmt->error);
    }
    
    $appointments = [];
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }

    $events = [];
    foreach ($appointments as $appointment) {
        $dateTime = $appointment['appointment_date'];
        $start = new DateTime($dateTime);
        
        $end = clone $start;
        $end->add(new DateInterval('PT30M'));
        
        $eventClass = 'event-regular';
        
        $event = [
            'id' => $appointment['id'],
            'title' => $appointment['patient_name'],
            'start' => $start->format('Y-m-d\TH:i:s'),
            'end' => $end->format('Y-m-d\TH:i:s'),
            'description' => $appointment['reason'],
            'type' => 'regular',
            'status' => strtolower($appointment['status']),
            'patient_phone' => $appointment['patient_phone'],
            'className' => $eventClass,
            'allDay' => false,
            'doctor_name' => $appointment['doctor_name'],
            'doctor_specialization' => $appointment['doctor_specialization']
        ];
        
        $events[] = $event;
    }
    
    echo json_encode($events);
    
} catch (Exception $e) {
    error_log("Error in appointments_doctor_data.php: " . $e->getMessage());
    
    echo json_encode([
        'error' => true,
        'message' => $e->getMessage(),
        'appointments_count' => isset($appointments) ? count($appointments) : 0,
        'events_count' => isset($events) ? count($events) : 0
    ]);
}
?>
