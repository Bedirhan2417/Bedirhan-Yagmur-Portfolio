<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'config.php';

if (!isset($_GET['id'])) {
    die('No member ID provided.');
}

$member_id = intval($_GET['id']);

$stmt = $conn->prepare("DELETE FROM family_members WHERE member_id = ?");
$stmt->bind_param("i", $member_id);
$stmt->execute();

header("Location: family_members.php");
exit();
