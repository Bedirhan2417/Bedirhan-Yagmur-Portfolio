<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_GET['mark_read']) && isset($_GET['message_id'])) {
    $message_id = intval($_GET['message_id']);
    $sql_update = "UPDATE messages_emergency SET is_read = TRUE, read_date = NOW() WHERE message_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("i", $message_id);
    $stmt_update->execute();
}


$sql = "SELECT me.*, 
               fm.first_name as contact_first_name, 
               fm.last_name as contact_last_name,
               fm.relationship,
               p.first_name as patient_first_name,
               p.last_name as patient_last_name,
               u.first_name as sender_first_name,
               u.last_name as sender_last_name
        FROM messages_emergency me
        JOIN family_members fm ON me.member_id = fm.member_id
        JOIN patients p ON fm.patient_id = p.patient_id
        JOIN users u ON me.sender_id = u.user_id
        ORDER BY me.message_date DESC";

$result = $conn->query($sql);


$total_messages = 0;
$unread_messages = 0;
$today_messages = 0;

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
    $total_messages++;
    if (!$row['is_read']) $unread_messages++;
    if (date('Y-m-d', strtotime($row['message_date'])) == date('Y-m-d')) {
        $today_messages++;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Messages Dashboard - Health Monitoring</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .main-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .page-header {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(220, 38, 38, 0.05) 100%);
            pointer-events: none;
        }

        .page-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            font-size: 1.1rem;
            color: var(--gray-600);
            margin-bottom: 0;
            position: relative;
            z-index: 1;
        }

        .stats-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--white);
            border-radius: 16px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-xl);
        }

        .stat-card .icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 1.5rem;
        }

        .stat-card.total .icon { background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); }
        .stat-card.unread .icon { background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%); }
        .stat-card.today .icon { background: linear-gradient(135deg, var(--warning-color) 0%, #fbbf24 100%); }

        .stat-card h3 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 0.5rem;
        }

        .stat-card p {
            color: var(--gray-600);
            font-weight: 500;
        }

        .messages-container {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .messages-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .messages-header h3 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--gray-800);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-modern {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .btn-modern:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-primary-modern {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }

        .btn-secondary-modern {
            background: linear-gradient(135deg, var(--gray-600) 0%, var(--gray-700) 100%);
            color: white;
        }

        .message-item {
            background: var(--gray-100);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
            position: relative;
        }

        .message-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            background: var(--white);
        }

        .message-item.unread {
            border-left: 4px solid var(--danger-color);
            background: rgba(239, 68, 68, 0.05);
        }

        .message-item.unread::before {
            content: 'NEW';
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: var(--danger-color);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .message-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .message-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .contact-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.2rem;
        }

        .contact-details h5 {
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 0.25rem;
        }

        .contact-details p {
            color: var(--gray-600);
            font-size: 0.9rem;
            margin: 0;
        }

        .message-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-badge.read {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-badge.unread {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }

        .message-content {
            background: var(--white);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1rem;
            border: 1px solid var(--gray-200);
        }

        .message-content p {
            color: var(--gray-800);
            line-height: 1.6;
            margin: 0;
            white-space: pre-line;
        }

        .message-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-600);
        }

        .message-actions {
            display: flex;
            gap: 0.5rem;
        }

        .btn-small {
            padding: 0.25rem 0.75rem;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-small:hover {
            transform: translateY(-1px);
        }

        .btn-mark-read {
            background: var(--success-color);
            color: white;
        }

        .btn-view-details {
            background: var(--primary-color);
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray-600);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 1rem;
        }

        .empty-state h4 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
        }

        .empty-state p {
            font-size: 1rem;
            margin-bottom: 0;
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }
            
            .page-header h1 {
                font-size: 2rem;
            }
            
            .messages-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .message-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
       
        <div style="margin-bottom: 1rem;">
            <a href="caretaker_dashboard.php" class="btn-modern btn-secondary-modern">
                <i class="fas fa-arrow-left"></i>
                Back to Dashboard
            </a>
        </div>
       
        <div class="page-header">
            <h1>📬 Emergency Messages Dashboard</h1>
            <p>Track and manage all emergency contact messages</p>
        </div>

  
        <div class="stats-section">
            <div class="stat-card total">
                <div class="icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <h3><?php echo $total_messages; ?></h3>
                <p>Total Messages</p>
            </div>
            <div class="stat-card unread">
                <div class="icon">
                    <i class="fas fa-exclamation-circle"></i>
                </div>
                <h3><?php echo $unread_messages; ?></h3>
                <p>Unread Messages</p>
            </div>
            <div class="stat-card today">
                <div class="icon">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <h3><?php echo $today_messages; ?></h3>
                <p>Today's Messages</p>
            </div>
        </div>

     
        <div class="messages-container">
            <div class="messages-header">
                <h3>
                    <i class="fas fa-list"></i>
                    Emergency Messages
                </h3>
            </div>

            <?php if (!empty($messages)): ?>
                <?php foreach ($messages as $message): ?>
                    <div class="message-item <?php echo !$message['is_read'] ? 'unread' : ''; ?>">
                        <div class="message-header">
                            <div class="message-info">
                                
                                <div class="contact-avatar" style="width:70px;height:70px;font-size:2rem;background:linear-gradient(135deg,#f87171,#fbbf24,#60a5fa);box-shadow:0 2px 8px rgba(239,68,68,0.12);">
                                    <?php echo strtoupper(substr($message['contact_first_name'], 0, 1) . substr($message['contact_last_name'], 0, 1)); ?>
                                </div>
                                <div class="contact-details">
                                    <h5><?php echo htmlspecialchars($message['contact_first_name'] . ' ' . $message['contact_last_name']); ?></h5>
                                    <p>
                                        <strong>Patient:</strong> <?php echo htmlspecialchars($message['patient_first_name'] . ' ' . $message['patient_last_name']); ?> | 
                                        <strong>Relationship:</strong> <?php echo htmlspecialchars($message['relationship']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="message-status">
                                <span class="status-badge <?php echo $message['is_read'] ? 'read' : 'unread'; ?>">
                                    <?php echo $message['is_read'] ? 'Read' : 'Unread'; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div style="position:absolute;top:18px;left:90px;">
                            <img src="https://cdn-icons-png.flaticon.com/512/616/616494.png" alt="Emergency Icon" style="width:32px;height:32px;filter:drop-shadow(0 2px 4px rgba(239,68,68,0.12));" />
                        </div>
                        <div class="message-content">
                            <p><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                        </div>

                        <div class="message-footer">
                            <div>
                                <strong>Sent by:</strong> <?php echo htmlspecialchars($message['sender_first_name'] . ' ' . $message['sender_last_name']); ?> | 
                                <strong>Date:</strong> <?php echo date('M d, Y H:i', strtotime($message['message_date'])); ?>
                                <?php if ($message['read_date']): ?>
                                    | <strong>Read:</strong> <?php echo date('M d, Y H:i', strtotime($message['read_date'])); ?>
                                <?php endif; ?>
                            </div>
                            <div class="message-actions">
                                <?php if (!$message['is_read']): ?>
                                    <a href="?mark_read=1&message_id=<?php echo $message['message_id']; ?>" 
                                       class="btn-small btn-mark-read">
                                        <i class="fas fa-check"></i> Mark Read
                                    </a>
                                <?php endif; ?>
                                <a href="message_detail.php?id=<?php echo $message['message_id']; ?>" 
                                   class="btn-small btn-view-details">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <img src="https://undraw.co/api/illustrations/undraw_mail_box_re_dvds.svg" alt="No Messages" style="max-width:220px;width:100%;margin-bottom:1rem;" />
                    <h4>No Emergency Messages</h4>
                    <p>No emergency messages have been sent yet. Start by sending your first emergency message.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
     
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);


        document.querySelectorAll('.message-item').forEach(item => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(item);
        });


        let unreadCount = <?php echo $unread_messages; ?>;
        if (unreadCount > 0) {
            setTimeout(() => {
                location.reload();
            }, 30000); 
        }
    </script>
</body>
</html> 