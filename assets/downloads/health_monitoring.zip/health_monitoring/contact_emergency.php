<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "health_monitoring";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;

if ($patient_id <= 0) {
    echo "Invalid patient ID.";
    exit();
}


$sql_patient = "SELECT first_name, last_name FROM patients WHERE patient_id = ?";
$stmt_patient = $conn->prepare($sql_patient);
$stmt_patient->bind_param("i", $patient_id);
$stmt_patient->execute();
$result_patient = $stmt_patient->get_result();
if ($result_patient->num_rows > 0) {
    $patient = $result_patient->fetch_assoc();
} else {
    echo "Patient not found.";
    exit();
}

$sql_emergency = "SELECT member_id, first_name, last_name, relationship, phone, email 
                  FROM family_members 
                  WHERE patient_id = ? AND emergency_contact = 1 LIMIT 1";
$stmt_emergency = $conn->prepare($sql_emergency);
$stmt_emergency->bind_param("i", $patient_id);
$stmt_emergency->execute();
$result_emergency = $stmt_emergency->get_result();

if ($result_emergency->num_rows > 0) {
    $emergency_contact = $result_emergency->fetch_assoc();
} else {
    echo "No emergency contact found for this patient.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = trim($_POST['message']);
    if ($message === '') {
        $error = "Message cannot be empty.";
    } else {
        $sender_id = $_SESSION['user_id'];
        
        $sql_message = "INSERT INTO messages_emergency (member_id, sender_id, message, message_date) VALUES (?, ?, ?, NOW())";
        $stmt_message = $conn->prepare($sql_message);
        $stmt_message->bind_param("iis", $emergency_contact['member_id'], $sender_id, $message);
        
        if ($stmt_message->execute()) {
            $success = "Message sent successfully to the emergency contact.";
        } else {
            $error = "Error sending message: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Contact Emergency Contact - Health Monitoring System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #3b82f6;
            --accent-color: #60a5fa;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-bg: #f8fafc;
            --white: #ffffff;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            color: var(--gray-800);
            line-height: 1.6;
        }

        .main-content {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
        }

        .page-header {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .page-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(220, 38, 38, 0.05) 100%);
            pointer-events: none;
        }

        .page-header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
        }

        .page-header p {
            font-size: 1.1rem;
            color: var(--gray-600);
            margin-bottom: 0;
            position: relative;
            z-index: 1;
        }

        .emergency-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        .contact-card {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .contact-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .contact-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
            box-shadow: var(--shadow-lg);
        }

        .contact-info h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 0.5rem;
        }

        .contact-info .relationship {
            color: var(--gray-600);
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .contact-details {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--gray-100);
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .detail-item:hover {
            background: var(--gray-200);
            transform: translateX(5px);
        }

        .detail-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.1rem;
        }

        .detail-icon.phone { background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%); }
        .detail-icon.email { background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%); }

        .detail-content h5 {
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 0.25rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .detail-content p {
            color: var(--gray-800);
            font-weight: 600;
            margin: 0;
        }

        .message-card {
            background: var(--white);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: var(--shadow-xl);
            border: 1px solid var(--gray-200);
        }

        .message-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .message-header h3 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-800);
            margin: 0;
        }

        .message-templates {
            margin-bottom: 2rem;
        }

        .template-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }

        .template-btn {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            border: 2px solid var(--gray-200);
            background: var(--white);
            color: var(--gray-700);
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .template-btn:hover {
            border-color: var(--danger-color);
            color: var(--danger-color);
            transform: translateY(-2px);
        }

        .message-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 600;
            color: var(--gray-700);
            font-size: 0.95rem;
        }

        .form-control {
            border: 2px solid var(--gray-200);
            border-radius: 12px;
            padding: 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            resize: vertical;
            min-height: 120px;
        }

        .form-control:focus {
            border-color: var(--danger-color);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            outline: none;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .btn-modern {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }

        .btn-modern:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-danger-modern {
            background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%);
            color: white;
        }

        .btn-secondary-modern {
            background: linear-gradient(135deg, var(--gray-600) 0%, var(--gray-700) 100%);
            color: white;
        }

        .alert-modern {
            border-radius: 12px;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            border: none;
            font-weight: 500;
        }

        .alert-success {
            background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%);
            color: white;
        }

        .alert-danger {
            background: linear-gradient(135deg, var(--danger-color) 0%, #f87171 100%);
            color: white;
        }

        .patient-info {
            background: var(--gray-100);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .patient-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .patient-details h5 {
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 0.25rem;
        }

        .patient-details p {
            color: var(--gray-600);
            margin: 0;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }
            
            .emergency-container {
                grid-template-columns: 1fr;
            }
            
            .page-header h1 {
                font-size: 2rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .template-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        
        <div class="page-header">
            <h1>🚨 Emergency Contact</h1>
            <p>Contact emergency person for <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></p>
        </div>

     
        <div class="patient-info">
            <div class="patient-avatar">
                <?php echo strtoupper(substr($patient['first_name'], 0, 1) . substr($patient['last_name'], 0, 1)); ?>
            </div>
            <div class="patient-details">
                <h5><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h5>
                <p>Patient ID: <?php echo $patient_id; ?></p>
            </div>
        </div>

     
        <?php if (isset($error)) : ?>
            <div class="alert-modern alert-danger">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($success)) : ?>
            <div class="alert-modern alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <div class="emergency-container">
         
            <div class="contact-card">
                <div class="contact-header">
                    <div class="contact-avatar">
                        <?php echo strtoupper(substr($emergency_contact['first_name'], 0, 1) . substr($emergency_contact['last_name'], 0, 1)); ?>
                    </div>
                    <div class="contact-info">
                        <h3><?php echo htmlspecialchars($emergency_contact['first_name'] . ' ' . $emergency_contact['last_name']); ?></h3>
                        <div class="relationship">
                            <i class="fas fa-user-shield"></i>
                            <?php echo htmlspecialchars($emergency_contact['relationship']); ?>
                        </div>
                    </div>
                </div>

                <div class="contact-details">
                    <div class="detail-item">
                        <div class="detail-icon phone">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="detail-content">
                            <h5>Phone</h5>
                            <p><?php echo htmlspecialchars($emergency_contact['phone']); ?></p>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-icon email">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="detail-content">
                            <h5>Email</h5>
                            <p><?php echo htmlspecialchars($emergency_contact['email']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="message-card">
                <div class="message-header">
                    <i class="fas fa-comment-dots" style="color: var(--danger-color); font-size: 1.5rem;"></i>
                    <h3>Send Message</h3>
                </div>

                <div class="message-templates">
                    <h6 style="margin-bottom: 1rem; color: var(--gray-700); font-weight: 600;">
                        <i class="fas fa-lightbulb"></i> Quick Message Templates
                    </h6>
                    <div class="template-buttons">
                        <button type="button" class="template-btn" onclick="setTemplate('critical')">
                            <i class="fas fa-exclamation-triangle"></i> Critical Situation
                        </button>
                        <button type="button" class="template-btn" onclick="setTemplate('fall')">
                            <i class="fas fa-user-fall"></i> Fall Incident
                        </button>
                        <button type="button" class="template-btn" onclick="setTemplate('health')">
                            <i class="fas fa-heartbeat"></i> Health Status
                        </button>
                        <button type="button" class="template-btn" onclick="setTemplate('general')">
                            <i class="fas fa-info-circle"></i> General Info
                        </button>
                    </div>
                </div>

                <form action="contact_emergency.php?patient_id=<?php echo $patient_id; ?>" method="POST" class="message-form">
                    <div class="form-group">
                        <label for="message">
                            <i class="fas fa-edit"></i> Your Message
                        </label>
                        <textarea 
                            class="form-control" 
                            id="message" 
                            name="message" 
                            placeholder="Write your emergency message here..." 
                            required
                        ></textarea>
                    </div>

                    <div class="action-buttons">
                        <button type="submit" class="btn-modern btn-danger-modern">
                            <i class="fas fa-paper-plane"></i>
                            Send Message
                        </button>
                        <a href="caretaker_dashboard.php" class="btn-modern btn-secondary-modern">
                            <i class="fas fa-arrow-left"></i>
                            Back to Dashboard
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const patientName = '<?php echo addslashes(htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name'])); ?>';

    const templates = {
        critical: `🚨 CRITICAL EMERGENCY NOTIFICATION

A critical health situation has occurred for ${patientName}. Please contact us immediately.

Condition: [Describe the condition here]
Location: [Location here]
Time: ${new Date().toLocaleString('en-US')}

Emergency intervention may be required.`,

        fall: `⚠️ FALL INCIDENT NOTIFICATION

${patientName} experienced a fall incident. Condition has been checked and is currently stable.

Fall Time: ${new Date().toLocaleString('en-US')}
Condition: [Describe condition here]
Injury: [Injury details if any]

Please contact us as soon as possible.`,

        health: `📊 HEALTH STATUS REPORT

Daily health status report for ${patientName}:

Heart Rate: [Value] bpm
Blood Pressure: [Value] mmHg
Oxygen: [Value] %
Temperature: [Value] °C

General Status: [Good/Fair/Critical]
Notes: [Additional notes if any]

Please contact us if you have any concerns.`,

        general: `ℹ️ GENERAL INFORMATION

General information regarding ${patientName}:

Subject: [Subject here]
Details: [Details here]
Date: ${new Date().toLocaleDateString('en-US')}

This is for informational purposes.`
    };

    function setTemplate(type) {
        const messageArea = document.getElementById('message');
        messageArea.value = templates[type];
        messageArea.focus();

        messageArea.style.borderColor = 'var(--danger-color)';
        setTimeout(() => {
            messageArea.style.borderColor = '';
        }, 1000);
    }
    const textarea = document.getElementById('message');
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 300) + 'px';
    });

    textarea.addEventListener('input', function() {
        const maxLength = 1000;
        const currentLength = this.value.length;
        const remaining = maxLength - currentLength;

        if (currentLength > maxLength * 0.8) {
            this.style.borderColor = remaining < 0 ? 'var(--danger-color)' : 'var(--warning-color)';
        } else {
            this.style.borderColor = '';
        }
    });
</script>
</body>
</html>
